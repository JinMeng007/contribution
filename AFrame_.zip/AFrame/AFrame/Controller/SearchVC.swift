//
//  SearchVC.swift
//  AFrame
//
//  Created by Lee Sheng Jin on 2019/2/10.
//  Copyright © 2019 DrawRanger. All rights reserved.
//

import UIKit

enum SearchFilter {
    case all
    case contacts
    case transactions
    case categories
}

class SearchVC: BaseViewController {
    
    @IBOutlet weak var searchView: UIView!
    @IBOutlet weak var scrView: UIScrollView!
    @IBOutlet weak var lblNoResult: UILabel!
    @IBOutlet weak var txtSearch: SearchTextField!
    
    var searchResults: [SearchResult] = []
    var filterView: FilterView!
    var filterClicked: Bool = false
    var current_filter: SearchFilter = .all
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.filterView = FilterView(frame: CGRect(x: self.view.frame.width - 145, y: 85, width: 135, height: 160))
        self.filterView.loadNib(1)
        self.filterView.alpha = 0.0
        self.view.addSubview(filterView)
        self.initView()
    }
    
    func initView() {
        self.searchView.layer.borderWidth = 1.0
        self.searchView.layer.borderColor = APP_BLUE_COLOR.cgColor
        // Configure a custom search text field
        configureCustomSearchTextField()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
    }
    
    fileprivate func configureCustomSearchTextField() {
        // Set theme - Default: light
        txtSearch.theme = SearchTextFieldTheme.lightTheme()
        
        // Update data source when the user stops typing
        txtSearch.userStoppedTypingHandler = {
            if let criteria = self.txtSearch.text {
                if criteria.count > 0 {
                    
                    // Show loading indicator
//                    self.txtSearch.showLoadingIndicator()
                    self.showHUD()
                    self.filterAcronymInBackground(criteria) {
                        searchResults in
                        
                        // Stop loading indicator
//                        self.txtSearch.stopLoadingIndicator()
                        DispatchQueue.main.async {
                            self.hideHUD()
                            if (searchResults == nil || searchResults?.count == 0) && criteria.count != 0 {
                                self.lblNoResult.alpha = 1.0
                            }else {
                                self.lblNoResult.alpha = 0.0
                                self.searchResults = searchResults ?? []
                                self.drawCells()
                            }
                        }
                        
                    }
                }else {
                    
                }
            }
            } as (() -> Void)
    }
    
    fileprivate func filterAcronymInBackground(_ criteria: String, callback: @escaping (_ searchResults: [SearchResult]?) -> Void) {
        
        let filter = "term=\(criteria)&limit=50"
        
        API.sharedInstance.api_search(filter.addingPercentEncoding(withAllowedCharacters: .urlPathAllowed)!) { (searchResults) in
            DispatchQueue.main.async {
                callback(searchResults)
            }
        }
    }
    
    func drawCells() {
        var cell: UIView?
        var last_cell: UIView?
        var offset_y: CGFloat = 0.0
        
        self.scrView.subviews.forEach { (view) in
            if view is TransactionCell || view is ProfileCell {
                view.removeFromSuperview()
            }
        }
        
        for searchResult in self.searchResults {
            if last_cell != nil {
                offset_y = last_cell!.frame.origin.y + last_cell!.frame.height
            }
            if searchResult.contact == nil {
                let tmpCell = TransactionCell(frame: CGRect(x: 0, y: offset_y, width: self.scrView.frame.width, height: 120))
                tmpCell.transaction = searchResult.xaction
                cell = tmpCell
            }else {
                let tmpCell = ProfileCell(frame: CGRect(x: 0, y: offset_y, width: self.scrView.frame.width, height: 60))
                tmpCell.contact = searchResult.contact
                cell = tmpCell
            }
            last_cell = cell
            self.scrView.addSubview(cell!)
            self.scrView.contentSize = CGSize(width: 0, height: last_cell!.frame.origin.y + last_cell!.frame.height)
        }
        
    }
    
    @IBAction func actionClearResult(_ sender: UIButton) {
        self.txtSearch.text = ""
        self.searchResults.removeAll()
        self.scrView.subviews.forEach { (view) in
            if view is TransactionCell || view is ProfileCell {
                view.removeFromSuperview()
            }
        }
        self.scrView.contentSize = CGSize(width: 0, height: 0)
        self.lblNoResult.alpha = 0.0
    }
    
    @IBAction func actionOpenFilter(_ sender: UIButton) {
        self.view.endEditing(true)
        if self.filterView.alpha == 0.0 {
            self.filterView.alpha = 1.0
        }else {
            self.filterView.alpha = 0.0
        }
    }
    
}
