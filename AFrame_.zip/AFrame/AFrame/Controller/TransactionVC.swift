//
//  TransactionVC.swift
//  AFrame
//
//  Created by Lee Sheng Jin on 2019/2/10.
//  Copyright © 2019 DrawRanger. All rights reserved.
//

import UIKit
import DropDown

class TransactionVC: BaseViewController {
    
    @IBOutlet weak var scrView: UIScrollView!
    @IBOutlet weak var lblNoResult: UILabel!
    @IBOutlet weak var btnFilter: UIButton!
    
    var open_transactions: [Transaction] = []
    let refreshCtrl: UIRefreshControl = UIRefreshControl()
    var current_filter: String = "appuser"
    var filterView: FilterView!
    var filterClicked: Bool = false
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.filterView = FilterView(frame: CGRect(x: self.view.frame.width - 170, y: 85, width: 160, height: 100))
        self.filterView.loadNib(0)
        self.filterView.alpha = 0.0
        self.view.addSubview(filterView)
        
        if !User.sharedInstance.is_loggedin {
            self.showHUD()
            API.sharedInstance.api_authentication(User.sharedInstance.userName!, User.sharedInstance.password!) { (errMsg) in
                DispatchQueue.main.async {
                    self.hideHUD()
                    if errMsg == nil {
                        self.current_filter = "appuser"
                        self.getAllOpenTransactions()
                    }else {
                        self.alertViewController(title: "Oops!", message: errMsg!)
                    }
                }
            }
        }else {
            self.current_filter = "appuser"
            self.getAllOpenTransactions()
        }
        
        refreshCtrl.frame = CGRect(x: 0, y: 50, width: refreshCtrl.frame.width, height: refreshCtrl.frame.height)
        refreshCtrl.tintColor = UIColor(red: 200 / 255, green: 200 / 255, blue: 200 / 255, alpha: 1.0)
        refreshCtrl.addTarget(self, action: #selector(self.getAllOpenTransactions), for: .valueChanged)
        self.scrView.refreshControl = refreshCtrl
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
    }
    
    @IBAction func actionOpenFilter(_ sender: UIButton) {
        self.view.endEditing(true)
        if self.filterView.alpha == 0.0 {
            self.filterView.alpha = 1.0
        }else {
            self.filterView.alpha = 0.0
        }
    }
    
    @objc func getAllOpenTransactions() {
        if self.open_transactions.count == 0 {
            self.lblNoResult.alpha = 1.0
        }else {
            self.lblNoResult.alpha = 0.0
        }
        if self.filterClicked {
            self.showHUD()
        }
        API.sharedInstance.api_get_open_xactions(self.current_filter) { (open_transactions) in
            DispatchQueue.main.async {
                if self.filterClicked {
                    self.hideHUD()
                    self.filterClicked = false
                }
                self.refreshCtrl.endRefreshing()
                self.scrView.subviews.forEach { (view) in
                    if view is TransactionCell {
                        view.removeFromSuperview()
                    }
                }
                if open_transactions != nil && open_transactions?.count != 0 {
                    self.lblNoResult.alpha = 0.0
                    self.open_transactions = open_transactions!
                    self.drawCells()
                }else {
                    self.lblNoResult.alpha = 1.0
                }
            }
        }
    }
    
    func drawCells() {
        var cell: TransactionCell?
        var last_cell: TransactionCell?
        var offset_y: CGFloat = 0
        
        for transaction in self.open_transactions {
            if last_cell != nil {
                offset_y = last_cell!.frame.origin.y + last_cell!.frame.height
            }
            cell = TransactionCell(frame: CGRect(x: 0, y: offset_y, width: self.scrView.frame.width, height: 120))
            cell?.transaction = transaction
            last_cell = cell
            self.scrView.addSubview(cell!)
            self.scrView.contentSize = CGSize(width: 0, height: last_cell!.frame.origin.y + last_cell!.frame.height)
        }
    }

}
