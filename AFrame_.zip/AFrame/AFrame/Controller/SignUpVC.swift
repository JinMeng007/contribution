//
//  SignUpVC.swift
//  AFrame
//
//  Created by Lee Sheng Jin on 2019/6/17.
//  Copyright © 2019 DrawRanger. All rights reserved.
//

import UIKit
import WebKit

class SignUpVC: BaseViewController, WKUIDelegate, WKNavigationDelegate {
    
    var signupWebView: WKWebView!
    var isLoaded: Bool = false

    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.isLoaded = false
        
        let webConfig = WKWebViewConfiguration()
        signupWebView = WKWebView(frame: CGRect(x: 0, y: 80, width: self.view.bounds.width, height: self.view.bounds.height - 80), configuration: webConfig)
        signupWebView.uiDelegate = self
        signupWebView.navigationDelegate = self
        self.view.addSubview(signupWebView)
        
        let url_request = URLRequest(url: URL(string: APIURL.sign_up)!)
        signupWebView.load(url_request)
    }
    
    @IBAction func actionBack(_ sender: UIButton) {
        self.navigationController?.popViewController(animated: true)
    }
    
    func webView(_ webView: WKWebView, didFinish navigation: WKNavigation!) {
        print("did finish.....")
        self.hideHUD()
        if !isLoaded {
            self.isLoaded = true
        }else {
            self.navigationController?.popViewController(animated: true)
        }
    }
    
    func webView(_ webView: WKWebView, didStartProvisionalNavigation navigation: WKNavigation!) {
        print("did start.....")
        self.showHUD()
    }

}
