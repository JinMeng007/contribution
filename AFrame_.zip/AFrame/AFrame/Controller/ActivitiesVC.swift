//
//  ActivitiesVC.swift
//  AFrame
//
//  Created by Lee Sheng Jin on 2019/2/13.
//  Copyright © 2019 DrawRanger. All rights reserved.
//

import UIKit

class ActivitiesVC: BaseViewController {
    
    @IBOutlet weak var scrView: UIScrollView!
    @IBOutlet weak var lblAddress: UILabel!
    @IBOutlet weak var lblNoActivities: UILabel!
    
    var xaction_detail: TransactionDetail?
    var xaction_activities: [TransactionActivity] = []
    
    let refreshCtrl: UIRefreshControl = UIRefreshControl()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.lblAddress.text = self.xaction_detail?.address?.addressLineString
        refreshCtrl.frame = CGRect(x: 0, y: 50, width: refreshCtrl.frame.width, height: refreshCtrl.frame.height)
        refreshCtrl.tintColor = UIColor(red: 200 / 255, green: 200 / 255, blue: 200 / 255, alpha: 1.0)
        refreshCtrl.addTarget(self, action: #selector(self.getXactionActivities), for: .valueChanged)
        self.scrView.refreshControl = refreshCtrl
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        self.getXactionActivities()
    }
    
    @objc func getXactionActivities() {
//        self.showHUD()
        API.sharedInstance.api_xaction_activities(self.xaction_detail!.xactionId!) { (activities) in
            DispatchQueue.main.async {
                self.refreshCtrl.endRefreshing()
//                self.hideHUD()
                self.xaction_activities = activities ?? []
                if self.xaction_activities.count > 0 {
                    self.lblNoActivities.alpha = 0.0
                }else {
                    self.lblNoActivities.alpha = 1.0
                }
                self.drawCell()
            }
        }
    }
    
    @IBAction func actionGotoLink(_ sender: UIButton) {
        if URL(string: self.xaction_detail?.siteUrl ?? "") != nil {
            UIApplication.shared.open(URL(string: self.xaction_detail?.siteUrl ?? "")!, options: [:], completionHandler: nil)
        }
    }
    
    @IBAction func actionBack(_ sender: UIButton) {
        self.navigationController?.popViewController(animated: true)
    }
    
    func drawCell() {
        var last_cell: UIView?
        var offset_y: CGFloat = 61.0
        self.scrView.subviews.forEach { (view) in
            if view is ActivityCell {
                view.removeFromSuperview()
            }
        }
        for activity in self.xaction_activities {
            if last_cell != nil {
                offset_y = last_cell!.frame.origin.y + last_cell!.frame.height
            }
            
            if activity.xactionActivityClass == "TASK" {
                let task_instance = activity.task
                var cell: TaskCell?
                
                var labelHeight = task_instance?.subject?.heightForView(UIFont(name: "Gordita-Medium", size: 14.0)!, self.scrView.frame.width - 80) ?? 45
                labelHeight = labelHeight * 1.4
                var dy: CGFloat = 0
                if labelHeight > 45 {
                    dy = labelHeight - 45
                }
                
                if task_instance?.status == "OPEN" {
                    cell = TaskCell(frame: CGRect(x: 0, y: offset_y, width: self.scrView.frame.width, height: 105 + dy))
                    cell?.loadNib(1)
                } else if task_instance?.status == "PENDING" {
                    cell = TaskCell(frame: CGRect(x: 0, y: offset_y, width: self.scrView.frame.width, height: 80 + dy))
                    cell?.loadNib(2)
                }else {
                    cell = TaskCell(frame: CGRect(x: 0, y: offset_y, width: self.scrView.frame.width, height: 80 + dy))
                    cell?.loadNib(4)
                }
                cell?.task = task_instance
                last_cell = cell
            }else {
                var height: CGFloat = 0.0
                var type: Int = 0
                var dy: CGFloat = 0
                
                if activity.xactionActivityClass == "XACTIONACTIVITYIMPORT" {
                    var labelHeight = activity.xactionActivityImport?.feedback?.heightForView(UIFont(name: "Gordita-Medium", size: 14.0)!, self.scrView.frame.width - 80) ?? 45
                    labelHeight = labelHeight * 1.4
                    if labelHeight > 45 {
                        dy = labelHeight - 45
                    }
                    height = 185 + dy
                    if activity.xactionActivityImport?.showAgentName == nil || activity.xactionActivityImport?.showAgentName == "" {
                        height -= 20
                    }
                    if activity.xactionActivityImport?.showAgentPhone2 == nil || activity.xactionActivityImport?.showAgentPhone2 == "" {
                        height -= 20
                    }
                    if activity.xactionActivityImport?.showAgentPhone1 == nil || activity.xactionActivityImport?.showAgentPhone1 == "" {
                        height -= 20
                    }
                    if activity.xactionActivityImport?.showAgentEmail == nil || activity.xactionActivityImport?.showAgentEmail == "" {
                        height -= 20
                    }
                    type = 1
                }else {
                    var labelHeight = activity.xactionActivityGeneric?.note?.heightForView(UIFont(name: "Gordita-Medium", size: 14.0)!, self.scrView.frame.width - 80) ?? 45
                    labelHeight = labelHeight * 1.4
                    if labelHeight > 45 {
                        dy = labelHeight - 45
                    }
                    if (activity.xactionActivityGeneric?.fileName != nil && activity.xactionActivityGeneric?.fileName != "") || (activity.xactionActivityGeneric?.url != nil && activity.xactionActivityGeneric?.url != "") {
                        height = 125 + dy
                        type = 0
                    }else {
                        height = 100 + dy
                        type = 2
                    }
                }
                let cell = ActivityCell(frame: CGRect(x: 0, y: offset_y, width: self.scrView.frame.width, height: height))
                cell.loadNib(type)
                cell.activity = activity
                last_cell = cell
            }
            self.scrView.addSubview(last_cell!)
            self.scrView.contentSize = CGSize(width: 0, height: last_cell!.frame.origin.y + last_cell!.frame.height)
            
        }
    }
    
    @IBAction func actionCreateNewActivity(_ sender: UIButton) {
        let vc = self.storyboard?.instantiateViewController(withIdentifier: "XActivityGenericVC") as! XActivityGenericVC
        vc.activity = nil
        vc.transaction = self.xaction_detail
        self.navigationController?.pushViewController(vc, animated: true)
    }
    
}
