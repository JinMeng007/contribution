//
//  NotificationVC.swift
//  AFrame
//
//  Created by Lee Sheng Jin on 2019/2/10.
//  Copyright © 2019 DrawRanger. All rights reserved.
//

import UIKit

class NotificationVC: BaseViewController {
    
    @IBOutlet weak var scrView: UIScrollView!
    @IBOutlet weak var tabBtn: UISegmentedControl!
    @IBOutlet weak var lblTitle: UILabel!
    @IBOutlet weak var lblMark: UIButton!
    @IBOutlet weak var lblNoResult: UILabel!
    @IBOutlet weak var tblNotification: UITableView!
    @IBOutlet weak var sepView: UIView!
    
    var current_notifications: [AFNotification] = []
    var upcoming_dates: [Event] = []
    
    let notiRefCtrl: UIRefreshControl = UIRefreshControl()
    let upcomingRefCtrl: UIRefreshControl = UIRefreshControl()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.initView()
    }
    
    func initView() {
        tabBtn.selectedSegmentIndex = 0
        lblTitle.text = "Notifications"
        lblNoResult.text = "No Notifications"
        lblNoResult.alpha = 1.0
        
        notiRefCtrl.frame = CGRect(x: 0, y: 50, width: notiRefCtrl.frame.width, height: notiRefCtrl.frame.height)
        notiRefCtrl.tintColor = UIColor(red: 200 / 255, green: 200 / 255, blue: 200 / 255, alpha: 1.0)
        notiRefCtrl.addTarget(self, action: #selector(self.getNotifications), for: .valueChanged)
        self.tblNotification.refreshControl = notiRefCtrl
        
        upcomingRefCtrl.frame = CGRect(x: 0, y: 50, width: upcomingRefCtrl.frame.width, height: upcomingRefCtrl.frame.height)
        upcomingRefCtrl.tintColor = UIColor(red: 200 / 255, green: 200 / 255, blue: 200 / 255, alpha: 1.0)
        upcomingRefCtrl.addTarget(self, action: #selector(self.getUpcomingDates), for: .valueChanged)
        self.scrView.refreshControl = upcomingRefCtrl
        
        self.tblNotification.delegate = self
        self.tblNotification.dataSource = self
        self.tblNotification.alpha = 1.0
        self.tblNotification.allowsSelection = false
        self.tblNotification.separatorStyle = .none
        self.scrView.alpha = 0.0
        self.actionTab(tabBtn)
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
    }
    
    @objc func getNotifications() {
//        self.showHUD()
        API.sharedInstance.api_current_notifications { (current_notifications) in
            DispatchQueue.main.async {
//                self.hideHUD()
                self.notiRefCtrl.endRefreshing()
                self.current_notifications.removeAll()
                self.tblNotification.reloadData()
                if current_notifications != nil && current_notifications?.count != 0 {
                    self.lblNoResult.alpha = 0.0
                    self.current_notifications = current_notifications!
                    self.tblNotification.reloadData()
                }else {
                    self.lblNoResult.text = "No Notifications"
                    self.lblNoResult.alpha = 1.0
                }
            }
        }
    }
    
    @objc func getUpcomingDates() {
//        self.showHUD()
        API.sharedInstance.api_all_user_events(30) { (events) in
            DispatchQueue.main.async {
//                self.hideHUD()
                self.upcomingRefCtrl.endRefreshing()
                self.scrView.subviews.forEach { (view) in
                    if view is UpcomingDateCell {
                        view.removeFromSuperview()
                    }
                }
                if events != nil && events?.count != 0 {
                    self.lblNoResult.alpha = 0.0
                    self.upcoming_dates = events!
                    self.drawUpcomingDates()
                }else {
                    self.lblNoResult.text = "No Upcoming Dates"
                    self.lblNoResult.alpha = 1.0
                }
            }
        }
    }
    
    @IBAction func actionTab(_ sender: UISegmentedControl) {
        if sender.selectedSegmentIndex == 0 || sender.selectedSegmentIndex == -1 {
            self.lblTitle.text = "Notifications"
            self.lblMark.alpha = 1.0
            self.sepView.alpha = 1.0
            self.tblNotification.alpha = 1.0
            self.scrView.alpha = 0.0
            self.getNotifications()
        }else {
            self.lblTitle.text = "Upcoming Dates"
            self.lblMark.alpha = 0.0
            self.sepView.alpha = 0.0
            self.tblNotification.alpha = 0.0
            self.scrView.alpha = 1.0
            self.getUpcomingDates()
        }
    }
    
    func drawUpcomingDates() {
        var cell: UpcomingDateCell?
        var last_cell: UpcomingDateCell?
        var offset_y: CGFloat = 0.0
        
        for event in self.upcoming_dates {
            if last_cell != nil {
                offset_y = last_cell!.frame.origin.y + last_cell!.frame.height
            }
            
            var labelHeight = event.title?.heightForView(UIFont(name: "Gordita-Medium", size: 14.0)!, self.scrView.frame.width - 100) ?? 25
            labelHeight = labelHeight * 1.2
            var dy: CGFloat = 0
            if labelHeight > 25 {
                dy = labelHeight - 25
            }
            
            cell = UpcomingDateCell(frame: CGRect(x: 0, y: offset_y, width: self.scrView.frame.width, height: 100 + dy))
            cell?.event = event
            last_cell = cell
            self.scrView.addSubview(cell!)
            self.scrView.contentSize = CGSize(width: 0, height: last_cell!.frame.origin.y + last_cell!.frame.height)
        }
    }
    
    @IBAction func actionMarkAllAsRead(_ sender: UIButton) {
        API.sharedInstance.api_mark_all_read()
        for notification in self.current_notifications {
            notification.hasBeenRead = true
        }
        self.tblNotification.reloadData()
    }
    
}

extension NotificationVC: UITableViewDelegate, UITableViewDataSource, NotificationCellDelegate {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return self.current_notifications.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "notiCell") as! NotificationCell
        cell.delegate = self
        cell.notification = self.current_notifications[indexPath.row]
        return cell
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        var labelHeight = self.current_notifications[indexPath.row].displayText?.heightForView(UIFont(name: "Gordita-Medium", size: 14.0)!, self.tblNotification.frame.width - 100) ?? 35
        labelHeight = labelHeight * 1.5
        var height: CGFloat = 0
        if labelHeight <= 35 {
            height = 120.0
        }else {
            height = 120.0 + labelHeight - 35
        }
        if self.current_notifications[indexPath.row].task != nil {
            return height - 35
        }else {
            return height
        }
        
    }
    
    func deleteNotification(_ cell: NotificationCell) {
        let indexPath = self.tblNotification.indexPath(for: cell)
        API.sharedInstance.api_delete_notification(self.current_notifications[indexPath!.row].notificationId!)
        self.current_notifications.remove(at: indexPath!.row)
        self.tblNotification.deleteRows(at: [indexPath!], with: UITableView.RowAnimation.automatic)
    }
    
}

protocol NotificationCellDelegate {
    func deleteNotification(_ cell: NotificationCell)
}

class NotificationCell: UITableViewCell {
    @IBOutlet weak var btnNotiIcon: UIButton!
    @IBOutlet weak var lblNotiCont: UILabel!
    @IBOutlet weak var lblNotiUser: UILabel!
    @IBOutlet weak var lblNotiDetailIcon: UILabel!
    @IBOutlet weak var lblNotiDetailCont: UILabel!
    @IBOutlet weak var lblDate: UILabel!
    
    @IBOutlet weak var h_d_constraint: NSLayoutConstraint!
    
    var delegate: NotificationCellDelegate?
    
    var notification: AFNotification? {
        didSet {
            let dateFormatter = DateFormatter()
            dateFormatter.dateFormat = "yyyy-MM-dd"
            var date: Date!
            self.lblNotiCont.setAttrTxt(notification?.displayText ?? "")
            if notification?.task != nil {
//                self.lblNotiUser.text = notification?.task?.subject
                self.h_d_constraint.constant = 0.0
                self.lblNotiDetailCont.text = "Task"
                self.lblNotiDetailIcon.text = AppIcons.task.rawValue
                date = notification?.task?.dueDate?.utcToLocal(dateFormatter.dateFormat) ?? Date().utcToLocal(dateFormatter.dateFormat)
            }else {
                self.h_d_constraint.constant = 25.0
            }
            self.contentView.layoutIfNeeded()
            if notification?.event != nil {
                if notification?.event?.xaction != nil {
                    self.lblNotiUser.text = "\(notification?.event?.xaction?.address?.addressLine ?? "") - \(notification?.event?.xaction?.contact?.lastName ?? notification?.event?.xaction?.contact?.company ?? "")"
                }else if notification?.event?.contact != nil {
                    self.lblNotiUser.text = notification?.event?.contact?.displayFirstLast
                }else {
                    self.lblNotiUser.text = notification?.event?.title
                }
                self.lblNotiDetailCont.text = "Event"
                self.lblNotiDetailIcon.text = AppIcons.task.rawValue
                date = notification?.event?.startDate?.utcToLocal(dateFormatter.dateFormat) ?? Date().utcToLocal(dateFormatter.dateFormat)
            }
            if notification?.xaction != nil {
                self.lblNotiUser.text = "\(notification?.xaction?.address?.addressLine ?? "") - \(notification?.xaction?.contact?.lastName ?? notification?.xaction?.contact?.company ?? "")"
                self.lblNotiDetailCont.text = "Transaction"
                self.lblNotiDetailIcon.text = AppIcons.home.rawValue
                date = notification?.xaction?.closingDate?.utcToLocal(dateFormatter.dateFormat) ?? Date().utcToLocal(dateFormatter.dateFormat)
            }
            if notification?.contact != nil {
                self.lblNotiUser.text = notification?.contact?.displayFirstLast
                self.lblNotiDetailCont.text = "Contact"
                self.lblNotiDetailIcon.text = AppIcons.profile.rawValue
                date = Date().utcToLocal(dateFormatter.dateFormat)
            }
            dateFormatter.dateFormat = "MMM d (E)"
            self.lblDate.text = dateFormatter.string(from: date)
            if notification!.hasBeenRead! {
                self.btnNotiIcon.setTitleColor(APP_BLUE_COLOR, for: .normal)
            }else {
                self.btnNotiIcon.setTitleColor(APP_ORANGE_COLOR, for: .normal)
            }
            btnNotiIcon.setTitle(notification?.notificationType?.getFontIcon(), for: .normal)
        }
    }
    
    @IBAction func actionDelete(_ sender: UIButton) {
        self.delegate?.deleteNotification(self)
    }
    
    @IBAction func actionGotoDetail(_ sender: UIButton) {
        let vc = self.findViewController() as! BaseViewController
        if self.notification?.xaction != nil || self.notification?.event?.xaction != nil {
            vc.showHUD()
            var xactionId: Int = 0
            if self.notification?.xaction != nil {
                xactionId = self.notification!.xaction!.xactionId!
            }else {
                xactionId = self.notification!.event!.xaction!.xactionId!
            }
            API.sharedInstance.api_xaction_detail(xactionId) { (detail) in
                DispatchQueue.main.async {
                    if detail != nil {
                        let viewCon = vc.storyboard?.instantiateViewController(withIdentifier: "TransactionDetailVC") as! TransactionDetailVC
                        viewCon.xaction_detail = detail
                        API.sharedInstance.api_xaction_participants(xactionId) { (participants) in
                            DispatchQueue.main.async {
                                vc.hideHUD()
                                viewCon.xaction_participants = participants ?? []
                                vc.navigationController?.pushViewController(viewCon, animated: true)
                            }
                        }
                    }else {
                        vc.hideHUD()
                    }
                }
            }
        }else if self.notification?.contact != nil || self.notification?.event?.contact != nil {
            vc.showHUD()
            var contactId: Int = 0
            if self.notification?.contact != nil {
                contactId = self.notification!.contact!.contactId!
            }else {
                contactId = self.notification!.event!.contact!.contactId!
            }
            API.sharedInstance.api_contact(contactId) { (contact_detail) in
                DispatchQueue.main.async {
                    vc.hideHUD()
                    if contact_detail != nil {
                        let viewCon = vc.storyboard?.instantiateViewController(withIdentifier: "ContactDetailVC") as! ContactDetailVC
                        viewCon.contact_object = contact_detail
                        vc.navigationController?.pushViewController(viewCon, animated: true)
                    }
                }
            }
        }
    }
    
    @IBAction func actionRead(_ sender: UIButton) {
        self.btnNotiIcon.setTitleColor(APP_BLUE_COLOR, for: .normal)
        API.sharedInstance.api_mark_read(self.notification!.notificationId!)
    }
    
}
