//
//  UsersVC.swift
//  AFrame
//
//  Created by Lee Sheng Jin on 2019/3/13.
//  Copyright © 2019 DrawRanger. All rights reserved.
//

import UIKit

class UsersVC: BaseViewController {
    
    var appUsers: [AppUser] = []
    @IBOutlet weak var scrView: UIScrollView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.drawCells()
    }
    
    func drawCells() {
        var cell: ProfileCell?
        var last_cell: ProfileCell?
        var offset_y: CGFloat = 0
        for appUser in self.appUsers {
            if last_cell != nil {
                offset_y = last_cell!.frame.origin.y + last_cell!.frame.height
            }
            cell = ProfileCell(frame: CGRect(x: 0, y: offset_y, width: self.scrView.frame.width, height: 60))
            cell?.appUser = appUser
            last_cell = cell
            self.scrView.addSubview(cell!)
            self.scrView.contentSize = CGSize(width: 0, height: last_cell!.frame.origin.y + last_cell!.frame.height)
        }
    }
    
    @IBAction func actionBack(_ sender: UIButton) {
        self.dismiss(animated: true, completion: nil)
    }
    
}
