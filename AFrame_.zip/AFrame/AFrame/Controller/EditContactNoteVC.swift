//
//  EditContactNoteVC.swift
//  AFrame
//
//  Created by Lee Sheng Jin on 2019/2/13.
//  Copyright © 2019 DrawRanger. All rights reserved.
//

import UIKit

class EditContactNoteVC: BaseViewController {
    
    @IBOutlet weak var scrView: UIScrollView!
    @IBOutlet weak var noteSegment: UISegmentedControl!
    @IBOutlet weak var txtNote: UITextView!
    @IBOutlet weak var lblDate: UITextField!
    @IBOutlet weak var lblAuthorName: UILabel!
    @IBOutlet weak var prospectingSwitch: AFSwitch!
    
    var note: Note?
    var contact_object: ContactDetail?
    let dateFormatter = DateFormatter()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        scrView.contentSize = CGSize(width: 0, height: 587)
        let attrs: [NSAttributedString.Key : Any] = [NSAttributedString.Key.font: UIFont(name: "FontAwesome5ProLight", size: 14)!]
        noteSegment.setTitleTextAttributes(attrs, for: .normal)
        
        if note == nil {
            note = Note([:])
            self.note?.noteType = "NOTE"
        }
        
        // NOTE, PHONE, LETTER, EMAIL
        switch note?.noteType {
        case "PHONE":
            noteSegment.selectedSegmentIndex = 1
            break
        case "LETTER":
            noteSegment.selectedSegmentIndex = 2
            break
        case "EMAIL":
            noteSegment.selectedSegmentIndex = 3
            break
        default:
            noteSegment.selectedSegmentIndex = 0
            break
        }
        
        let datePVComplete = UIDatePicker()
        datePVComplete.datePickerMode = .date
        lblDate.inputView = datePVComplete
        datePVComplete.addTarget(self, action: #selector(self.setDate(sender:)), for: .valueChanged)
        if self.note?.note != nil && self.note?.note != "" {
            self.txtNote.text = self.note?.note
        }else {
            self.txtNote.placeholder = "Note"
        }
//        self.lblAuthorName.text = self.contact_object?.displayFirstLast
        self.prospectingSwitch.isOn = self.note?.isProspecting ?? false
        dateFormatter.dateFormat = "yyyy-MM-dd"
        let date = dateFormatter.date(from: note?.noteDate ?? "") ?? Date()
        dateFormatter.dateFormat = "MMMM d, yyyy"
        lblDate.text = dateFormatter.string(from: date.utcToLocal(dateFormatter.dateFormat))
    }
    
    @objc func setDate(sender: UIDatePicker) {
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "MMMM d, yyyy"
        lblDate.text = dateFormatter.string(from: sender.date)
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        if self.appDelegate.selected_appUser != nil {
            self.lblAuthorName.text = self.appDelegate.selected_appUser?.displayFirstLast
        }
    }
    
    @IBAction func actionNoteType(_ sender: UISegmentedControl) {
        // NOTE, PHONE, LETTER, EMAIL
        switch sender.selectedSegmentIndex {
        case 0:
            self.note?.noteType = "NOTE"
            break
        case 1:
            self.note?.noteType = "PHONE"
            break
        case 2:
            self.note?.noteType = "LETTER"
            break
        default:
            self.note?.noteType = "EMAIL"
            break
        }
    }
    
    @IBAction func actionBack(_ sender: UIButton) {
        if sender.tag == 100 {
            var param: [String: Any] = [
                "appUserId": self.note?.appUserId ?? self.appDelegate.selected_appUser?.appUserId ?? 0,
                "contactId": self.note?.contactId ?? self.contact_object?.contactId ?? 0,
                "note": self.txtNote.text!,
                "noteType": self.note!.noteType!,
                "isProspecting": self.prospectingSwitch.isOn
            ]
            if self.lblDate.text != "" {
                let dateFormatter = DateFormatter()
                dateFormatter.dateFormat = "MMMM d, yyyy"
                let date = self.lblDate.text!.utcToLocal(dateFormatter.dateFormat)
                dateFormatter.dateFormat = "yyyy-MM-dd"
                param.updateValue(dateFormatter.string(from: date), forKey: "noteDate")
            }
            if self.note?.contactNoteId != nil && self.note?.contactNoteId != 0 {
                API.sharedInstance.api_patch_note(param, self.note?.contactNoteId ?? 0)
            }else {
                if self.appDelegate.selected_appUser == nil {
                    self.alertViewController(title: "Oops!", message: "Please select Author.")
                }else {
                    API.sharedInstance.api_create_note(param)
                }
            }
        }else {
            if self.note?.contactNoteId != nil && self.note?.contactNoteId != 0 {
                API.sharedInstance.api_delete_note(self.note?.contactNoteId ?? 0)
            }
        }
        self.appDelegate.selected_appUser = nil
        self.navigationController?.popViewController(animated: true)
    }
    
    @IBAction func actionGotoDetail(_ sender: UIButton) {
        self.showHUD()
        API.sharedInstance.api_active_app_users(note?.appUserId ?? User.sharedInstance.appUserId!) { (active_users) in
            DispatchQueue.main.async {
                self.hideHUD()
                if active_users != nil {
                    let vc = self.storyboard?.instantiateViewController(withIdentifier: "UsersVC") as! UsersVC
                    vc.appUsers = active_users!
                    self.present(vc, animated: true, completion: nil)
                }
            }
        }
    }
    
}
