//
//  ContactDatesVC.swift
//  AFrame
//
//  Created by Lee Sheng Jin on 2019/2/13.
//  Copyright © 2019 DrawRanger. All rights reserved.
//

import UIKit

class ContactDatesVC: BaseViewController {
    
    @IBOutlet weak var scrView: UIScrollView!
    @IBOutlet weak var lblAddress: UILabel!
    @IBOutlet weak var lblNoDates: UILabel!
    
    var xaction_detail: TransactionDetail?
    var contract_dates: [ContractDate] = []
    let refreshCtrl: UIRefreshControl = UIRefreshControl()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        refreshCtrl.frame = CGRect(x: 0, y: 50, width: refreshCtrl.frame.width, height: refreshCtrl.frame.height)
        refreshCtrl.tintColor = UIColor(red: 200 / 255, green: 200 / 255, blue: 200 / 255, alpha: 1.0)
        refreshCtrl.addTarget(self, action: #selector(self.getContractDates), for: .valueChanged)
        self.scrView.refreshControl = refreshCtrl
        self.lblAddress.text = xaction_detail?.address?.addressLineString
        if self.contract_dates.count > 0 {
            self.lblNoDates.alpha = 0.0
        }else {
            self.lblNoDates.alpha = 1.0
        }
        self.drawCells()
    }
    
    @objc func getContractDates() {
        let suffix = "xactionId=\(xaction_detail?.xactionId ?? 0)"
        API.sharedInstance.api_contract_dates(suffix) { (contract_dates) in
            DispatchQueue.main.async {
                self.refreshCtrl.endRefreshing()
                self.contract_dates = contract_dates ?? []
                if self.contract_dates.count > 0 {
                    self.lblNoDates.alpha = 0.0
                }else {
                    self.lblNoDates.alpha = 1.0
                }
                self.drawCells()
            }
        }
    }
    
    func drawCells() {
        var cell: ContractDateCell?
        var last_cell: ContractDateCell?
        var offset_y: CGFloat = 61.0
        self.scrView.subviews.forEach { (view) in
            if view is ContractDateCell {
                view.removeFromSuperview()
            }
        }
        for contractDate in self.contract_dates {
            if last_cell != nil {
                offset_y = last_cell!.frame.origin.y + last_cell!.frame.height
            }
            
            var labelHeight = contractDate.title?.heightForView(UIFont(name: "Gordita-Medium", size: 17.0)!, self.scrView.frame.width - 80) ?? 25
            labelHeight = labelHeight * 1.4
            var dy: CGFloat = 0
            if labelHeight > 25 {
                dy = labelHeight - 25
            }
            
            cell = ContractDateCell(frame: CGRect(x: 0, y: offset_y, width: self.scrView.frame.width, height: 80 + dy))
            cell?.contractDate = contractDate
            last_cell = cell
            self.scrView.addSubview(cell!)
            self.scrView.contentSize = CGSize(width: 0, height: last_cell!.frame.origin.y + last_cell!.frame.height)
        }
    }
    
    @IBAction func actionBack(_ sender: UIButton) {
        self.navigationController?.popViewController(animated: true)
    }
    
    @IBAction func actionGotoDetail(_ sender: UIButton) {
        if URL(string: self.xaction_detail?.siteUrl ?? "") != nil {
            UIApplication.shared.open(URL(string: self.xaction_detail?.siteUrl ?? "")!, options: [:], completionHandler: nil)
        }
    }
    
}
