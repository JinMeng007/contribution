//
//  TasksVC.swift
//  AFrame
//
//  Created by Lee Sheng Jin on 2019/2/13.
//  Copyright © 2019 DrawRanger. All rights reserved.
//

import UIKit

class TasksVC: BaseViewController {
    
    @IBOutlet weak var lblName: UILabel!
    @IBOutlet weak var tblTask: UITableView!
    @IBOutlet weak var lblNoTasks: UILabel!
    
    var tasks: [Any] = []
    var contact_object: ContactDetail?
    var xaction_detail: TransactionDetail?
    
    let refreshCtrl: UIRefreshControl = UIRefreshControl()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        if self.contact_object != nil {
            self.lblName.text = self.contact_object?.displayFirstLast
        }else {
            self.lblName.text = self.xaction_detail?.address?.addressLineString
        }
        tblTask.delegate = self
        tblTask.dataSource = self
        tblTask.separatorStyle = .none
        tblTask.allowsSelection = false
        tblTask.register(UINib(nibName: "AFCell", bundle: nil), forCellReuseIdentifier: "afCell")
        
        refreshCtrl.frame = CGRect(x: 0, y: 50, width: refreshCtrl.frame.width, height: refreshCtrl.frame.height)
        refreshCtrl.tintColor = UIColor(red: 200 / 255, green: 200 / 255, blue: 200 / 255, alpha: 1.0)
        refreshCtrl.addTarget(self, action: #selector(self.getContactTasks), for: .valueChanged)
        self.tblTask.refreshControl = refreshCtrl
        
        self.getContactTasks()
    }
    
    @objc func getContactTasks() {
//        self.showHUD()
        var suffix = "contactId=\(contact_object?.contactId ?? 0)"
        if contact_object == nil {
            suffix = "xactionId=\(xaction_detail?.xactionId ?? 0)"
        }
        API.sharedInstance.api_contact_tasks(suffix) { (tasks) in
            DispatchQueue.main.async {
//                self.hideHUD()
                self.refreshCtrl.endRefreshing()
                if tasks != nil && tasks?.count != 0 {
                    self.lblNoTasks.alpha = 0.0
                    self.tasks.removeAll()
                    let dateFormatter = DateFormatter()
                    dateFormatter.dateFormat = "yyyy-MM-dd"
                    let date1 = Date().utcToLocal(dateFormatter.dateFormat)
                    
                    var overdue_tasks: [Any] = []
                    var today_tasks: [Any] = []
                    var date_list: [String] = []
                    var completed_tasks: [Any] = []
                    var future_tasks: [[Any]] = []
                    for task in tasks! {
                        let date2 = task.dueDate!.utcToLocal(dateFormatter.dateFormat)
                        
                        if task.status == "COMPLETE" {
                            if completed_tasks.count == 0 {
                                completed_tasks.append("Completed")
                            }
                            completed_tasks.append(task)
                        }else {
                            if date1.compare(date2) == .orderedDescending {
                                if overdue_tasks.count == 0 {
                                    overdue_tasks.append("Overdue")
                                }
                                overdue_tasks.append(task)
                            }
                            if date1.compare(date2) == .orderedSame {
                                if today_tasks.count == 0 {
                                    today_tasks.append("Today")
                                }
                                today_tasks.append(task)
                            }
                            if task.dueDate != nil && date1.compare(date2) == .orderedAscending && !date_list.contains(task.dueDate!) {
                                date_list.append(task.dueDate!)
                            }
                        }
                    }
                    for i in 0 ..< date_list.count {
                        future_tasks.append([])
                        for task in tasks! {
                            if task.dueDate != nil && task.dueDate == date_list[i] {
                                if future_tasks[i].count == 0 {
                                    dateFormatter.dateFormat = "yyyy-MM-dd"
                                    let date = date_list[i].utcToLocal(dateFormatter.dateFormat)
                                    dateFormatter.dateFormat = "MMMM d (E)"
                                    future_tasks[i].append(dateFormatter.string(from: date))
                                }
                                future_tasks[i].append(task)
                            }
                        }
                    }
                    
                    // Overdue Tasks
                    for task in overdue_tasks {
                        self.tasks.append(task)
                    }
                    // Today Tasks
                    for task in today_tasks {
                        self.tasks.append(task)
                    }
                    // Future Tasks
                    for part_list in future_tasks {
                        for task in part_list {
                            self.tasks.append(task)
                        }
                    }
                    
                    // Completed Tasks
                    for task in completed_tasks {
                        self.tasks.append(task)
                    }
                }else {
                    self.lblNoTasks.alpha = 1.0
                }
                self.tblTask.reloadData()
            }
        }
    }
    
    @IBAction func actionBack(_ sender: UIButton) {
        self.navigationController?.popViewController(animated: true)
    }
    
    @IBAction func actionContactDetail(_ sender: UIButton) {
        var siteUrl: String?
        if self.contact_object != nil {
            siteUrl = self.contact_object?.siteUrl
        }else {
            siteUrl = self.xaction_detail?.contact?.siteUrl
        }
        
        if URL(string: siteUrl ?? "") != nil {
            UIApplication.shared.open(URL(string: siteUrl ?? "")!, options: [:], completionHandler: nil)
        }
    }
    
    @IBAction func actionCreateTask(_ sender: UIButton) {
        let vc = self.storyboard?.instantiateViewController(withIdentifier: "EditTaskVC") as! EditTaskVC
        vc.task = nil
        self.navigationController?.pushViewController(vc, animated: true)
    }
    
}

extension TasksVC: UITableViewDelegate, UITableViewDataSource, TaskCellDelegate {
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return self.tasks.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let contCell = tableView.dequeueReusableCell(withIdentifier: "afCell") as! AFCell
        contCell.subviews.forEach { (view) in
            if view is TaskCell {
                view.removeFromSuperview()
            }
        }
        var cell: TaskCell?
        if self.tasks[indexPath.row] is String && self.tasks[indexPath.row] as! String != "Completed" {
            cell = TaskCell(frame: CGRect(x: 0, y: 0, width: self.tblTask.frame.width, height: 50))
            cell?.loadNib(0)
        }else {
            cell = TaskCell(frame: CGRect(x: 0, y: 0, width: self.tblTask.frame.width, height: 50))
            cell?.loadNib(3)
        }
        if self.tasks[indexPath.row] is Task {
            let task_instance = self.tasks[indexPath.row] as? Task
            let height: CGFloat = task_instance?.subject?.heightForView(UIFont(name: "Gordita-Medium", size: 14.0)!, self.view.frame.width - 80) ?? 35
            var dy: CGFloat = -10
            if height > 25 {
                dy = height * 1.5 - 30
            }
            if task_instance?.status == "OPEN" {
                cell = TaskCell(frame: CGRect(x: 0, y: 0, width: self.tblTask.frame.width, height: 105 + dy))
                cell?.loadNib(1)
            }else if task_instance?.status == "COMPLETE"{
                cell = TaskCell(frame: CGRect(x: 0, y: 0, width: self.tblTask.frame.width, height: 70 + dy))
                cell?.loadNib(4)
            }else {
                cell = TaskCell(frame: CGRect(x: 0, y: 0, width: self.tblTask.frame.width, height: 70 + dy))
                cell?.loadNib(2)
            }
        }
        cell?.task = self.tasks[indexPath.row]
        cell?.delegate = self
        contCell.addSubview(cell!)
        return contCell
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        if self.tasks[indexPath.row] is Task {
            let task_instance = self.tasks[indexPath.row] as? Task
            let height: CGFloat = task_instance?.subject?.heightForView(UIFont(name: "Gordita-Medium", size: 14.0)!, self.view.frame.width - 80) ?? 35
            var dy: CGFloat = -10
            if height > 25 {
                dy = height * 1.5 - 30
            }
            if task_instance?.status == "OPEN" {
                return 105 + dy
            }else {
                return 70 + dy
            }
        }else {
            return 50
        }
    }
    
    func removeTask(_ cell: TaskCell) {
        API.sharedInstance.api_complete_task((cell.task as! Task).taskId!)
        let indexPath = self.tblTask.indexPath(for: cell.superview as! UITableViewCell)
        if indexPath!.row + 1 < self.tasks.count && self.tasks[indexPath!.row + 1] is String && self.tasks[indexPath!.row - 1] is String {
            self.tasks.remove(at: indexPath!.row - 1)
            self.tasks.remove(at: indexPath!.row - 1)
            let prevInd = IndexPath(row: indexPath!.row - 1, section: indexPath!.section)
            self.tblTask.deleteRows(at: [prevInd, indexPath!], with: UITableView.RowAnimation.automatic)
        }else {
            self.tasks.remove(at: indexPath!.row)
            self.tblTask.deleteRows(at: [indexPath!], with: UITableView.RowAnimation.automatic)
        }
        DispatchQueue.main.asyncAfter(deadline: .now() + 1) {
            self.getContactTasks()
        }
    }
    
    func snoozeTask(_ cell: TaskCell) {
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "yyyy-MM-dd"
        let in_task = cell.task as! Task
        let indexPath = self.tblTask.indexPath(for: cell.superview as! UITableViewCell)
        if indexPath!.row + 1 < self.tasks.count && self.tasks[indexPath!.row + 1] is String && self.tasks[indexPath!.row - 1] is String {
            self.tasks.remove(at: indexPath!.row - 1)
            self.tasks.remove(at: indexPath!.row - 1)
        }else {
            self.tasks.remove(at: indexPath!.row)
        }
        var ind = 0
        for task in self.tasks {
            if task is Task {
                let tmp_task = task as! Task
                let date1 = dateFormatter.date(from: in_task.dueDate ?? "") ?? Date().utcToLocal(dateFormatter.dateFormat)
                let date2 = dateFormatter.date(from: tmp_task.dueDate ?? "") ?? Date().utcToLocal(dateFormatter.dateFormat)
                if date1.compare(date2) == .orderedSame || date1.compare(date2) == .orderedAscending {
                    var isExist: Bool = false
                    let dateFM = DateFormatter()
                    dateFM.dateFormat = "MMMM d (E)"
                    for task in self.tasks {
                        if task is String {
                            let dateStr = task as! String
                            if dateStr == dateFM.string(from: date1) {
                                isExist = true
                                break
                            }
                        }
                    }
                    if !isExist {
                        isExist = true
                        if self.tasks[ind - 1] is String {
                            self.tasks.insert(dateFM.string(from: date1), at: ind - 1)
                        }else {
                            self.tasks.insert(dateFM.string(from: date1), at: ind)
                            ind += 1
                        }
                    }
                    self.tasks.insert(in_task, at: ind)
                    break
                }
            }
            ind += 1
        }
        self.tblTask.reloadData()
//        let indPath = IndexPath(row: ind - 1, section: 0)
        //        let cellRect = self.tblTask.rectForRow(at: indPath)
        //        if !self.tblTask.bounds.contains(cellRect) {
//        self.tblTask.scrollToRow(at: indPath, at: .top, animated: false)
        //        }
//        self.tblTask.scrollToRow(at: indexPath!, at: .top, animated: false)
    }
}
