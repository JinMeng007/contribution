//
//  XActivityImportVC.swift
//  AFrame
//
//  Created by Lee Sheng Jin on 2019/3/10.
//  Copyright © 2019 DrawRanger. All rights reserved.
//

import UIKit

class XActivityImportVC: BaseViewController {
    
    @IBOutlet weak var txtFeedback: UITextView!
    @IBOutlet weak var txtShowingDate: UITextField!
    @IBOutlet weak var txtShowingTime: UITextField!
    @IBOutlet weak var switchRepeating: AFSwitch!
    @IBOutlet weak var switchNoShow: AFSwitch!
    
    var activity: XAIDetail?
    var timePV: TDPicker!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.initView()
    }
    
    func initView() {
        if activity?.feedback == nil || activity?.feedback == "" {
            self.txtFeedback.placeholder = "Feedback"
        }else {
            self.txtFeedback.text = activity?.feedback
        }
        self.txtShowingTime.text = activity?.showTime
        switchRepeating.setOn(activity?.isSecondShowing ?? false, animated: false)
        switchNoShow.setOn(activity?.isNoShow ?? false, animated: false)
        
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "yyyy-MM-dd"
        
        let dateStr = activity?.activityDate
        
        if dateStr != nil && dateStr != "" {
            let activityDate = dateStr!.utcToLocal(dateFormatter.dateFormat)
            dateFormatter.dateFormat = "MMM d, yyyy"
            self.self.txtShowingDate.text = dateFormatter.string(from: activityDate)
        }else {
            dateFormatter.dateFormat = "MMM d, yyyy"
            self.self.txtShowingDate.text = dateFormatter.string(from: Date().utcToLocal(dateFormatter.dateFormat))
        }
        
        let datePV = UIDatePicker()
        datePV.datePickerMode = .date
        txtShowingDate.inputView = datePV
        datePV.addTarget(self, action: #selector(self.setDate(sender:)), for: .valueChanged)
        
        self.timePV = TDPicker(frame: CGRect(x: 0, y: self.view.frame.height, width: self.view.frame.width, height: 240))
        self.timePV.td_delegate = self
        self.view.addSubview(self.timePV)
    }
    
    @objc func setDate(sender: UIDatePicker) {
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "MMM d, yyyy"
        txtShowingDate.text = dateFormatter.string(from: sender.date)
    }
    
    @IBAction func actionBack(_ sender: UIButton) {
        if sender.tag == 100 {
            var param: [String: Any] = [
                "feedback": txtFeedback.text!,
                "showTime": txtShowingTime.text!,
                "isSecondShowing": switchRepeating.isOn,
                "isNoShow": switchNoShow.isOn
            ]
            if txtShowingDate.text != "" {
                let dateFormatter = DateFormatter()
                dateFormatter.dateFormat = "MMM d, yyyy"
                let dueDate = self.txtShowingDate.text!.utcToLocal(dateFormatter.dateFormat)
                dateFormatter.dateFormat = "yyyy-MM-dd"
                param.updateValue(dateFormatter.string(from: dueDate), forKey: "activityDate")
            }
            API.sharedInstance.api_xactionactivity_import_patch(activity!.xactionActivityImportId!, param)
        }
        self.navigationController?.popViewController(animated: true)
    }
    
    @IBAction func actionShowTimePicker(_ sender: UIButton) {
        self.view.endEditing(true)
        UIView.animate(withDuration: 0.3, delay: 0.0, options: .curveEaseOut, animations: {
            self.timePV.transform = CGAffineTransform(translationX: 0, y: -240)
        }, completion: { (finished: Bool) in
            
        })
    }
    
}

extension XActivityImportVC: TDPickerDelegate {
    func setTimeDuration(_ result: String) {
        self.txtShowingTime.text = result
    }
}
