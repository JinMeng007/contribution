//
//  TransactionsVC.swift
//  AFrame
//
//  Created by Lee Sheng Jin on 2019/2/13.
//  Copyright © 2019 DrawRanger. All rights reserved.
//

import UIKit

class TransactionsVC: BaseViewController {

    @IBOutlet weak var scrView: UIScrollView!
    @IBOutlet weak var lblName: UILabel!
    
    var contact_xactions: [Transaction] = []
    var contact_object: ContactDetail?
    
    let refreshCtrl: UIRefreshControl = UIRefreshControl()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.lblName.text = self.contact_object?.displayFirstLast
        refreshCtrl.frame = CGRect(x: 0, y: 50, width: refreshCtrl.frame.width, height: refreshCtrl.frame.height)
        refreshCtrl.tintColor = UIColor(red: 200 / 255, green: 200 / 255, blue: 200 / 255, alpha: 1.0)
        refreshCtrl.addTarget(self, action: #selector(self.getContactXactions), for: .valueChanged)
        self.scrView.refreshControl = refreshCtrl
        self.getContactXactions()
    }
    
    @objc func getContactXactions() {
//        self.showHUD()
        API.sharedInstance.api_get_contact_xactions(self.contact_object!.contactId!) { (contact_xactions) in
            DispatchQueue.main.async {
                self.refreshCtrl.endRefreshing()
//                self.hideHUD()
                self.contact_xactions = contact_xactions ?? []
                self.drawCells()
            }
        }
    }
    
    func drawCells() {
        var cell: TransactionCell?
        var last_cell: TransactionCell?
        var offset_y: CGFloat = 61.0
        self.scrView.subviews.forEach { (view) in
            if view is TransactionCell {
                view.removeFromSuperview()
            }
        }
        for xaction in self.contact_xactions {
            if last_cell != nil {
                offset_y = last_cell!.frame.origin.y + last_cell!.frame.height
            }
            cell = TransactionCell(frame: CGRect(x: 0, y: offset_y, width: scrView.frame.width, height: 120))
            cell?.transaction = xaction
            last_cell = cell
            self.scrView.addSubview(cell!)
            self.scrView.contentSize = CGSize(width: 0, height: last_cell!.frame.origin.y + last_cell!.frame.height)
        }
    }
    
    @IBAction func actionBack(_ sender: UIButton) {
        self.navigationController?.popViewController(animated: true)
    }
    
    @IBAction func actionContactDetailEdit(_ sender: UIButton) {
//        if URL(string: APIURL.contact_detail_edit.appending("\(self.contact_object?.contactId ?? 0)")) != nil {
//            UIApplication.shared.open(URL(string: APIURL.contact_detail_edit.appending("\(self.contact_object?.contactId ?? 0)"))!, options: [:], completionHandler: nil)
//        }
        if URL(string: self.contact_object?.siteUrl ?? "") != nil {
            UIApplication.shared.open(URL(string: self.contact_object?.siteUrl ?? "")!, options: [:], completionHandler: nil)
        }
    }
    
}
