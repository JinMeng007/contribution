//
//  NotesVC.swift
//  AFrame
//
//  Created by Lee Sheng Jin on 2019/2/13.
//  Copyright © 2019 DrawRanger. All rights reserved.
//

import UIKit

class NotesVC: BaseViewController {
    
    @IBOutlet weak var tblNotes: UITableView!
    @IBOutlet weak var lblName: UILabel!
    @IBOutlet weak var lblNoNotes: UILabel!
    
    var note_arr: [Note] = []
    var contact_object: ContactDetail?
    
    let refreshCtrl: UIRefreshControl = UIRefreshControl()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.lblName.text = self.contact_object?.displayFirstLast
        self.tblNotes.delegate = self
        self.tblNotes.dataSource = self
        self.tblNotes.allowsSelection = false
        self.tblNotes.separatorStyle = .none
        tblNotes.register(UINib(nibName: "AFCell", bundle: nil), forCellReuseIdentifier: "afCell")
        refreshCtrl.frame = CGRect(x: 0, y: 50, width: refreshCtrl.frame.width, height: refreshCtrl.frame.height)
        refreshCtrl.tintColor = UIColor(red: 200 / 255, green: 200 / 255, blue: 200 / 255, alpha: 1.0)
        refreshCtrl.addTarget(self, action: #selector(self.getContactNotes), for: .valueChanged)
        self.tblNotes.refreshControl = refreshCtrl
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        self.getContactNotes()
    }
    
    @objc func getContactNotes() {
//        self.showHUD()
        API.sharedInstance.api_contact_notes(self.contact_object!.contactId!) { (notes) in
            DispatchQueue.main.async {
//                self.hideHUD()
                self.refreshCtrl.endRefreshing()
                self.note_arr = notes ?? []
                if self.note_arr.count == 0 {
                    self.lblNoNotes.alpha = 1.0
                }else {
                    self.lblNoNotes.alpha = 0.0
                }
                self.tblNotes.reloadData()
            }
        }
    }
    
    @IBAction func actionBack(_ sender: UIButton) {
        self.navigationController?.popViewController(animated: true)
    }
    
    @IBAction func actionGotoDetail(_ sender: UIButton) {
//        if URL(string: APIURL.contact_detail_edit.appending("\(self.contact_object?.contactId ?? 0)")) != nil {
//            UIApplication.shared.open(URL(string: APIURL.contact_detail_edit.appending("\(self.contact_object?.contactId ?? 0)"))!, options: [:], completionHandler: nil)
//        }
        if URL(string: self.contact_object?.siteUrl ?? "") != nil {
            UIApplication.shared.open(URL(string: self.contact_object?.siteUrl ?? "")!, options: [:], completionHandler: nil)
        }
    }
    
    @IBAction func actionCreateContactNote(_ sender: UIButton) {
        let vc = self.storyboard?.instantiateViewController(withIdentifier: "EditContactNoteVC") as! EditContactNoteVC
        vc.note = nil
        vc.contact_object = self.contact_object
        self.navigationController?.pushViewController(vc, animated: true)
    }
    
}

extension NotesVC: UITableViewDelegate, UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return self.note_arr.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let noteCell = tableView.dequeueReusableCell(withIdentifier: "afCell") as! AFCell
        noteCell.subviews.forEach { (view) in
            if view is NoteCell {
                view.removeFromSuperview()
            }
        }
        let note = note_arr[indexPath.row]
        var cell: NoteCell?
        var extra_height: CGFloat = 0
        var labelHeight = note.note?.heightForView(UIFont(name: "Gordita-Medium", size: 14.0)!, self.tblNotes.frame.width) ?? 45
        labelHeight = labelHeight + (labelHeight / 3)
        if labelHeight > 45 {
            extra_height = labelHeight
        }
        if note.fileName != nil && note.fileName != "" {
            cell = NoteCell(frame: CGRect(x: 0, y: 0, width: self.tblNotes.frame.width, height: 115 + extra_height))
            cell?.loadNib(1)
        }else {
            cell = NoteCell(frame: CGRect(x: 0, y: 0, width: self.tblNotes.frame.width, height: 80 + extra_height))
            cell?.loadNib(0)
        }
        cell?.note = note
        cell?.contact_object = self.contact_object
        noteCell.addSubview(cell!)
        return noteCell
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        let note = note_arr[indexPath.row]
        var extra_height: CGFloat = 0
        var labelHeight = note.note?.heightForView(UIFont(name: "Gordita-Medium", size: 14.0)!, self.tblNotes.frame.width) ?? 45
        labelHeight = labelHeight + (labelHeight / 3)
        if labelHeight > 45 {
            extra_height = labelHeight
        }
        if note_arr[indexPath.row].fileName != nil && note_arr[indexPath.row].fileName != "" {
            return 115 + extra_height
        }else {
            return 80 + extra_height
        }
    }
    
    func tableView(_ tableView: UITableView, leadingSwipeActionsConfigurationForRowAt indexPath: IndexPath) -> UISwipeActionsConfiguration? {
        return UISwipeActionsConfiguration(actions: [])
    }
    
    func tableView(_ tableView: UITableView, trailingSwipeActionsConfigurationForRowAt indexPath: IndexPath) -> UISwipeActionsConfiguration? {
        let deleteAction = UIContextualAction(style: .normal, title: "Delete") { (action, view, success:(Bool) -> Void) in
            DispatchQueue.main.async {
                API.sharedInstance.api_delete_note(self.note_arr[indexPath.row].contactNoteId ?? 0)
                self.note_arr.remove(at: indexPath.row)
                self.tblNotes.deleteRows(at: [indexPath], with: UITableView.RowAnimation.automatic)
            }
        }
        deleteAction.backgroundColor = UIColor.red
        return UISwipeActionsConfiguration(actions: [deleteAction])
    }
    
}
