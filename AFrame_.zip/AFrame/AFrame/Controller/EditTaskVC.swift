//
//  EditTaskVC.swift
//  AFrame
//
//  Created by Lee Sheng Jin on 2019/2/13.
//  Copyright © 2019 DrawRanger. All rights reserved.
//

import UIKit
import DropDown

class EditTaskVC: BaseViewController {
    
    @IBOutlet weak var scrView: UIScrollView!
    @IBOutlet weak var taskSegment: UISegmentedControl!
    @IBOutlet weak var txtTaskCont: UITextView!
    @IBOutlet weak var statusIcon: UILabel!
    @IBOutlet weak var btnStatus: UIButton!
    @IBOutlet weak var txtNote: UITextView!
    @IBOutlet weak var switchProsp: AFSwitch!
    @IBOutlet weak var txtDueDate: UITextField!
    @IBOutlet weak var txtReminderDT: UITextField!
    @IBOutlet weak var txtCompleteDate: UITextField!
    @IBOutlet weak var txtToUser: UITextField!
    @IBOutlet weak var txtWithUser: UITextField!
    @IBOutlet weak var txtEndRepeat: UITextField!
    @IBOutlet weak var btnFrequency: UIButton!
    @IBOutlet weak var recurView: UIView!
    @IBOutlet var recurItems: [UIView]!
    
    // Daily Recurring
    @IBOutlet weak var txtDDay: UITextField!
    
    // Weekly Recurring
    @IBOutlet weak var txtWDay: UITextField!
    @IBOutlet weak var btnWDate: UIButton!
    
    // Monthly Recurring
    @IBOutlet weak var txtMDay: UITextField!
    @IBOutlet weak var btnMDay: UIButton!
    
    // Yearly Recurring
    @IBOutlet weak var txtYDay: UITextField!
    @IBOutlet weak var btnYM: UIButton!
    @IBOutlet weak var btnYD: UIButton!
    
    var task: TaskDetail?
    let statusDropDown = DropDown()
    let frequencyDropDown = DropDown()
    let dateDropDown = DropDown()
    let mdayDropDown = DropDown()
    let ymdayDropDown = DropDown()
    let monthDropDown = DropDown()
    lazy var dropDowns: [DropDown] = {
        return [
            self.statusDropDown,
            self.frequencyDropDown,
            self.dateDropDown,
            self.mdayDropDown,
            self.ymdayDropDown,
            self.monthDropDown
        ]
    }()
    let statusOptions: [String] = ["Open", "In Progress", "Complete"]
    let frequencyOptions: [String] = ["-- Frequency --", "Daily", "Weekly", "Monthly", "Yearly"]
    var days: [String] = []
    let dates: [String] = ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"]
    let months: [String] = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"]
    
    override func viewDidLoad() {
        super.viewDidLoad()
        scrView.contentSize = CGSize(width: 0, height: 640)
        let attrs: [NSAttributedString.Key : Any] = [NSAttributedString.Key.font: UIFont(name: "FontAwesome5ProLight", size: 14)!]
        taskSegment.setTitleTextAttributes(attrs, for: .normal)
        
        for i in 0 ..< 31 {
            self.days.append("\(i + 1)")
        }
        
        if self.task == nil {
            self.task = TaskDetail([:])
            self.task?.status = "OPEN"
            self.task?.taskType = "TODO"
        }else {
            switch task?.taskType {
            case "LETTER":
                self.taskSegment.selectedSegmentIndex = 2
                break
            case "EMAIL":
                self.taskSegment.selectedSegmentIndex = 3
                break
            case "PHONE":
                self.taskSegment.selectedSegmentIndex = 1
                break
            default:
                self.taskSegment.selectedSegmentIndex = 0
                break
            }
            
            self.txtToUser.text = self.task?.appUser?.displayFirstLast
            self.txtWithUser.text = self.task?.contact?.displayFirstLast
            self.txtTaskCont.text = self.task?.subject
            if self.task?.recurringFrequency == nil || self.task?.recurringFrequency == "" {
                self.btnFrequency.setTitle("-- Frequency --", for: .normal)
            }else {
                self.btnFrequency.setTitle(self.task?.recurringFrequency?.capitalized, for: .normal)
            }
            switch task?.status {
            case "OPEN":
                self.btnStatus.setTitle("Open", for: .normal)
                self.statusIcon.textColor = APP_GREEN_COLOR
                break
            case "IN_PROGRESS":
                self.btnStatus.setTitle("In Progress", for: .normal)
                self.statusIcon.textColor = APP_ORANGE_COLOR
                break
            case "COMPLETE":
                self.btnStatus.setTitle("Complete", for: .normal)
                self.statusIcon.textColor = APP_BLUE_COLOR
                break
            default:
                self.btnStatus.setTitle("Open", for: .normal)
                self.statusIcon.textColor = APP_GREEN_COLOR
                break
            }
            if self.task?.note == nil || self.task?.note == "" {
                self.txtNote.placeholder = "Note"
            }else {
                self.txtNote.text = self.task?.note
            }
            
            let dateFormatter = DateFormatter()
            dateFormatter.dateFormat = "yyyy-MM-dd"
            
            if task?.dueDate != nil && task?.dueDate != "" {
                let dueDate = self.task?.dueDate?.utcToLocal(dateFormatter.dateFormat)
                dateFormatter.dateFormat = "MMM d, yyyy"
                self.txtDueDate.text = dateFormatter.string(from: dueDate ?? Date())
            }else {
                dateFormatter.dateFormat = "MMM d, yyyy"
                self.txtDueDate.text = dateFormatter.string(from: Date().utcToLocal(dateFormatter.dateFormat))
            }
            dateFormatter.dateFormat = "yyyy-MM-dd"
            if task?.status == "COMPLETE" {
                txtCompleteDate.alpha = 1.0
                if task?.completeDate != nil && task?.completeDate != "" {
                    let dueDate = self.task?.completeDate?.utcToLocal(dateFormatter.dateFormat)
                    dateFormatter.dateFormat = "MMMM d, yyyy"
                    self.txtCompleteDate.text = dateFormatter.string(from: dueDate ?? Date())
                }else {
                    dateFormatter.dateFormat = "MMMM d, yyyy"
                    self.txtCompleteDate.text = dateFormatter.string(from: Date().utcToLocal(dateFormatter.dateFormat))
                }
            }
            
            dateFormatter.dateFormat = "yyyy-MM-dd"
            if task?.recurringEndDate == "COMPLETE" {
                if task?.recurringEndDate != nil && task?.recurringEndDate != "" {
                    let dueDate = self.task?.recurringEndDate?.utcToLocal(dateFormatter.dateFormat)
                    dateFormatter.dateFormat = "MMMM d, yyyy"
                    self.txtEndRepeat.text = dateFormatter.string(from: dueDate ?? Date())
                }else {
                    dateFormatter.dateFormat = "MMMM d, yyyy"
                    self.txtEndRepeat.text = dateFormatter.string(from: Date().utcToLocal(dateFormatter.dateFormat))
                }
            }
            
            txtReminderDT.text = self.task?.reminderDate
        }
        
        let datePV = UIDatePicker()
        datePV.datePickerMode = .date
        txtDueDate.inputView = datePV
        datePV.addTarget(self, action: #selector(self.setDueDate(sender:)), for: .valueChanged)
        
        let datePVComplete = UIDatePicker()
        datePVComplete.datePickerMode = .date
        txtCompleteDate.inputView = datePVComplete
        datePVComplete.addTarget(self, action: #selector(self.setCompleteDate(sender:)), for: .valueChanged)
        
        let datePVER = UIDatePicker()
        datePVER.datePickerMode = .date
        txtEndRepeat.inputView = datePVER
        datePVER.addTarget(self, action: #selector(self.setERDate(sender:)), for: .valueChanged)
        
        let dateTimePV = UIDatePicker()
        dateTimePV.datePickerMode = .dateAndTime
        txtReminderDT.inputView = dateTimePV
        dateTimePV.addTarget(self, action: #selector(self.setReminderDT(sender:)), for: .valueChanged)
        
        self.customizeDropDown(self)
        statusDropDown.anchorView = btnStatus
        self.statusDropDown.dataSource = self.statusOptions
        statusDropDown.bottomOffset = CGPoint(x: -40, y: btnStatus.bounds.height)
        statusDropDown.width = btnStatus.bounds.width + 40
        statusDropDown.selectionAction = { [unowned self] (index, item) in
            DispatchQueue.main.async {
                switch index {
                case 0:
                    self.txtCompleteDate.alpha = 0.0
                    self.task?.status = "OPEN"
                    self.btnStatus.setTitle("Open", for: .normal)
                    self.statusIcon.textColor = APP_GREEN_COLOR
                    break
                case 1:
                    self.txtCompleteDate.alpha = 0.0
                    self.task?.status = "IN_PROGRESS"
                    self.btnStatus.setTitle("In Progress", for: .normal)
                    self.statusIcon.textColor = APP_ORANGE_COLOR
                    break
                case 2:
                    self.txtCompleteDate.alpha = 1.0
                    self.task?.status = "COMPLETE"
                    self.btnStatus.setTitle("Complete", for: .normal)
                    self.statusIcon.textColor = APP_BLUE_COLOR
                    break
                default:
                    self.txtCompleteDate.alpha = 0.0
                    self.btnStatus.setTitle("Open", for: .normal)
                    self.statusIcon.textColor = APP_GREEN_COLOR
                    break
                }
            }
        }
        
        frequencyDropDown.anchorView = btnFrequency
        self.frequencyDropDown.dataSource = self.frequencyOptions
        frequencyDropDown.bottomOffset = CGPoint(x: -40, y: btnFrequency.bounds.height)
        frequencyDropDown.width = btnFrequency.bounds.width
        frequencyDropDown.selectionAction = { [unowned self] (index, item) in
            DispatchQueue.main.async {
                self.btnFrequency.setTitle(self.frequencyOptions[index], for: .normal)
                switch index {
                case 1:
                    if self.task?.taskId == nil {
                        self.txtDDay.text = ""
                    }else {
                        self.txtDDay.text = "\(self.task?.recurringSeparationCount ?? 1)"
                    }
                    break
                case 2:
                    if self.task?.taskId == nil {
                        self.txtWDay.text = ""
                        self.btnWDate.setTitle("Monday", for: .normal)
                    }else {
                        self.txtWDay.text = "\(self.task?.recurringSeparationCount ?? 1)"
                        self.btnWDate.setTitle(self.task?.recurringDayOfWeek ?? "Monday", for: .normal)
                    }
                    break
                case 3:
                    if self.task?.taskId == nil {
                        self.txtMDay.text = ""
                        self.btnMDay.setTitle("1", for: .normal)
                    }else {
                        self.txtMDay.text = "\(self.task?.recurringSeparationCount ?? 1)"
                        self.btnMDay.setTitle("\(self.task?.recurringDayOfMonth ?? 1)", for: .normal)
                    }
                    break
                case 4:
                    if self.task?.taskId == nil {
                        self.txtYDay.text = ""
                        self.btnYM.setTitle("Jan", for: .normal)
                        self.btnYD.setTitle("1", for: .normal)
                    }else {
                        self.txtYDay.text = "\(self.task?.recurringSeparationCount ?? 1)"
                        self.btnYM.setTitle("\(self.task?.recurringMonthOfYear ?? "Jan")", for: .normal)
                        self.btnYD.setTitle("\(self.task?.recurringDayOfMonth ?? 1)", for: .normal)
                    }
                    break
                default:
                    break
                }
                if index != 0 {
                    self.recurItems[index - 1].alpha = 1.0
                    self.recurView.fadeIn(completion: { (success) in
                        
                    })
                }
            }
        }
        
        dateDropDown.anchorView = btnWDate
        dateDropDown.dataSource = self.dates
        dateDropDown.bottomOffset = CGPoint(x: 0, y: btnWDate.bounds.height)
        dateDropDown.width = btnWDate.bounds.width
        dateDropDown.selectionAction = { [unowned self] (index, item) in
            DispatchQueue.main.async {
                self.btnWDate.setTitle(self.dates[index], for: .normal)
            }
        }
        
        mdayDropDown.anchorView = btnMDay
        mdayDropDown.dataSource = self.days
        mdayDropDown.bottomOffset = CGPoint(x: 0, y: btnMDay.bounds.height)
        mdayDropDown.width = btnMDay.bounds.width
        mdayDropDown.selectionAction = { [unowned self] (index, item) in
            DispatchQueue.main.async {
                self.btnMDay.setTitle(self.days[index], for: .normal)
            }
        }
        
        ymdayDropDown.anchorView = btnYD
        ymdayDropDown.dataSource = self.days
        ymdayDropDown.bottomOffset = CGPoint(x: 0, y: btnYD.bounds.height)
        ymdayDropDown.width = btnYD.bounds.width
        ymdayDropDown.selectionAction = { [unowned self] (index, item) in
            DispatchQueue.main.async {
                self.btnYD.setTitle(self.days[index], for: .normal)
            }
        }
        
        monthDropDown.anchorView = btnYM
        monthDropDown.dataSource = self.months
        monthDropDown.bottomOffset = CGPoint(x: 0, y: btnYM.bounds.height)
        monthDropDown.width = btnYM.bounds.width
        monthDropDown.selectionAction = { [unowned self] (index, item) in
            DispatchQueue.main.async {
                self.btnYM.setTitle(self.months[index], for: .normal)
            }
        }
    }
    
    @IBAction func actionStatus(_ sender: UIButton) {
        self.view.endEditing(true)
        statusDropDown.show()
    }
    
    @IBAction func actionFrequency(_ sender: UIButton) {
        self.view.endEditing(true)
        frequencyDropDown.show()
    }
    
    @objc func setDueDate(sender: UIDatePicker) {
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "MMM d, yyyy"
        txtDueDate.text = dateFormatter.string(from: sender.date)
    }
    
    @objc func setCompleteDate(sender: UIDatePicker) {
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "MMMM d, yyyy"
        txtCompleteDate.text = dateFormatter.string(from: sender.date)
    }
    
    @objc func setERDate(sender: UIDatePicker) {
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "MMMM d, yyyy"
        txtEndRepeat.text = dateFormatter.string(from: sender.date)
    }
    
    @objc func setReminderDT(sender: UIDatePicker) {
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "MMM d, yyyy HH:MM a"
        txtReminderDT.text = dateFormatter.string(from: sender.date)
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        if self.appDelegate.selected_appUser != nil {
            if self.appDelegate.selection_type == "AssignTo" {
                self.task?.appUserId = self.appDelegate.selected_appUser?.appUserId
                self.txtToUser.text = self.appDelegate.selected_appUser?.displayFirstLast
            }else {
                self.task?.contactId = self.appDelegate.selected_appUser?.appUserId
                self.txtWithUser.text = self.appDelegate.selected_appUser?.displayFirstLast
            }
        }
    }
    
    @IBAction func actionBack(_ sender: UIButton) {
        self.appDelegate.selected_appUser = nil
        self.navigationController?.popViewController(animated: true)
    }
    
    @IBAction func actionSave(_ sender: UIButton) {
        if task?.status == "COMPLETE" && txtCompleteDate.text == "" {
            self.alertViewController(title: "Oops!", message: "Please input Task Complete Date.")
        }else {
            var param: [String: Any] = [
                "appUserId": self.task?.appUserId ?? NSNull(),
                "contactId": self.task?.contactId ?? NSNull(),
                "subject": self.txtTaskCont.text!,
                "note": self.txtNote.text!,
                "status": task!.status!,
                "taskType": task!.taskType!,
                "isProspecting": switchProsp.isOn
            ]
            if txtDueDate.text != "" {
                let dateFormatter = DateFormatter()
                dateFormatter.dateFormat = "MMM d, yyyy"
                let dueDate = self.txtDueDate.text!.utcToLocal(dateFormatter.dateFormat)
                dateFormatter.dateFormat = "yyyy-MM-dd"
                param.updateValue(dateFormatter.string(from: dueDate), forKey: "dueDate")
            }
            if txtCompleteDate.text != "" && task!.status! == "COMPLETE" {
                let dateFormatter = DateFormatter()
                dateFormatter.dateFormat = "MMMM d, yyyy"
                let dueDate = self.txtCompleteDate.text!.utcToLocal(dateFormatter.dateFormat)
                dateFormatter.dateFormat = "yyyy-MM-dd"
                param.updateValue(dateFormatter.string(from: dueDate), forKey: "completeDate")
            }
            if txtReminderDT.text != "" {
                param.updateValue(txtReminderDT.text!, forKey: "reminderDate")
            }
            if task?.recurringFrequency != nil && task?.recurringFrequency != "" {
                let dateFormatter = DateFormatter()
                dateFormatter.dateFormat = "MMMM d, yyyy"
                let dueDate = self.txtEndRepeat.text!.utcToLocal(dateFormatter.dateFormat)
                dateFormatter.dateFormat = "yyyy-MM-dd"
                param.updateValue(dateFormatter.string(from: dueDate), forKey: "completeDate")
            }
            if self.btnFrequency.titleLabel?.text != "-- Frequency --" {
    
                if btnFrequency.titleLabel?.text == "Daily" {
                    param.updateValue("DAILY", forKey: "recurringFrequency")
                    param.updateValue(Int(self.txtDDay.text!)!, forKey: "recurringSeparationCount")
                }
                if btnFrequency.titleLabel?.text == "Weekly" {
                    param.updateValue("WEEKLY", forKey: "recurringFrequency")
                    param.updateValue(Int(self.txtWDay.text!)!, forKey: "recurringSeparationCount")
                    param.updateValue(self.btnWDate.titleLabel!.text!.uppercased(), forKey: "recurringDayOfWeek")
                }
                if btnFrequency.titleLabel?.text == "Monthly" {
                    param.updateValue("MONTHLY", forKey: "recurringFrequency")
                    param.updateValue(Int(self.txtMDay.text!)!, forKey: "recurringSeparationCount")
                    param.updateValue(Int(self.btnMDay.titleLabel!.text!)!, forKey: "recurringDayOfMonth")
                }
                if btnFrequency.titleLabel?.text == "Yearly" {
                    param.updateValue("YEARLY", forKey: "recurringFrequency")
                    param.updateValue(Int(self.txtYDay.text!)!, forKey: "recurringSeparationCount")
                    param.updateValue(self.btnYM.titleLabel!.text!.monthFullWord(), forKey: "recurringMonthOfYear")
                    param.updateValue(Int(self.btnYD.titleLabel!.text!)!, forKey: "recurringDayOfMonth")
                }
                param.updateValue(true, forKey: "isRecurring")
                param.updateValue(true, forKey: "recurring")
            }
            if task?.taskId == nil {
                API.sharedInstance.api_create_task(param)
            }else {
                API.sharedInstance.api_patch_task(param, task!.taskId!)
            }
            self.appDelegate.selected_appUser = nil
            self.navigationController?.popViewController(animated: true)
        }
    }
    
    @IBAction func actionWDay(_ sender: UIButton) {
        self.view.endEditing(true)
        dateDropDown.show()
    }
    
    @IBAction func actionMDay(_ sender: UIButton) {
        self.view.endEditing(true)
        mdayDropDown.show()
    }
    
    @IBAction func actionYM(_ sender: UIButton) {
        self.view.endEditing(true)
        monthDropDown.show()
    }
    
    @IBAction func actionYD(_ sender: UIButton) {
        self.view.endEditing(true)
        ymdayDropDown.show()
    }
    
    
    func customizeDropDown(_ sender: AnyObject) {
        DropDown.setupDefaultAppearance()
        
        dropDowns.forEach {
            $0.cellNib = UINib(nibName: "DropDownCell", bundle: Bundle(for: DropDownCell.self))
            $0.cellHeight = 35
            $0.customCellConfiguration = nil
        }
    }
    
    @IBAction func actionChangeType(_ sender: UISegmentedControl) {
        switch sender.selectedSegmentIndex {
        case 0:
            task?.taskType = "TODO"
            break
        case 1:
            task?.taskType = "PHONE"
            break
        case 2:
            task?.taskType = "LETTER"
            break
        default:
            task?.taskType = "EMAIL"
            break
        }
    }
    
    @IBAction func actionSelectUser(_ sender: UIButton) {
        let vc = self.storyboard?.instantiateViewController(withIdentifier: "UsersVC") as! UsersVC
        if sender.tag == 100 {
            self.appDelegate.selection_type = "AssignTo"
            self.showHUD()
            API.sharedInstance.api_active_app_users(task?.appUserId ?? User.sharedInstance.appUserId!) { (appUsers) in
                DispatchQueue.main.async {
                    self.hideHUD()
                    if appUsers != nil {
                        vc.appUsers = appUsers!
                        self.present(vc, animated: true, completion: nil)
                    }
                }
            }
        }else {
            self.appDelegate.selection_type = "AssignWith"
            self.showHUD()
            API.sharedInstance.api_active_app_users(task?.contactId ?? User.sharedInstance.appUserId!) { (appUsers) in
                DispatchQueue.main.async {
                    self.hideHUD()
                    if appUsers != nil {
                        vc.appUsers = appUsers!
                        self.present(vc, animated: true, completion: nil)
                    }
                }
            }
        }
    }
    
    @IBAction func actionDone(_ sender: UIButton) {
        var errMsg: String = ""
        switch sender.tag - 200 {
        case 0:
            if txtDDay.text == "" {
                errMsg = "Please input Separation Days."
            }
            break
        case 1:
            if txtWDay.text == "" {
                errMsg = "Please input Separation Days."
            }
            break
        case 2:
            if txtMDay.text == "" {
                errMsg = "Please input Separation Days."
            }
            break
        default:
            if txtYDay.text == "" {
                errMsg = "Please input Separation Days."
            }
            break
        }
        if errMsg == "" {
            self.recurView.fadeOut { (success) in
                DispatchQueue.main.async {
                    for view in self.recurItems {
                        view.alpha = 0.0
                    }
                }
            }
        }else {
            self.alertViewController(title: "Oops!", message: errMsg)
        }
    }
    
}
