//
//  ContactDetailVC.swift
//  AFrame
//
//  Created by Lee Sheng Jin on 2019/2/13.
//  Copyright © 2019 DrawRanger. All rights reserved.
//

import UIKit
import Contacts
import ContactsUI

class ContactDetailVC: BaseViewController {
    
    @IBOutlet weak var cdTbl: UITableView!
    
    var header_str: [String] = ["", "Transactions", "Notes", "Tasks", "Mailing Addresses", "Other Details", "Categories", "Owners"]
    var header_expanded: [Bool] = [false, false, false, false, false, false, false, false]
    var cell_norm_heights: [CGFloat] = [385, 60, 60, 60, 60, 60, 60, 60]
    var cell_expand_heights: [CGFloat] = [385, 60, 60, 60, 215, 174, 110, 110]
    
    var contact_object: ContactDetail?
    let refreshCtrl: UIRefreshControl = UIRefreshControl()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.initView()
    }
    
    func initView() {
        self.cdTbl.delegate = self
        self.cdTbl.dataSource = self
        self.cdTbl.separatorStyle = .none
        self.cdTbl.allowsSelection = false
        self.cdTbl.showsVerticalScrollIndicator = false
        if self.contact_object?.xactionCount != nil && self.contact_object?.xactionCount != 0 {
            self.header_str[1] = "\(self.contact_object?.xactionCount ?? 0) Transactions"
        }
        refreshCtrl.frame = CGRect(x: 0, y: 50, width: refreshCtrl.frame.width, height: refreshCtrl.frame.height)
        refreshCtrl.tintColor = UIColor(red: 200 / 255, green: 200 / 255, blue: 200 / 255, alpha: 1.0)
        refreshCtrl.addTarget(self, action: #selector(self.getDetails), for: .valueChanged)
        self.cdTbl.refreshControl = refreshCtrl
    }
    
    @objc func getDetails() {
        API.sharedInstance.api_contact(contact_object?.contactId ?? 0) { (contact_detail) in
            DispatchQueue.main.async {
                self.refreshCtrl.endRefreshing()
                if contact_detail != nil {
                    self.contact_object = contact_detail
                    self.cdTbl.reloadData()
                }
            }
        }
    }
    
    @IBAction func actionBack(_ sender: UIButton) {
        self.navigationController?.popViewController(animated: true)
    }
    
    @IBAction func actionContactEdit(_ sender: UIButton) {
//        if URL(string: APIURL.contact_detail_edit.appending("\(self.contact_object?.contactId ?? 0)")) != nil {
//            UIApplication.shared.open(URL(string: APIURL.contact_detail_edit.appending("\(self.contact_object?.contactId ?? 0)"))!, options: [:], completionHandler: nil)
//        }
        if URL(string: self.contact_object?.siteUrl ?? "") != nil {
            UIApplication.shared.open(URL(string: self.contact_object?.siteUrl ?? "")!, options: [:], completionHandler: nil)
        }
    }
    
}

extension ContactDetailVC: CDBtmCellDelegate, UITableViewDataSource, UITableViewDelegate {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 8
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        if indexPath.row == 0 {
            let cell = tableView.dequeueReusableCell(withIdentifier: "headerCell") as! CDHeaderCell
            cell.contentWidth = self.view.frame.width
            if self.contact_object != nil {
                cell.contact_object = self.contact_object
            }
            cell_norm_heights[0] = cell.contentHeight
            cell_expand_heights[0] = cell.contentHeight
            return cell
        }else if indexPath.row > 0 && indexPath.row < 4 {
            let cell = tableView.dequeueReusableCell(withIdentifier: "midCell") as! CDMidCell
            cell.lblTitle.text = header_str[indexPath.row]
            cell.cell_ind = indexPath.row
            return cell
        }else {
            let cell = tableView.dequeueReusableCell(withIdentifier: "btmCell") as! CDBtmCell
            cell.lblTitle.text = header_str[indexPath.row]
            if self.contact_object != nil {
                cell.contact_detail = self.contact_object
            }
            cell.initCellContent(indexPath.row - 4, self.header_expanded[indexPath.row])
            cell.delegate = self
            return cell
        }
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        if header_expanded[indexPath.row] {
            return cell_expand_heights[indexPath.row]
        }else {
            return cell_norm_heights[indexPath.row]
        }
    }
    
    func openCell(_ cell: CDBtmCell) {
        let indexPath = self.cdTbl.indexPath(for: cell)
        self.header_expanded[indexPath!.row] = !self.header_expanded[indexPath!.row]
//        self.cdTbl.beginUpdates()
//        self.cdTbl.insertRows(at: [indexPath!], with: .fade)
//        self.cdTbl.deleteRows(at: [indexPath!], with: .fade)
//        self.cdTbl.reloadRows(at: [indexPath!], with: .automatic)
//        self.cdTbl.endUpdates()
        UIView.setAnimationsEnabled(false)
        self.cdTbl.beginUpdates()
        self.cdTbl.reloadSections(NSIndexSet(index: 0) as IndexSet, with: .none)
        self.cdTbl.endUpdates()
        UIView.setAnimationsEnabled(true)
    }
}

class CDHeaderCell: UITableViewCell {
    
    @IBOutlet weak var lblDispFL: UILabel!
    
    var contentHeight: CGFloat = 0
    var contentWidth: CGFloat = 0
    var contact_object: ContactDetail? {
        didSet {
            self.contentView.subviews.forEach { (view) in
                if view.tag != 1000 {
                    view.removeFromSuperview()
                }
            }
            var offset_y: CGFloat = 0
            self.lblDispFL.text = contact_object?.displayFirstLast
            /// Init Contact Detail View
            let lblCN = GorditaLabel(frame: CGRect(x: 19, y: 71, width: contentWidth - 70, height: 25))
            lblCN.text = "\(contact_object?.firstName ?? "") \(contact_object?.lastName ?? "")"
            self.contentView.addSubview(lblCN)
            offset_y = lblCN.frame.origin.y + 28
            if contact_object?.company != nil && contact_object?.company != "" {
                let lblComp = GorditaLabel(frame: CGRect(x: 19, y: lblCN.frame.origin.y + 28, width: self.contentView.frame.width - 70, height: 25))
                lblComp.text = contact_object?.company
                self.contentView.addSubview(lblComp)
                offset_y = lblComp.frame.origin.y + 35
            }
            
            let lblCreatContIcon1 = IconLabel(frame: CGRect(x: contentWidth - 40, y: lblCN.frame.origin.y, width: 30, height: 30))
            lblCreatContIcon1.contentMode = .center
            lblCreatContIcon1.text_color = APP_BLUE_COLOR
            lblCreatContIcon1.text = AppIcons.save.rawValue
            self.contentView.addSubview(lblCreatContIcon1)
            let saveBtn1 = UIButton(frame: lblCreatContIcon1.frame)
            saveBtn1.addTarget(self, action: #selector(self.createMainContact), for: .touchUpInside)
            self.contentView.addSubview(saveBtn1)
            for phone in contact_object!.phones {
                let lblIcon = IconLabel(frame: CGRect(x: 19, y: offset_y, width: 25, height: 25))
                lblIcon.contentMode = .center
                lblIcon.text = AppIcons.phone.rawValue
                self.contentView.addSubview(lblIcon)
                let lblPhone = IconLabel(frame: CGRect(x: 48, y: offset_y, width: contentWidth - 63, height: 25))
                if phone.phoneType == "Cell" || phone.phoneType == "Mobile" {
                    lblPhone.text = "\(phone.phoneType ?? "") \(phone.phone ?? "")        \(AppIcons.sms.rawValue)"
                }else {
                    lblPhone.text = "\(phone.phoneType ?? "") \(phone.phone ?? "")"
                }
                let btnPhone = AFPhoneButton()
                btnPhone.frame = CGRect(x: 48, y: offset_y, width: 155, height: 30)
                btnPhone.number = phone.phone
                
                self.contentView.addSubview(lblPhone)
                self.contentView.addSubview(btnPhone)
                
                if phone.phoneType == "Cell" || phone.phoneType == "Mobile" {
                    let btnSMS = AFSMSButton()
                    btnSMS.frame = CGRect(x: 210, y: offset_y, width: 50, height: 30)
                    btnSMS.number = phone.phone
                    self.contentView.addSubview(btnSMS)
                }
                
                offset_y += 32
            }
            
            offset_y += 5
            
            if contact_object?.email != nil && contact_object?.email != "" {
                let lblEmailIcon = IconLabel(frame: CGRect(x: 19, y: offset_y, width: 25, height: 25))
                lblEmailIcon.contentMode = .center
                lblEmailIcon.text = AppIcons.email.rawValue
                self.contentView.addSubview(lblEmailIcon)
                let lblEmail = IconLabel(frame: CGRect(x: 48, y: offset_y, width: contentWidth - 63, height: 25))
                lblEmail.text = contact_object?.email
                let btnEmail = AFEmailButton()
                btnEmail.frame = lblEmail.frame
                btnEmail.email = contact_object?.email
                self.contentView.addSubview(lblEmail)
                self.contentView.addSubview(btnEmail)
                offset_y += 32
            }
            let sep_view1 = UIView(frame: CGRect(x: 0, y: offset_y, width: contentWidth, height: 1))
            sep_view1.backgroundColor = UIColor(red: 240 / 255, green: 240 / 255, blue: 240 / 255, alpha: 1.0)
            self.contentView.addSubview(sep_view1)
            offset_y += 11
            
            if contact_object?.spouseEmail != nil && contact_object?.spouseEmail != "" || contact_object?.spouseFirstName != nil && contact_object?.spouseFirstName != "" || contact_object?.spouseLastName != nil && contact_object?.spouseLastName != "" {
                let lblSN = GorditaLabel(frame: CGRect(x: 19, y: offset_y, width: contentWidth - 70, height: 25))
                lblSN.text = "\(contact_object?.spouseFirstName ?? "") \(contact_object?.spouseLastName ?? "")"
                self.contentView.addSubview(lblSN)
                let lblCreatContIcon2 = IconLabel(frame: CGRect(x: contentWidth - 40, y: lblSN.frame.origin.y, width: 30, height: 30))
                lblCreatContIcon2.text = AppIcons.save.rawValue
                lblCreatContIcon2.contentMode = .center
                lblCreatContIcon2.text_color = APP_BLUE_COLOR
                self.contentView.addSubview(lblCreatContIcon2)
                let saveBtn2 = UIButton(frame: lblCreatContIcon2.frame)
                saveBtn2.addTarget(self, action: #selector(self.createSpouseContact), for: .touchUpInside)
                self.contentView.addSubview(saveBtn2)
                offset_y += 28
                
                for phone in contact_object!.spousePhones {
                    let lblIcon = IconLabel(frame: CGRect(x: 19, y: offset_y, width: 25, height: 25))
                    lblIcon.text = AppIcons.phone.rawValue
                    self.contentView.addSubview(lblIcon)
                    let lblPhone = IconLabel(frame: CGRect(x: 48, y: offset_y, width: contentWidth - 63, height: 25))
                    if phone.phoneType == "Cell" || phone.phoneType == "Mobile" {
                        lblPhone.text = "\(phone.phoneType ?? "") \(phone.phone ?? "")        \(AppIcons.sms.rawValue)"
                    }else {
                        lblPhone.text = "\(phone.phoneType ?? "") \(phone.phone ?? "")"
                    }
                    let btnPhone = AFPhoneButton()
                    btnPhone.frame = CGRect(x: 48, y: offset_y, width: 155, height: 30)
                    btnPhone.number = phone.phone
                    
                    self.contentView.addSubview(lblPhone)
                    self.contentView.addSubview(btnPhone)
                    
                    if phone.phoneType == "Cell" || phone.phoneType == "Mobile" {
                        let btnSMS = AFSMSButton()
                        btnSMS.frame = CGRect(x: 210, y: offset_y, width: 50, height: 30)
                        btnSMS.number = phone.phone
                        self.contentView.addSubview(btnSMS)
                    }
                    offset_y += 32
                }
                
                offset_y += 5
                
                if contact_object?.spouseEmail != nil && contact_object?.spouseEmail != "" {
                    let lblSEmailIcon = IconLabel(frame: CGRect(x: 19, y: offset_y, width: 25, height: 25))
                    lblSEmailIcon.text = AppIcons.email.rawValue
                    self.contentView.addSubview(lblSEmailIcon)
                    let lblSEmail = IconLabel(frame: CGRect(x: 48, y: offset_y, width: contentWidth - 63, height: 25))
                    lblSEmail.text = contact_object?.spouseEmail
                    let btnSEmail = AFEmailButton()
                    btnSEmail.frame = lblSEmail.frame
                    btnSEmail.email = contact_object?.spouseEmail
                    self.contentView.addSubview(lblSEmail)
                    self.contentView.addSubview(btnSEmail)
                    offset_y += 33
                }
            }
            
            contentHeight = offset_y
            
        }
    }
    
    @objc func createMainContact() {
        let contact = CNMutableContact()
        contact.givenName = contact_object?.firstName ?? ""
        contact.familyName = contact_object?.lastName ?? ""
        contact.organizationName = contact_object?.company ?? ""
        let homeEmail = CNLabeledValue(label: CNLabelHome, value: (contact_object?.email ?? "") as NSString)
        contact.emailAddresses = [homeEmail]
        for phone in contact_object!.phones {
            contact.phoneNumbers.append(CNLabeledValue(
                label:phone.phoneType?.getPhoneType(),
                value:CNPhoneNumber(stringValue: "\(phone.phone ?? "")")))
        }
        let homeAddress = CNMutablePostalAddress()
        homeAddress.street = contact_object?.addressHome?.address1 ?? ""
        homeAddress.city = contact_object?.addressHome?.city ?? ""
        homeAddress.state = contact_object?.addressHome?.state ?? ""
        homeAddress.postalCode = contact_object?.addressHome?.zip ?? ""
        contact.postalAddresses = [CNLabeledValue(label:CNLabelHome, value:homeAddress)]
        
        if contact_object?.birthday != nil {
            
            let birthday = NSDateComponents()
            birthday.day = contact_object!.birthday![2]
            birthday.month = contact_object!.birthday![1]
            birthday.year = contact_object!.birthday![0]
            contact.birthday = birthday as DateComponents
        }
        
        // Saving the newly created contact
//        let store = CNContactStore()
//        let saveRequest = CNSaveRequest()
//        saveRequest.add(contact, toContainerWithIdentifier:nil)
//        try! store.execute(saveRequest)
        
        let viewCon = self.findViewController() as! BaseViewController
        let vc = CNContactViewController(forNewContact: contact)
        vc.delegate = viewCon
        let navCon = UINavigationController(rootViewController: vc)
        viewCon.present(navCon, animated: true, completion: nil)
    }
    
    @objc func createSpouseContact() {
        let contact = CNMutableContact()
        contact.givenName = contact_object?.spouseFirstName ?? ""
        contact.familyName = contact_object?.spouseLastName ?? ""
        let homeEmail = CNLabeledValue(label: CNLabelHome, value: (contact_object?.spouseEmail ?? "") as NSString)
        contact.emailAddresses = [homeEmail]
        
        for phone in contact_object!.spousePhones {
            contact.phoneNumbers.append(CNLabeledValue(
                label:phone.phoneType?.getPhoneType(),
                value:CNPhoneNumber(stringValue: "\(phone.phone ?? "")")))
        }
        
        if contact_object?.birthdaySpouse != nil {
            
            let birthday = NSDateComponents()
            birthday.day = contact_object!.birthdaySpouse![2]
            birthday.month = contact_object!.birthdaySpouse![1]
            birthday.year = contact_object!.birthdaySpouse![0]
            contact.birthday = birthday as DateComponents
        }
        
        // Saving the newly created contact
//        let store = CNContactStore()
//        let saveRequest = CNSaveRequest()
//        saveRequest.add(contact, toContainerWithIdentifier:nil)
//        try! store.execute(saveRequest)
        
        let viewCon = self.findViewController() as! BaseViewController
        let vc = CNContactViewController(forNewContact: contact)
        vc.delegate = viewCon
        let navCon = UINavigationController(rootViewController: vc)
        viewCon.present(navCon, animated: true, completion: nil)
    }
    
}

class CDMidCell: UITableViewCell {
    
    @IBOutlet weak var lblTitle: UILabel!
    @IBOutlet weak var lblIcon: UILabel!
    
    var cell_ind: Int? {
        didSet {
            switch cell_ind! {
            case 1:
                lblIcon.text = AppIcons.home.rawValue
                break
            case 2:
                lblIcon.text = AppIcons.comment.rawValue
                break
            default:
                lblIcon.text = AppIcons.task.rawValue
                break
            }
        }
    }
    
    @IBAction func actionGoDetail(_ sender: UIButton) {
        let vc = self.findViewController() as! ContactDetailVC
        switch cell_ind! {
        case 1:
            let gotoVC = vc.storyboard?.instantiateViewController(withIdentifier: "TransactionsVC") as! TransactionsVC
            gotoVC.contact_object = vc.contact_object
            vc.navigationController?.pushViewController(gotoVC, animated: true)
            break
        case 2:
            let gotoVC = vc.storyboard?.instantiateViewController(withIdentifier: "NotesVC") as! NotesVC
            gotoVC.contact_object = vc.contact_object
            vc.navigationController?.pushViewController(gotoVC, animated: true)
            break
        default:
            let gotoVC = vc.storyboard?.instantiateViewController(withIdentifier: "TasksVC") as! TasksVC
            gotoVC.contact_object = vc.contact_object
            vc.navigationController?.pushViewController(gotoVC, animated: true)
            break
        }
        
    }
    
}

protocol CDBtmCellDelegate {
    func openCell(_ cell: CDBtmCell)
}

class CDBtmCell: UITableViewCell {
    
    @IBOutlet weak var lblTitle: UILabel!
    @IBOutlet var contentViews: [UIView]!
    @IBOutlet weak var btnDrop: UIButton!
    
    //Mailing Addresses
    @IBOutlet weak var lblHomeAddr1: UILabel!
    @IBOutlet weak var lblHomeAddr2: UILabel!
    @IBOutlet weak var lblWorkAddr1: UILabel!
    @IBOutlet weak var lblWorkAddr2: UILabel!
    @IBOutlet weak var btnHomeMap: UIButton!
    @IBOutlet weak var btnWorkMap: UIButton!
    @IBOutlet weak var iconHomeMap: UILabel!
    @IBOutlet weak var iconWorkMap: UILabel!
    
    //Other Details
    @IBOutlet weak var lblDOB: UILabel!
    @IBOutlet weak var lblSpouseDOB: UILabel!
    @IBOutlet weak var lblWedDate: UILabel!
    
    // Categories
    @IBOutlet weak var scrCategory: UIScrollView!
    
    // Owners
    @IBOutlet weak var lblOwnersStr: UILabel!
    
    var delegate: CDBtmCellDelegate?
    var contact_detail: ContactDetail? {
        didSet {
            self.lblHomeAddr1.text = contact_detail?.addressHome?.addressLineString
            self.lblHomeAddr2.text = contact_detail?.addressHome?.cszstring
            self.lblWorkAddr1.text = contact_detail?.addressWork?.addressLineString
            self.lblWorkAddr2.text = contact_detail?.addressWork?.cszstring
            
            let dateFormatter = DateFormatter()
            if contact_detail?.birthday != nil {
                dateFormatter.dateFormat = "yyyy-M-d"
                let dob = dateFormatter.date(from: "\(contact_detail!.birthday![0])-\(contact_detail!.birthday![1])-\(contact_detail!.birthday![2])")?.utcToLocal(dateFormatter.dateFormat)
                dateFormatter.dateFormat = "MMMM d, yyyy"
                self.lblDOB.text = dateFormatter.string(from: dob!)
            }
            if contact_detail?.birthdaySpouse != nil {
                dateFormatter.dateFormat = "yyyy-M-d"
                let spouseDob = dateFormatter.date(from: "\(contact_detail!.birthdaySpouse![0])-\(contact_detail!.birthdaySpouse![1])-\(contact_detail!.birthdaySpouse![2])")?.utcToLocal(dateFormatter.dateFormat)
                dateFormatter.dateFormat = "MMMM d, yyyy"
                self.lblSpouseDOB.text = dateFormatter.string(from: spouseDob!)
            }
            
            if contact_detail?.anniversary != nil {
                dateFormatter.dateFormat = "yyyy-M-d"
                let anniversaryDate = dateFormatter.date(from: "\(contact_detail!.anniversary![0])-\(contact_detail!.anniversary![1])-\(contact_detail!.anniversary![2])")?.utcToLocal(dateFormatter.dateFormat)
                dateFormatter.dateFormat = "MMMM d, yyyy"
                self.lblWedDate.text = dateFormatter.string(from: anniversaryDate!)
            }
            
            self.lblOwnersStr.text = contact_detail?.ownersString
            if contact_detail?.addressHome?.addressComplete == nil || !contact_detail!.addressHome!.addressComplete! || contact_detail?.addressHome?.addressFullString == nil || contact_detail?.addressHome?.addressFullString == "" {
                btnHomeMap.alpha = 0.0
                iconHomeMap.alpha = 0.0
            }
            if contact_detail?.addressWork?.addressComplete == nil || !contact_detail!.addressWork!.addressComplete! || contact_detail?.addressWork?.addressFullString == nil || contact_detail?.addressWork?.addressFullString == "" {
                btnWorkMap.alpha = 0.0
                iconWorkMap.alpha = 0.0
            }
            
            var label: BorderLabel?
            var last_label: BorderLabel?
            var offset_x: CGFloat = 20
            self.scrCategory.subviews.forEach { (view) in
                if view is BorderLabel {
                    view.removeFromSuperview()
                }
            }
            for category in contact_detail!.categories {
                if last_label != nil {
                    offset_x = last_label!.frame.origin.x + last_label!.frame.width + 15
                }
                label = BorderLabel()
                label?.frame = CGRect(x: offset_x, y: 10, width: category.name!.widthOfLabel(withConstrainedHeight: 30, font: UIFont(name: "Gordita-Medium", size: 14)!) + 20.0, height: 30)
                label?.text = category.name
                self.scrCategory.addSubview(label!)
                last_label = label
                self.scrCategory.contentSize = CGSize(width: last_label!.frame.origin.x + last_label!.frame.width + 15, height: 0)
            }
        }
    }
    
    func initCellContent(_ cont_ind: Int, _ expanded: Bool) {
        for i in 0 ..< contentViews.count {
            if cont_ind != i {
                contentViews[i].alpha = 0.0
            }
        }
        if expanded {
            contentViews[cont_ind].alpha = 1.0
//            btnDrop.setTitleColor(APP_GRAY_COLOR, for: .normal)
//            btnDrop.setTitle(AppIcons.up_arrow.rawValue, for: .normal)
//            btnDrop.rotate(90)
        }else {
//            btnDrop.setTitleColor(APP_BLUE_COLOR, for: .normal)
//            btnDrop.setTitle(AppIcons.drop_arrow.rawValue, for: .normal)
//            btnDrop.rotate(0)
        }
    }
    
    @IBAction func actionOpenCell(_ sender: UIButton) {
        delegate?.openCell(self)
    }
    
    @IBAction func actionGotoMap(_ sender: UIButton) {
        if sender.tag == 100 {
            if URL(string: contact_detail?.addressHome?.googleMapsUrlString ?? "") != nil {
                UIApplication.shared.open(URL(string: contact_detail?.addressHome?.googleMapsUrlString ?? "")!, options: [:], completionHandler: nil)
            }
        }else {
            if URL(string: contact_detail?.addressWork?.googleMapsUrlString ?? "") != nil {
                UIApplication.shared.open(URL(string: contact_detail?.addressWork?.googleMapsUrlString ?? "")!, options: [:], completionHandler: nil)
            }
        }
    }
    
    
}
