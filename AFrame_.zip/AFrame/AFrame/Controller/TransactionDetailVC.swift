//
//  TransactionDetailVC.swift
//  AFrame
//
//  Created by Lee Sheng Jin on 2019/2/13.
//  Copyright © 2019 DrawRanger. All rights reserved.
//

import UIKit
import Contacts
import ContactsUI

class TransactionDetailVC: BaseViewController {
    
    @IBOutlet weak var detailTbl: UITableView!
    
    var header_str: [String] = ["", "---", "Activities", "Attachments", "Tasks", "Contract Dates", "Listing Details", "Contract Details", "Participants"]
    var header_expanded: [Bool] = [false, false, false, false, false, false, false, false, false]
    let cell_norm_heights: [CGFloat] = [300, 50, 50, 50, 50, 50, 50, 50, 50]
    var cell_expand_heights: [CGFloat] = [300, 50, 50, 50, 50, 50, 613, 391, 500]
    var xaction_detail: TransactionDetail?
    var xaction_participants: [Participant] = []
    let refreshCtrl: UIRefreshControl = UIRefreshControl()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        refreshCtrl.frame = CGRect(x: 0, y: 50, width: refreshCtrl.frame.width, height: refreshCtrl.frame.height)
        refreshCtrl.tintColor = UIColor(red: 200 / 255, green: 200 / 255, blue: 200 / 255, alpha: 1.0)
        refreshCtrl.addTarget(self, action: #selector(self.getXactionDetail), for: .valueChanged)
        self.detailTbl.refreshControl = refreshCtrl
        self.initView()
    }
    
    @objc func getXactionDetail() {
        API.sharedInstance.api_xaction_detail(xaction_detail!.xactionId!) { (detail) in
            DispatchQueue.main.async {
                if detail != nil {
                    self.xaction_detail = detail
                    API.sharedInstance.api_xaction_participants(self.xaction_detail!.xactionId!) { (participants) in
                        DispatchQueue.main.async {
                            self.refreshCtrl.endRefreshing()
                            self.xaction_participants = participants ?? []
                            self.initView()
                        }
                    }
                }else {
                    self.refreshCtrl.endRefreshing()
                }
            }
        }
    }
    
    func initView() {
        self.detailTbl.delegate = self
        self.detailTbl.dataSource = self
        self.detailTbl.separatorStyle = .none
        self.detailTbl.allowsSelection = false
        self.detailTbl.showsVerticalScrollIndicator = false
        self.header_str[1] = self.xaction_detail?.contact?.displayFirstLast ?? "---"
        self.detailTbl.reloadData()
    }
    
    @IBAction func actionBack(_ sender: UIButton) {
        self.navigationController?.popViewController(animated: true)
    }

}

extension TransactionDetailVC: UITableViewDelegate, UITableViewDataSource, TDBtmCellDelegate {
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 9
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        if indexPath.row == 0 {
            let cell = tableView.dequeueReusableCell(withIdentifier: "tdHeaderCell") as! TDHeaderCell
            if self.xaction_detail != nil {
                cell.xaction_detail = self.xaction_detail
            }
            return cell
        }else if indexPath.row > 0 && indexPath.row < 6 {
            let cell = tableView.dequeueReusableCell(withIdentifier: "tdMidCell") as! TDMidCell
            cell.lblCont.text = header_str[indexPath.row]
            cell.cell_ind = indexPath.row
            return cell
        }else {
            let cell = tableView.dequeueReusableCell(withIdentifier: "tdBtmCell") as! TDBtmCell
            cell.lblTitle.text = header_str[indexPath.row]
            if self.xaction_detail != nil {
                cell.xaction_detail = self.xaction_detail
            }
            if indexPath.row == 8 {
                cell.contentHeight = 60
                cell.contentWidth = self.view.frame.width
                cell.participants = self.xaction_participants
            }
            cell.initCellContent(indexPath.row - 6, self.header_expanded[indexPath.row])
            cell_expand_heights[indexPath.row] = cell.contentHeight
            cell.delegate = self
            return cell
        }
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        if header_expanded[indexPath.row] {
            return cell_expand_heights[indexPath.row]
        }else {
            return cell_norm_heights[indexPath.row]
        }
    }
    
    func openCell(_ cell: TDBtmCell) {
        let indexPath = self.detailTbl.indexPath(for: cell)
        self.header_expanded[indexPath!.row] = !self.header_expanded[indexPath!.row]
        UIView.setAnimationsEnabled(false)
        self.detailTbl.beginUpdates()
        self.detailTbl.reloadSections(NSIndexSet(index: 0) as IndexSet, with: .none)
        self.detailTbl.endUpdates()
        UIView.setAnimationsEnabled(true)
    }
    
}

class TDHeaderCell: UITableViewCell {
    
    @IBOutlet weak var lblAddress: UILabel!
    @IBOutlet weak var statusBadge: UIView!
    @IBOutlet weak var lblStatus: UILabel!
    @IBOutlet weak var lblPropType: UILabel!
    @IBOutlet weak var lblListPrice: UILabel!
    @IBOutlet weak var lblSide: UILabel!
    @IBOutlet weak var lblContractPrice: UILabel!
    @IBOutlet weak var lblClosingDate: UILabel!
    @IBOutlet weak var lblPrimaryAgent: UILabel!
    @IBOutlet weak var lblCoAgent: UILabel!
    
    var xaction_detail: TransactionDetail? {
        didSet {
            self.lblAddress.text = xaction_detail?.address?.addressLineString
            self.lblStatus.text = xaction_detail?.status
            self.lblPropType.text = xaction_detail?.propType
            self.lblListPrice.text = xaction_detail?.listPrice?.getCurrency()
            self.lblSide.text = xaction_detail?.xactionSide?.capitalized
            self.lblContractPrice.text = xaction_detail?.contractPrice?.getCurrency()
            self.statusBadge.backgroundColor = xaction_detail?.statusColorHex?.getColor() ?? UIColor.black
            
            let dateFormatter = DateFormatter()
            dateFormatter.dateFormat = "yyyy-MM-dd"
            let date = xaction_detail?.closedDate != nil ? xaction_detail?.closedDate?.utcToLocal(dateFormatter.dateFormat) ?? Date().utcToLocal(dateFormatter.dateFormat) : xaction_detail?.closingDate?.utcToLocal(dateFormatter.dateFormat) ?? Date().utcToLocal(dateFormatter.dateFormat)
            dateFormatter.dateFormat = "MMM d, yyyy"
            self.lblClosingDate.text = dateFormatter.string(from: date)
            self.lblPrimaryAgent.text = xaction_detail?.appUserPrimaryAgent?.displayFirstLast
            self.lblCoAgent.text = xaction_detail?.appUserCoAgent?.displayFirstLast
        }
    }
    
    @IBAction func actionGotoLink(_ sender: UIButton) {
        if URL(string: self.xaction_detail?.siteUrl ?? "") != nil {
            UIApplication.shared.open(URL(string: self.xaction_detail?.siteUrl ?? "")!, options: [:], completionHandler: nil)
        }
    }
    
    @IBAction func actionMap(_ sender: UIButton) {
        if URL(string: xaction_detail?.address?.googleMapsUrlString ?? "") != nil {
            UIApplication.shared.open(URL(string: xaction_detail?.address?.googleMapsUrlString ?? "")!, options: [:], completionHandler: nil)
        }else {
            let vc = self.findViewController() as! BaseViewController
            vc.alertViewController(title: "Oops!", message: "Invalid Map link.")
        }
    }
    
}

class TDMidCell: UITableViewCell {
    @IBOutlet weak var lblIcon: UILabel!
    @IBOutlet weak var lblCont: UILabel!
    
    var cell_ind: Int? {
        didSet {
            switch cell_ind! {
            case 1:
                lblIcon.text = AppIcons.profile.rawValue
                break
            case 2:
                lblIcon.text = AppIcons.list.rawValue
                break
            case 3:
                lblIcon.text = AppIcons.file.rawValue
                break
            case 4:
                lblIcon.text = AppIcons.task.rawValue
                break
            default:
                lblIcon.text = AppIcons.calendar.rawValue
                break
            }
        }
    }
    
    @IBAction func actionGoDetail(_ sender: UIButton) {
        let vc = self.findViewController() as! TransactionDetailVC
        switch cell_ind! {
        case 1:
            let tmpVC = vc.storyboard?.instantiateViewController(withIdentifier: "ContactDetailVC") as! ContactDetailVC
            tmpVC.contact_object = vc.xaction_detail?.contact
            vc.navigationController?.pushViewController(tmpVC, animated: true)
            break
        case 2:
            let tmpVC = vc.storyboard?.instantiateViewController(withIdentifier: "ActivitiesVC") as! ActivitiesVC
            tmpVC.xaction_detail = vc.xaction_detail
            vc.navigationController?.pushViewController(tmpVC, animated: true)
            break
        case 3:
            let tmpVC = vc.storyboard?.instantiateViewController(withIdentifier: "AttachmentsVC") as! AttachmentsVC
            tmpVC.xaction_detail = vc.xaction_detail
            vc.navigationController?.pushViewController(tmpVC, animated: true)
            break
        case 4:
            let tmpVC = vc.storyboard?.instantiateViewController(withIdentifier: "TasksVC") as! TasksVC
            tmpVC.xaction_detail = vc.xaction_detail
            vc.navigationController?.pushViewController(tmpVC, animated: true)
            break
        default:
            let tmpVC = vc.storyboard?.instantiateViewController(withIdentifier: "ContactDatesVC") as! ContactDatesVC
            let suffix = "xactionId=\(vc.xaction_detail?.xactionId ?? 0)"
            vc.showHUD()
            API.sharedInstance.api_contract_dates(suffix) { (contract_dates) in
                DispatchQueue.main.async {
                    vc.hideHUD()
                    tmpVC.xaction_detail = vc.xaction_detail
                    tmpVC.contract_dates = contract_dates ?? []
                    vc.navigationController?.pushViewController(tmpVC, animated: true)
                }
            }
            break
        }
    }
    
}

protocol TDBtmCellDelegate {
    func openCell(_ cell: TDBtmCell)
}

class TDBtmCell: UITableViewCell {
    
    @IBOutlet var contViews: [UIView]!
    @IBOutlet weak var btnArrow: UIButton!
    @IBOutlet weak var lblTitle: UILabel!
    
    //Listing Details
    @IBOutlet weak var lblListingDate: UILabel!
    @IBOutlet weak var lblBedBathBuilt: UILabel!
    @IBOutlet weak var lblExpireDate: UILabel!
    @IBOutlet weak var lblSqftperSqft: UILabel!
    @IBOutlet weak var lblLot: UILabel!
    @IBOutlet weak var lblSqftSource: UILabel!
    @IBOutlet weak var lblSchools: UILabel!
    @IBOutlet weak var lblSubdivision: UILabel!
    @IBOutlet weak var lblLockBox: UILabel!
    @IBOutlet weak var lblSecurity: UILabel!
    @IBOutlet weak var lblRemarks: UILabel!
    @IBOutlet weak var lblInstructions: UILabel!
    @IBOutlet weak var lblOtherInfo: UILabel!
    
    
    // Contract Details
    @IBOutlet weak var lblEarnestMoney: UILabel!
    @IBOutlet weak var lblOtherParty: UILabel!
    @IBOutlet weak var lblSpecialProvisions: UILabel!
    @IBOutlet weak var lblPossession: UILabel!
    @IBOutlet weak var lblContOtherInfo: UILabel!
    
    // Participants
    var contentHeight: CGFloat = 50
    var contentWidth: CGFloat = 0
    var participants: [Participant]? {
        didSet {
            var offset_y: CGFloat = 8
            self.contViews[2].subviews.forEach { (view) in
                view.removeFromSuperview()
            }
            var count: Int = 0
            for participant in participants! {
                /// Init Contact Detail View
                let lblType = UILabel(frame: CGRect(x: 17, y: offset_y, width: contentWidth - 70, height: 25))
                lblType.font = UIFont(name: "Gordita-Regular", size: 15)!
                lblType.textColor = APP_GRAY_COLOR
                lblType.text = participant.xactionParticipantRole
                self.contViews[2].addSubview(lblType)
                
                let lblCN = GorditaLabel(frame: CGRect(x: 19, y: offset_y + 35, width: contentWidth - 70, height: 25))
                lblCN.text = "\(participant.firstName ?? "") \(participant.lastName ?? "")"
                self.contViews[2].addSubview(lblCN)
                let lblComp = GorditaLabel(frame: CGRect(x: 19, y: lblCN.frame.origin.y + 28, width: self.contentView.frame.width - 70, height: 25))
                lblComp.text = participant.company
                self.contViews[2].addSubview(lblComp)
                let lblCreatContIcon1 = IconLabel(frame: CGRect(x: contentWidth - 40, y: lblCN.frame.origin.y, width: 30, height: 30))
                lblCreatContIcon1.contentMode = .center
                lblCreatContIcon1.text_color = APP_BLUE_COLOR
                lblCreatContIcon1.text = AppIcons.save.rawValue
                self.contViews[2].addSubview(lblCreatContIcon1)
                let saveBtn1 = AFAddressButton(frame: lblCreatContIcon1.frame)
//                saveBtn1.addTarget(self, action: #selector(self.createMainContact), for: .touchUpInside)
                self.contViews[2].addSubview(saveBtn1)
                if participant.company != nil && participant.company != "" {
                    offset_y = lblCreatContIcon1.frame.origin.y + 65
                }else {
                    offset_y = lblCreatContIcon1.frame.origin.y + 30
                }
                for phone in participant.phones {
                    let lblIcon = IconLabel(frame: CGRect(x: 19, y: offset_y, width: 25, height: 25))
                    lblIcon.contentMode = .center
                    lblIcon.text = AppIcons.phone.rawValue
                    self.contViews[2].addSubview(lblIcon)
                    let lblPhone = IconLabel(frame: CGRect(x: 48, y: offset_y, width: contentWidth - 63, height: 25))
                    if phone.phoneType == "Cell" || phone.phoneType == "Mobile" {
                        lblPhone.text = "\(phone.phone ?? "")        \(AppIcons.sms.rawValue)"
                    }else {
                        lblPhone.text = phone.phone
                    }
                    let btnPhone = AFPhoneButton()
                    btnPhone.frame = CGRect(x: 48, y: offset_y, width: 155, height: 30)
                    btnPhone.number = phone.phone
                    self.contViews[2].addSubview(lblPhone)
                    self.contViews[2].addSubview(btnPhone)
                    
                    if phone.phoneType == "Cell" || phone.phoneType == "Mobile" {
                        let btnSMS = AFSMSButton()
                        btnSMS.frame = CGRect(x: 210, y: offset_y, width: 50, height: 30)
                        btnSMS.number = phone.phone
                        self.contViews[2].addSubview(btnSMS)
                    }
                    
                    offset_y += 35
                }
                
//                offset_y += 5
                
                if participant.email != nil && participant.email != "" {
                    let lblEmailIcon = IconLabel(frame: CGRect(x: 19, y: offset_y, width: 25, height: 25))
                    lblEmailIcon.contentMode = .center
                    lblEmailIcon.text = AppIcons.email.rawValue
                    self.contViews[2].addSubview(lblEmailIcon)
                    let lblEmail = IconLabel(frame: CGRect(x: 48, y: offset_y, width: contentWidth - 63, height: 25))
                    lblEmail.text = participant.email
                    let btnEmail = AFEmailButton(frame: lblEmail.frame)
                    btnEmail.subject = participant.address?.cszstring ?? ""
                    btnEmail.email = participant.email
                    self.contViews[2].addSubview(lblEmail)
                    self.contViews[2].addSubview(btnEmail)
                    offset_y += 37
                }
                
                if participant.address?.cszstring != nil && participant.address?.cszstring != "" {
                    let height: CGFloat = participant.address?.cszstring?.heightForView(UIFont(name: "FontAwesome5ProLight", size: 17)!, contentWidth - 45) ?? 25
                    let lblAddress = IconLabel(frame: CGRect(x: 19, y: offset_y, width: contentWidth - 70, height: height + 5))
                    lblAddress.text = participant.address?.cszstring
                    self.contViews[2].addSubview(lblAddress)
                    
                    let lblMap = UILabel(frame: CGRect(x: contentWidth - 38, y: offset_y + 2, width: 25, height: 25))
                    lblMap.font = UIFont(name: "FontAwesome5ProLight", size: 17)!
                    lblMap.textColor = APP_BLUE_COLOR
                    lblMap.text = AppIcons.map.rawValue
                    
                    let btnMap = IconButton(frame: lblMap.frame)
                    btnMap.mapLink = participant.address?.googleMapsUrlString
                    
                    self.contViews[2].addSubview(lblMap)
                    self.contViews[2].addSubview(btnMap)
                    
                    offset_y += height + 25
                }
                
                let contact = CNMutableContact()
                let contact_object = participant
                contact.givenName = contact_object.firstName ?? ""
                contact.familyName = contact_object.lastName ?? ""
                contact.organizationName = contact_object.company ?? ""
                let homeEmail = CNLabeledValue(label: CNLabelHome, value: (contact_object.email ?? "") as NSString)
                contact.emailAddresses = [homeEmail]
                
                for phone in contact_object.phones {
                    contact.phoneNumbers.append(CNLabeledValue(
                        label:phone.phoneType?.getPhoneType(),
                        value:CNPhoneNumber(stringValue: phone.phone ?? "")))
                }
                
                let homeAddress = CNMutablePostalAddress()
                homeAddress.street = contact_object.address?.address1 ?? ""
                homeAddress.city = contact_object.address?.city ?? ""
                homeAddress.state = contact_object.address?.state ?? ""
                homeAddress.postalCode = contact_object.address?.zip ?? ""
                contact.postalAddresses = [CNLabeledValue(label:CNLabelHome, value:homeAddress)]
                
                saveBtn1.contact = contact
                
                if participant.spouseEmail != nil && participant.spouseEmail != "" || participant.spouseFirstName != nil && participant.spouseFirstName != "" || participant.spouseLastName != nil && participant.spouseLastName != "" {
                    let lblSN = GorditaLabel(frame: CGRect(x: 19, y: offset_y, width: contentWidth - 70, height: 25))
                    lblSN.text = "\(participant.spouseFirstName ?? "") \(participant.spouseLastName ?? "")"
                    self.contViews[2].addSubview(lblSN)
                    
                    let lblCreatContIcon2 = IconLabel(frame: CGRect(x: contentWidth - 40, y: lblSN.frame.origin.y, width: 30, height: 30))
                    lblCreatContIcon2.text = AppIcons.save.rawValue
                    lblCreatContIcon2.contentMode = .center
                    lblCreatContIcon2.text_color = APP_BLUE_COLOR
                    self.contViews[2].addSubview(lblCreatContIcon2)
                    let saveBtn2 = AFAddressButton(frame: lblCreatContIcon2.frame)
//                    saveBtn2.addTarget(self, action: #selector(self.createSpouseContact), for: .touchUpInside)
                    self.contViews[2].addSubview(saveBtn2)
                    offset_y += 35
                    for phone in participant.spousePhones {
                        let lblIcon = IconLabel(frame: CGRect(x: 19, y: offset_y, width: 25, height: 25))
                        lblIcon.text = AppIcons.phone.rawValue
                        self.contViews[2].addSubview(lblIcon)
                        let lblPhone = IconLabel(frame: CGRect(x: 48, y: offset_y, width: 155, height: 25))
                        if phone.phoneType == "Cell" || phone.phoneType == "Mobile" {
                            lblPhone.text = "\(phone.phone ?? "")        \(AppIcons.sms.rawValue)"
                        }else {
                            lblPhone.text = phone.phone
                        }
                        let btnPhone = AFPhoneButton()
                        btnPhone.frame = CGRect(x: 48, y: offset_y, width: 155, height: 30)
                        btnPhone.number = phone.phone
                        self.contViews[2].addSubview(lblPhone)
                        self.contViews[2].addSubview(btnPhone)
                        
                        if phone.phoneType == "Cell" || phone.phoneType == "Mobile" {
                            let btnSMS = AFSMSButton()
                            btnSMS.frame = CGRect(x: 210, y: offset_y, width: 50, height: 30)
                            btnSMS.number = phone.phone
                            self.contViews[2].addSubview(btnSMS)
                        }
                        
                        offset_y += 27
                    }
                    
//                    offset_y += 5
                    
                    let contact = CNMutableContact()
                    let contact_object = participant
                    contact.givenName = contact_object.spouseFirstName ?? ""
                    contact.familyName = contact_object.spouseLastName ?? ""
                    contact.organizationName = contact_object.company ?? ""
                    let homeEmail = CNLabeledValue(label: CNLabelHome, value: (contact_object.spouseEmail ?? "") as NSString)
                    contact.emailAddresses = [homeEmail]
                    
                    for phone in contact_object.spousePhones {
                        contact.phoneNumbers.append(CNLabeledValue(
                            label:phone.phoneType?.getPhoneType(),
                            value:CNPhoneNumber(stringValue: phone.phone ?? "")))
                    }
                    
                    let homeAddress = CNMutablePostalAddress()
                    homeAddress.street = contact_object.address?.address1 ?? ""
                    homeAddress.city = contact_object.address?.city ?? ""
                    homeAddress.state = contact_object.address?.state ?? ""
                    homeAddress.postalCode = contact_object.address?.zip ?? ""
                    contact.postalAddresses = [CNLabeledValue(label:CNLabelHome, value:homeAddress)]
                    
                    saveBtn2.contact = contact
                    
                    if participant.spouseEmail != nil && participant.spouseEmail != "" {
                        let lblSEmailIcon = IconLabel(frame: CGRect(x: 19, y: offset_y, width: 25, height: 25))
                        lblSEmailIcon.text = AppIcons.email.rawValue
                        self.contViews[2].addSubview(lblSEmailIcon)
                        let lblSEmail = IconLabel(frame: CGRect(x: 48, y: offset_y, width: contentWidth - 63, height: 25))
                        lblSEmail.text = participant.spouseEmail
                        let btnSEmail = AFEmailButton(frame: lblSEmail.frame)
                        btnSEmail.email = participant.spouseEmail
                        self.contViews[2].addSubview(lblSEmail)
                        self.contViews[2].addSubview(btnSEmail)
                        offset_y += 27
                    }
                }
                count += 1
                if count != participants!.count {
                    let separateLine: UIView = UIView(frame: CGRect(x: 0, y: offset_y + 8, width: contentWidth, height: 1))
                    separateLine.backgroundColor = UIColor(red: 240 / 255, green: 240 / 255, blue: 240 / 255, alpha: 1.0)
                    self.contViews[2].addSubview(separateLine)
                    offset_y += 16
                }
            }
            
            contentHeight = offset_y < 60 ? 60 : offset_y + 78 //+ 100
        }
    }
    
    var xaction_detail: TransactionDetail? {
        didSet {
            
            let dateFormatter = DateFormatter()
            dateFormatter.dateFormat = "yyyy-MM-dd"
            let listDate = xaction_detail?.listDate?.utcToLocal(dateFormatter.dateFormat) ?? Date().utcToLocal(dateFormatter.dateFormat)
            dateFormatter.dateFormat = "MMM dd, yyyy"
            self.lblListingDate.text = dateFormatter.string(from: listDate)
            self.lblBedBathBuilt.text = "\(xaction_detail?.beds ?? 0)/ \(xaction_detail?.baths ?? 0.0)/ \(xaction_detail?.yearBuilt ?? 1970)"
            dateFormatter.dateFormat = "yyyy-MM-dd"
            let expireDate = xaction_detail?.expireDate?.utcToLocal(dateFormatter.dateFormat) ?? Date().utcToLocal(dateFormatter.dateFormat)
            dateFormatter.dateFormat = "MMM dd, yyyy"
            self.lblExpireDate.text = dateFormatter.string(from: expireDate)
            self.lblSqftperSqft.text = "\(xaction_detail?.sqFt ?? 0)"
            self.lblLot.text = xaction_detail?.lotSize
            self.lblSqftSource.text = xaction_detail?.sqFtSource
            self.lblSchools.text = xaction_detail?.schools
            self.lblLockBox.text = xaction_detail?.lockBox
            self.lblSecurity.text = xaction_detail?.securityCode
            self.lblRemarks.text = xaction_detail?.remarks
            self.lblInstructions.text = xaction_detail?.instructions
            self.lblOtherInfo.text = xaction_detail?.listOtherInfo
            self.lblEarnestMoney.text = xaction_detail?.earnestMoney
            self.lblOtherParty.text = xaction_detail?.otherParty
            self.lblSpecialProvisions.text = xaction_detail?.specialProvisions
            self.lblPossession.text = xaction_detail?.possession
            self.lblContOtherInfo.text = xaction_detail?.contractOtherInfo
        }
    }
    
    @objc func createMainContact() {
        let contact = CNMutableContact()
        let contact_object = self.xaction_detail?.contact
        contact.givenName = contact_object?.firstName ?? ""
        contact.familyName = contact_object?.lastName ?? ""
        let homeEmail = CNLabeledValue(label: CNLabelHome, value: (contact_object?.email ?? "") as NSString)
        contact.emailAddresses = [homeEmail]
        
        for phone in contact_object!.phones {
            contact.phoneNumbers.append(CNLabeledValue(
                label:CNLabelPhoneNumberiPhone,
                value:CNPhoneNumber(stringValue: phone.phone ?? "")))
        }
        let homeAddress = CNMutablePostalAddress()
        homeAddress.street = contact_object?.addressHome?.address1 ?? ""
        homeAddress.city = contact_object?.addressHome?.city ?? ""
        homeAddress.state = contact_object?.addressHome?.state ?? ""
        homeAddress.postalCode = contact_object?.addressHome?.zip ?? ""
        contact.postalAddresses = [CNLabeledValue(label:CNLabelHome, value:homeAddress)]
        
        if contact_object?.birthday != nil {
            
            let birthday = NSDateComponents()
            birthday.day = contact_object!.birthday![2]
            birthday.month = contact_object!.birthday![1]
            birthday.year = contact_object!.birthday![0]
            contact.birthday = birthday as DateComponents
        }
        
        let viewCon = self.findViewController() as! BaseViewController
        let vc = CNContactViewController(forNewContact: contact)
        vc.delegate = viewCon
        let navCon = UINavigationController(rootViewController: vc)
        viewCon.present(navCon, animated: true, completion: nil)
    }
    
    @objc func createSpouseContact() {
        let contact = CNMutableContact()
        let contact_object = self.xaction_detail?.contact
        contact.givenName = contact_object?.spouseFirstName ?? ""
        contact.familyName = contact_object?.spouseLastName ?? ""
        let homeEmail = CNLabeledValue(label: CNLabelHome, value: (contact_object?.spouseEmail ?? "") as NSString)
        contact.emailAddresses = [homeEmail]
        
        for phone in contact_object!.spousePhones {
            contact.phoneNumbers.append(CNLabeledValue(
                label:CNLabelPhoneNumberiPhone,
                value:CNPhoneNumber(stringValue: phone.phone ?? "")))
        }
        
        if contact_object?.birthdaySpouse != nil {
            
            let birthday = NSDateComponents()
            birthday.day = contact_object!.birthdaySpouse![2]
            birthday.month = contact_object!.birthdaySpouse![1]
            birthday.year = contact_object!.birthdaySpouse![0]
            contact.birthday = birthday as DateComponents
        }
        
        let viewCon = self.findViewController() as! BaseViewController
        let vc = CNContactViewController(forNewContact: contact)
        vc.delegate = viewCon
        let navCon = UINavigationController(rootViewController: vc)
        viewCon.present(navCon, animated: true, completion: nil)
    }
    
    var delegate: TDBtmCellDelegate?
    
    func initCellContent(_ cont_ind: Int, _ expanded: Bool) {
        for i in 0 ..< contViews.count {
            if cont_ind != i {
                contViews[i].alpha = 0.0
            }
        }
        if expanded {
            contViews[cont_ind].alpha = 1.0
            btnArrow.setTitleColor(APP_GRAY_COLOR, for: .normal)
        }else {
            btnArrow.setTitleColor(APP_BLUE_COLOR, for: .normal)
        }
        let width: CGFloat = UIScreen.main.bounds.width - 32
        if cont_ind == 0 {
            var remark_height = self.xaction_detail?.remarks?.heightForView(UIFont(name: "Gordita-Regular", size: 12.0)!, width) ?? 14
            var instruction_height = self.xaction_detail?.instructions?.heightForView(UIFont(name: "Gordita-Regular", size: 12.0)!, width) ?? 14
            var otherinfo_height = self.xaction_detail?.listOtherInfo?.heightForView(UIFont(name: "Gordita-Regular", size: 12.0)!, width) ?? 14
            remark_height = remark_height < 14 ? 14 : remark_height
            instruction_height = instruction_height < 14 ? 14 : instruction_height
            otherinfo_height = otherinfo_height < 14 ? 14 : otherinfo_height
            self.contentHeight = remark_height + instruction_height + otherinfo_height + 580
        }else if cont_ind == 1 {
            var otherparty_height = self.xaction_detail?.otherParty?.heightForView(UIFont(name: "Gordita-Regular", size: 12.0)!, width) ?? 14
            var province_height = self.xaction_detail?.specialProvisions?.heightForView(UIFont(name: "Gordita-Regular", size: 12.0)!, width) ?? 14
            var otherinfo_height = self.xaction_detail?.contractOtherInfo?.heightForView(UIFont(name: "Gordita-Regular", size: 12.0)!, width) ?? 14
            otherparty_height = otherparty_height < 14 ? 14 : otherparty_height
            province_height = province_height < 14 ? 14 : province_height
            otherinfo_height = otherinfo_height < 14 ? 14 : otherinfo_height
            self.contentHeight = otherparty_height + province_height + otherinfo_height + 391
        }
    }
    
    @IBAction func actionOpenCell(_ sender: UIButton) {
        delegate?.openCell(self)
    }
    
}
