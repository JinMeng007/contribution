//
//  MainVC.swift
//  Uptime
//
//  Created by RSS on 10/2/18.
//  Copyright © 2018 HTK. All rights reserved.
//

import UIKit
import Crashlytics

class MainVC: BaseViewController {

    @IBOutlet weak var mainView: UIView!
    @IBOutlet var tabButtons: [UIButton]!
    @IBOutlet weak var lblBadge: UILabel!
    
    var prevBtn: Int = 100
    var viewCons: [UIViewController?]!
    var tabMenu: TabMenu!
    var menuOpen: Bool = false
    
    override func viewDidLoad() {
        super.viewDidLoad()

        let transactionVC = self.storyboard?.instantiateViewController(withIdentifier: "TransactionVC") as! TransactionVC
        let searchVC = self.storyboard?.instantiateViewController(withIdentifier: "SearchVC") as! SearchVC
        let taskVC = self.storyboard?.instantiateViewController(withIdentifier: "TaskVC") as! TaskVC
        let notificationVC = self.storyboard?.instantiateViewController(withIdentifier: "NotificationVC") as! NotificationVC
        
        NotificationCenter.default.addObserver(self, selector: #selector(self.setBadge), name: Notification.Name.init("SetBadge"), object: nil)
        
        self.setBadge()
        self.viewCons = [transactionVC, searchVC, taskVC, notificationVC]
        self.actionTab(tabButtons[prevBtn - 100])
    }
    
    @objc func setBadge() {
        API.sharedInstance.api_notification_count { (count) in
            DispatchQueue.main.async {
                if count == 0 {
                    self.lblBadge.alpha = 0.0
                }else {
                    self.lblBadge.alpha = 1.0
                    self.lblBadge.text = "\(count)"
                }
            }
        }
    }
    
    @IBAction func actionTab(_ sender: UIButton) {
        if self.viewCons[sender.tag - 100] != nil {
            if tabMenu != nil {
                self.menuOpen = false
                openMenu()
            }
            if sender.tag == 103 {
                self.setBadge()
            }
            self.tabButtons[prevBtn - 100].setTitleColor(APP_BLUE_COLOR, for: .normal)
            let previousVC = self.viewCons[prevBtn - 100]!
            let newVC = self.viewCons[sender.tag - 100]!
            previousVC.willMove(toParent: nil)
            previousVC.view.removeFromSuperview()
            previousVC.removeFromParent()
            addChild(newVC)
            self.prevBtn = sender.tag
            self.tabButtons[prevBtn - 100].setTitleColor(APP_ORANGE_COLOR, for: .normal)
            self.animateFadeDismissTransition(to: newVC)
        }
    }
    
    @IBAction func actionMenu(_ sender: UIButton) {
        self.menuOpen = !self.menuOpen
        if tabMenu == nil {
//            tabMenu = TabMenu(frame: CGRect(x: self.view.frame.width - 170, y: -140, width: 160, height: 140))
            tabMenu = TabMenu(frame: CGRect(x: self.view.frame.width - 170, y: self.view.frame.height - 221, width: 160, height: 160))
            tabMenu.alpha = 0.0
            self.view.addSubview(tabMenu)
        }
        openMenu()
    }
    
    func openMenu() {
        if self.menuOpen {
            self.tabButtons[4].setTitleColor(APP_ORANGE_COLOR, for: .normal)
            self.tabMenu.alpha = 1.0
//            self.tabMenu.fadeIn { (success) in
//
//            }
//            UIView.animate(withDuration: 0.5, delay: 0.0, options: .curveEaseOut, animations: {
//                self.tabMenu.transform = CGAffineTransform(translationX: 0, y:  self.view.frame.height - 61)
//            }, completion: { (finished: Bool) in
//
//            })
        }else {
            self.tabButtons[4].setTitleColor(APP_BLUE_COLOR, for: .normal)
            self.tabMenu.alpha = 0.0
//            self.tabMenu.fadeOut { (success) in
//
//            }
//            UIView.animate(withDuration: 0.5, delay: 0.0, options: .curveEaseOut, animations: {
//                self.tabMenu.transform = CGAffineTransform(translationX: 0, y: 0)
//            }, completion: { (finished: Bool) in
//
//            })
        }
    }
    
    func animateFadeDismissTransition(to newVC: UIViewController) {
        newVC.view.frame = self.mainView.bounds
//        self.mainView.alpha = 0.0
        self.mainView.addSubview(newVC.view)
//        DispatchQueue.main.async {
            newVC.didMove(toParent: self)
//            UIView.animate(withDuration: 0.5, delay: 0.0, options: .curveEaseOut, animations: {
//                self.mainView.alpha = 1.0
//            }, completion: { (finished: Bool) in
//
//            })
//        }
    }

}
