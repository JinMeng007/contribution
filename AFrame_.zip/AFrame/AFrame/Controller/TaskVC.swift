//
//  TaskVC.swift
//  AFrame
//
//  Created by Lee Sheng Jin on 2019/2/10.
//  Copyright © 2019 DrawRanger. All rights reserved.
//

import UIKit

class TaskVC: BaseViewController {
    
    @IBOutlet weak var tblTask: UITableView!
    
    var openTasks: [Any] = []
    let refreshCtrl: UIRefreshControl = UIRefreshControl()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        tblTask.delegate = self
        tblTask.dataSource = self
        tblTask.separatorStyle = .none
        tblTask.allowsSelection = false
        tblTask.register(UINib(nibName: "AFCell", bundle: nil), forCellReuseIdentifier: "afCell")
        
        refreshCtrl.frame = CGRect(x: 0, y: 50, width: refreshCtrl.frame.width, height: refreshCtrl.frame.height)
        refreshCtrl.tintColor = UIColor(red: 200 / 255, green: 200 / 255, blue: 200 / 255, alpha: 1.0)
        refreshCtrl.addTarget(self, action: #selector(self.getOpenTasks), for: .valueChanged)
        self.tblTask.refreshControl = refreshCtrl
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        self.getOpenTasks()
    }
    
    @objc func getOpenTasks() {
//        self.showHUD()
        API.sharedInstance.api_open_tasks(30) { (tasks) in
            DispatchQueue.main.async {
//                self.hideHUD()
                self.refreshCtrl.endRefreshing()
                if tasks != nil && tasks?.count != 0 {
                    self.openTasks.removeAll()
                    let dateFormatter = DateFormatter()
                    dateFormatter.dateFormat = "yyyy-MM-dd"
                    dateFormatter.locale = Locale(identifier: "en_US_POSIX")
                    let date1 = Date().utcToLocal(dateFormatter.dateFormat)
                    
                    var overdue_tasks: [Any] = []
                    var today_tasks: [Any] = []
                    var date_list: [String] = []
                    var future_tasks: [[Any]] = []
                    for task in tasks! {
                        let date2 = task.dueDate!.utcToLocal(dateFormatter.dateFormat)
                        if date1.compare(date2) == .orderedDescending {
                            if overdue_tasks.count == 0 {
                                overdue_tasks.append("Overdue")
                            }
                            overdue_tasks.append(task)
                        }
                        if date1.compare(date2) == .orderedSame {
                            if today_tasks.count == 0 {
                                today_tasks.append("Today")
                            }
                            today_tasks.append(task)
                        }
                        if date1.compare(date2) == .orderedAscending && !date_list.contains(task.dueDate!) {
                            date_list.append(task.dueDate!)
                        }
                    }
                    for i in 0 ..< date_list.count {
                        future_tasks.append([])
                        for task in tasks! {
                            if task.dueDate != nil && task.dueDate == date_list[i] {
                                if future_tasks[i].count == 0 {
                                    dateFormatter.dateFormat = "yyyy-MM-dd"
                                    let date = date_list[i].utcToLocal(dateFormatter.dateFormat)
                                    dateFormatter.dateFormat = "MMMM d (E)"
                                    future_tasks[i].append(dateFormatter.string(from: date))
                                }
                                future_tasks[i].append(task)
                            }
                        }
                    }
                    
                    // Overdue Tasks
                    for task in overdue_tasks {
                        self.openTasks.append(task)
                    }
                    // Today Tasks
                    for task in today_tasks {
                        self.openTasks.append(task)
                    }
                    // Future Tasks
                    for part_list in future_tasks {
                        for task in part_list {
                            self.openTasks.append(task)
                        }
                    }
                    self.tblTask.reloadData()
                }
            }
        }
    }

}

extension TaskVC: UITableViewDelegate, UITableViewDataSource, TaskCellDelegate {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return self.openTasks.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let contCell = tableView.dequeueReusableCell(withIdentifier: "afCell") as! AFCell
        contCell.subviews.forEach { (view) in
            if view is TaskCell {
                view.removeFromSuperview()
            }
        }
        var cell: TaskCell?
        if self.openTasks[indexPath.row] is String && self.openTasks[indexPath.row] as! String != "Completed" {
            cell = TaskCell(frame: CGRect(x: 0, y: 0, width: self.tblTask.frame.width, height: 50))
            cell?.loadNib(0)
        }else {
            cell = TaskCell(frame: CGRect(x: 0, y: 0, width: self.tblTask.frame.width, height: 50))
            cell?.loadNib(3)
        }
        if self.openTasks[indexPath.row] is Task {
            let task_instance = self.openTasks[indexPath.row] as? Task
            let height: CGFloat = task_instance?.subject?.heightForView(UIFont(name: "Gordita-Medium", size: 14.0)!, self.view.frame.width - 80) ?? 35
            var dy: CGFloat = -10
            if height > 25 {
                dy = height * 1.5 - 30
            }
            if task_instance?.status == "OPEN" || task_instance?.status == "IN_PROGRESS" || task_instance?.status == "PENDING" {
                cell = TaskCell(frame: CGRect(x: 0, y: 0, width: self.tblTask.frame.width, height: 105 + dy))
                cell?.loadNib(1)
            }else if task_instance?.status == "COMPLETE" {
                cell = TaskCell(frame: CGRect(x: 0, y: 0, width: self.tblTask.frame.width, height: 70 + dy))
                cell?.loadNib(4)
            }else {
                cell = TaskCell(frame: CGRect(x: 0, y: 0, width: self.tblTask.frame.width, height: 70 + dy))
                cell?.loadNib(2)
            }
        }
        cell?.task = self.openTasks[indexPath.row]
        cell?.delegate = self
        contCell.addSubview(cell!)
        return contCell
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        if self.openTasks[indexPath.row] is Task {
            let task_instance = self.openTasks[indexPath.row] as? Task
            let height: CGFloat = task_instance?.subject?.heightForView(UIFont(name: "Gordita-Medium", size: 14.0)!, self.view.frame.width - 80) ?? 35
            var dy: CGFloat = -10
            if height > 25 {
                dy = height * 1.5 - 30
            }
            if task_instance?.status == "OPEN" || task_instance?.status == "IN_PROGRESS" || task_instance?.status == "PENDING" {
                return 105 + dy
            }else {
                return 70 + dy
            }
        }else {
            return 50
        }
    }
    
    func removeTask(_ cell: TaskCell) {
        API.sharedInstance.api_complete_task((cell.task as! Task).taskId!)
        let indexPath = self.tblTask.indexPath(for: cell.superview as! UITableViewCell)
        if indexPath!.row + 1 < self.openTasks.count && self.openTasks[indexPath!.row + 1] is String && self.openTasks[indexPath!.row - 1] is String || indexPath!.row + 1 == self.openTasks.count && self.openTasks[indexPath!.row - 1] is String {
            self.openTasks.remove(at: indexPath!.row - 1)
            self.openTasks.remove(at: indexPath!.row - 1)
            let prevInd = IndexPath(row: indexPath!.row - 1, section: indexPath!.section)
            self.tblTask.deleteRows(at: [prevInd, indexPath!], with: UITableView.RowAnimation.automatic)
        }else {
            self.openTasks.remove(at: indexPath!.row)
            self.tblTask.deleteRows(at: [indexPath!], with: UITableView.RowAnimation.automatic)
        }
    }
    
    func snoozeTask(_ cell: TaskCell) {
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "yyyy-MM-dd"
        dateFormatter.locale = Locale(identifier: "en_US_POSIX")
        let in_task = cell.task as! Task
        let date1 = dateFormatter.date(from: in_task.dueDate ?? "") ?? Date().utcToLocal(dateFormatter.dateFormat)
        let indexPath = self.tblTask.indexPath(for: cell.superview as! UITableViewCell)
        if indexPath!.row + 1 < self.openTasks.count && self.openTasks[indexPath!.row + 1] is String && self.openTasks[indexPath!.row - 1] is String || indexPath!.row + 1 == self.openTasks.count && self.openTasks[indexPath!.row - 1] is String {
            self.openTasks.remove(at: indexPath!.row - 1)
            self.openTasks.remove(at: indexPath!.row - 1)
//            let former_i_path: IndexPath = IndexPath(row: indexPath!.row - 1, section: 0)
//            self.tblTask.beginUpdates()
//            self.tblTask.deleteRows(at: [former_i_path, indexPath!], with: .automatic)
//            self.tblTask.endUpdates()
        }else {
            self.openTasks.remove(at: indexPath!.row)
//            self.tblTask.beginUpdates()
//            self.tblTask.deleteRows(at: [indexPath!], with: .automatic)
//            self.tblTask.endUpdates()
        }
        
        var ind = 0
        var isExist: Bool = false
        for task in self.openTasks {
            if task is Task {
                let tmp_task = task as! Task
                let date2 = dateFormatter.date(from: tmp_task.dueDate ?? "") ?? Date().utcToLocal(dateFormatter.dateFormat)
                if date1.compare(date2) == .orderedSame || date1.compare(date2) == .orderedAscending {
                    isExist = false
                    let dateFM = DateFormatter()
                    dateFM.dateFormat = "MMMM d (E)"
                    dateFM.locale = Locale(identifier: "en_US_POSIX")
                    for task in self.openTasks {
                        if task is String {
                            let dateStr = task as! String
                            if dateStr == dateFM.string(from: date1) {
                                isExist = true
                                break
                            }
                        }
                    }
                    if !isExist {
                        isExist = true
                        if self.openTasks[ind - 1] is String {
                            self.openTasks.insert(dateFM.string(from: date1), at: ind - 1)
                        }else {
                            self.openTasks.insert(dateFM.string(from: date1), at: ind)
                            ind += 1
                        }
                    }
                    self.openTasks.insert(in_task, at: ind)
                    break
                }
                
            }
            ind += 1
        }
        if !isExist {
            let dateFM = DateFormatter()
            dateFM.dateFormat = "MMMM d (E)"
            dateFM.locale = Locale(identifier: "en_US_POSIX")
            self.openTasks.insert(dateFM.string(from: date1), at: ind)
            ind += 1
            self.openTasks.insert(in_task, at: ind)
        }
        self.tblTask.reloadData()
//        let indPath = IndexPath(row: ind - 1, section: 0)
//        let cellRect = self.tblTask.rectForRow(at: indPath)
//        if !self.tblTask.bounds.contains(cellRect) {
//            self.tblTask.scrollToRow(at: indPath, at: .top, animated: false)
//        }
//        self.tblTask.scrollToRow(at: indexPath!, at: .top, animated: false)
    }
    
}

