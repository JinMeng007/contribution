//
//  XActivityGenericVC.swift
//  AFrame
//
//  Created by Lee Sheng Jin on 2019/3/10.
//  Copyright © 2019 DrawRanger. All rights reserved.
//

import UIKit
import DropDown

class XActivityGenericVC: BaseViewController {
    
    @IBOutlet weak var scrView: UIScrollView!
    @IBOutlet weak var btnType: UIButton!
    @IBOutlet weak var txtNote: UITextView!
    @IBOutlet weak var txtLink: UITextField!
    @IBOutlet weak var txtActivityDate: UITextField!
    @IBOutlet weak var switchRS: AFSwitch!
    @IBOutlet weak var switchShow: AFSwitch!
    @IBOutlet weak var txtName: UITextField!
    @IBOutlet weak var txtCompany: UITextField!
    @IBOutlet weak var txtPhone1: UITextField!
    @IBOutlet weak var txtPhone2: UITextField!
    @IBOutlet weak var txtEmail: UITextField!
    @IBOutlet weak var txtExpense: UITextField!
    @IBOutlet weak var typeIcon: UILabel!
    @IBOutlet weak var txtAppUser: UITextField!
    
    var activity: XAGDetail?
    var transaction: TransactionDetail?
    let typeDropDown = DropDown()
    lazy var dropDowns: [DropDown] = {
        return [
            self.typeDropDown
        ]
    }()
    var typeOptions: [String] = []
    var xaction_activitytypes: [XactionActivityType] = []
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.showHUD()
        API.sharedInstance.api_xaction_activitytypes { (types) in
            DispatchQueue.main.async {
                self.hideHUD()
                if types != nil {
                    self.xaction_activitytypes = types!
                    for type in types! {
                        self.typeOptions.append(type.name!)
                    }
                    self.typeDropDown.dataSource = self.typeOptions
                }else {
                    self.alertViewController(title: "Oops!", message: "There are no available Activity Types now... Please try again later.")
                }
            }
        }
       
        self.scrView.contentSize = CGSize(width: 0, height: 700)
        
        if self.activity != nil {
            self.btnType.setTitle(activity?.xactionActivityType?.name, for: .normal)
            self.typeIcon.text = activity?.xactionActivityType?.name?.getFontIcon()
            self.txtNote.text = activity?.note
            self.txtLink.text = activity?.url
            self.txtAppUser.text = activity?.appUser?.displayFirstLast
            self.appDelegate.selected_appUser = activity?.appUser
            let dateFormatter = DateFormatter()
            dateFormatter.dateFormat = "yyyy-MM-dd"
            
            let dateStr = activity?.activityDate
            
            if dateStr != nil && dateStr != "" {
                let activityDate = dateStr!.utcToLocal(dateFormatter.dateFormat)
                dateFormatter.dateFormat = "MMM d, yyyy"
                self.txtActivityDate.text = dateFormatter.string(from: activityDate)
            }else {
                dateFormatter.dateFormat = "MMM d, yyyy"
                self.txtActivityDate.text = dateFormatter.string(from: Date().utcToLocal(dateFormatter.dateFormat))
            }
            switchShow.setOn(activity?.isNoShow ?? false, animated: false)
            switchRS.setOn(activity?.isSecondShowing ?? false, animated: false)
            self.txtName.text = activity?.contactName
            self.txtCompany.text = activity?.contactCompany
            self.txtPhone1.text = activity?.contactPhone1
            self.txtPhone2.text = activity?.contactPhone2
            self.txtEmail.text = activity?.contactEmail
            self.txtExpense.text = "\(activity?.expense ?? 0)"
        }else {
            self.activity = XAGDetail([:])
        }
        
        let datePV = UIDatePicker()
        datePV.datePickerMode = .date
        txtActivityDate.inputView = datePV
        datePV.addTarget(self, action: #selector(self.setDate(sender:)), for: .valueChanged)
        
        self.customizeDropDown(self)
        typeDropDown.anchorView = btnType
        typeDropDown.bottomOffset = CGPoint(x: -40, y: btnType.bounds.height)
        typeDropDown.width = btnType.bounds.width + 40
        typeDropDown.selectionAction = { [unowned self] (index, item) in
            DispatchQueue.main.async {
                self.btnType.setTitle(self.typeOptions[index], for: .normal)
                self.typeIcon.text = self.typeOptions[index].getFontIcon()
                self.activity?.xactionActivityTypeId = self.xaction_activitytypes[index].xactionActivityTypeId!
            }
        }
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        if self.appDelegate.selected_appUser != nil {
            self.txtAppUser.text = self.appDelegate.selected_appUser?.displayFirstLast
        }
    }
    
    func customizeDropDown(_ sender: AnyObject) {
        DropDown.setupDefaultAppearance()
        
        dropDowns.forEach {
            $0.cellNib = UINib(nibName: "DropDownCell", bundle: Bundle(for: DropDownCell.self))
            $0.cellHeight = 35
            $0.customCellConfiguration = nil
        }
    }
    
    @IBAction func actionType(_ sender: UIButton) {
        self.view.endEditing(true)
        typeDropDown.show()
    }
    
    @objc func setDate(sender: UIDatePicker) {
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "MMM d, yyyy"
        txtActivityDate.text = dateFormatter.string(from: sender.date)
    }
    
    @IBAction func actionBack(_ sender: UIButton) {
        if sender.tag == 100 {
            var param: [String: Any] = [
                "appUserId": self.appDelegate.selected_appUser?.appUserId ?? 0,
                "xactionActivityTypeId": self.activity?.xactionActivityTypeId ?? 0,
                "url": self.txtLink.text!,
                "contactName": self.txtName.text!,
                "contactCompany": self.txtCompany.text!,
                "contactPhone1": self.txtPhone1.text!,
                "contactPhone2": self.txtPhone2.text!,
                "contactEmail": self.txtEmail.text!,
                "expense": Float(self.txtExpense.text!) ?? 0,
                "isNoShow": switchShow.isOn,
                "isSecondShowing": switchRS.isOn,
                "note": txtNote.text!
            ]
            if txtActivityDate.text != "" {
                let dateFormatter = DateFormatter()
                dateFormatter.dateFormat = "MMM d, yyyy"
                let dueDate = self.txtActivityDate.text!.utcToLocal(dateFormatter.dateFormat)
                dateFormatter.dateFormat = "MM/dd/yyyy"
                param.updateValue(dateFormatter.string(from: dueDate), forKey: "activityDate")
            }
            
            if self.activity?.xactionActivityId == nil || self.activity?.xactionActivityId == 0 {
                if checkFields() == nil {
                    param.updateValue(self.transaction!.xactionId!, forKey: "xactionId")
                    API.sharedInstance.api_xactionactivity_generic_create(param)
                    self.appDelegate.selected_appUser = nil
                    self.navigationController?.popViewController(animated: true)
                }else {
                    self.alertViewController(title: "Oops!", message: checkFields()!)
                }
            }else {
                API.sharedInstance.api_xactionactivity_generic_patch(activity!.xactionActivityId!, param)
                self.appDelegate.selected_appUser = nil
                self.navigationController?.popViewController(animated: true)
            }
        }else {
            self.appDelegate.selected_appUser = nil
            self.navigationController?.popViewController(animated: true)
        }
    }
    
    func checkFields() -> String? {
        if self.appDelegate.selected_appUser?.appUserId == nil {
            return "Please select App user."
        }
        if self.activity?.xactionActivityTypeId == nil {
            return "Please select Transaction Activity Type."
        }
        if txtNote.text == "" {
            return "Please input Note text."
        }
        if txtActivityDate.text == "" {
            return "Please input Activate Date."
        }
        return nil
    }
    
    @IBAction func actionAppUsers(_ sender: UIButton) {
        self.showHUD()
        API.sharedInstance.api_active_app_users(activity?.appUserId ?? User.sharedInstance.appUserId!) { (active_users) in
            DispatchQueue.main.async {
                self.hideHUD()
                if active_users != nil {
                    let vc = self.storyboard?.instantiateViewController(withIdentifier: "UsersVC") as! UsersVC
                    vc.appUsers = active_users!
                    self.present(vc, animated: true, completion: nil)
                }
            }
        }
    }
    
}
