//
//  LoginVC.swift
//  AFrame
//
//  Created by Lee Sheng Jin on 2019/2/10.
//  Copyright © 2019 DrawRanger. All rights reserved.
//

import UIKit

class LoginVC: BaseViewController {
    
    @IBOutlet var loginFields: [UIView]!
    @IBOutlet weak var btnEye: UIButton!
    @IBOutlet weak var txtPWD: UITextField!
    @IBOutlet weak var txtUsername: UITextField!
    @IBOutlet weak var scrView: UIScrollView!
    @IBOutlet weak var separateView: UIView!
    @IBOutlet weak var btnSignup: UIButton!
    @IBOutlet weak var lblLogin: UILabel!
    @IBOutlet weak var imgLogo: UIImageView!
    @IBOutlet weak var loginView: UIView!
    
    var showKeyboard: Bool = false
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.scrView.contentInset = UIEdgeInsets.zero
        self.scrView.contentInsetAdjustmentBehavior = .never
        self.scrView.contentSize = CGSize(width: 0, height: 600)
        self.addObservers()
        self.initView()
    }
    
    func addObservers() {
        NotificationCenter.default.addObserver(self, selector: #selector(self.keyboardWasShown), name: UIResponder.keyboardWillShowNotification, object: nil)
        NotificationCenter.default.addObserver(self, selector: #selector(self.keyboardWillBeHidden), name: UIResponder.keyboardWillHideNotification, object: nil)
    }
    
    @objc func keyboardWasShown(_ notification: Notification){
        
        if let keyboardFrame: NSValue = notification.userInfo?[UIResponder.keyboardFrameEndUserInfoKey] as? NSValue {
            let keyboardRectangle = keyboardFrame.cgRectValue
            let keyboardHeight = keyboardRectangle.height
            
            if showKeyboard == false {
                showKeyboard = true
                btnSignup.alpha = 1.0
                separateView.alpha = 0.0
                lblLogin.alpha = 0.0
                
                if self.view.frame.height - keyboardHeight - 470 < -120 {
                    self.imgLogo.alpha = 0.0
                }else {
                    imgLogo.transform = CGAffineTransform(translationX: 0, y: -35).concatenating(CGAffineTransform(scaleX: 0.8, y: 0.8))
                }
                if self.view.frame.height - keyboardHeight - 470 < 0 {
                    self.loginView.transform = CGAffineTransform(translationX: 0, y: self.view.frame.height - keyboardHeight - 470)
                    self.scrView.contentSize = CGSize(width: 0, height: 570 - keyboardHeight)
                }
            }
        }
        
    }
    
    @objc func keyboardWillBeHidden(){
        if showKeyboard == true {
            showKeyboard = false
            btnSignup.alpha = 0.0
            separateView.alpha = 1.0
            lblLogin.alpha = 1.0
            if imgLogo.alpha == 1 {
                imgLogo.transform = CGAffineTransform(translationX: 0, y: 0).concatenating(CGAffineTransform(scaleX: 1, y: 1))
            }else {
                imgLogo.alpha = 1.0
            }
            self.loginView.transform = CGAffineTransform(translationX: 0, y: 0)
            self.scrView.contentSize = CGSize(width: 0, height: 600)
        }
    }
    
    func initView() {
        for i in 0 ..< loginFields.count {
            loginFields[i].layer.borderColor = APP_GRAY_COLOR.cgColor
            loginFields[i].layer.borderWidth = 1.0
        }
    }
    
    @IBAction func actionShow(_ sender: UIButton) {
        if txtPWD.isSecureTextEntry {
            txtPWD.isSecureTextEntry = false
            btnEye.setTitle(AppIcons.eye.rawValue, for: .normal)
        }else {
            txtPWD.isSecureTextEntry = true
            btnEye.setTitle(AppIcons.eye_slash.rawValue, for: .normal)
        }
    }
    
    func checkFields() -> String? {
        if txtUsername.text == "" {
            return "Please input Username."
        }
        if txtPWD.text == "" {
            return "Please input Password."
        }
        return nil
    }
    
    @IBAction func actionLogin(_ sender: UIButton) {
        if let errMsg = checkFields() {
            self.alertViewController(title: "Oops!", message: errMsg)
        }else {
            self.showHUD()
            User.sharedInstance.userName = txtUsername.text!
            User.sharedInstance.password = txtPWD.text!
            API.sharedInstance.api_authentication(txtUsername.text!, txtPWD.text!) { (errMsg) in
                DispatchQueue.main.async {
                    self.hideHUD()
                    if errMsg == nil {
                        self.appDelegate.makingRoot("enterApp")
                    }else {
                        self.alertViewController(title: "Oops!", message: errMsg!)
                    }
                }
            }
        }
    }
    
    @IBAction func actionSignup(_ sender: UIButton) {
        let vc = self.storyboard?.instantiateViewController(withIdentifier: "SignUpVC") as! SignUpVC
        self.navigationController?.pushViewController(vc, animated: true)
    }
    
    @IBAction func actionForgotPWD(_ sender: UIButton) {
        if URL(string: APIURL.forgot_password) != nil {
            UIApplication.shared.open(URL(string: APIURL.forgot_password)!, options: [:], completionHandler: nil)
        }
    }
    
}
