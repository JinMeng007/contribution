//
//  AttachmentsVC.swift
//  AFrame
//
//  Created by Lee Sheng Jin on 2019/2/13.
//  Copyright © 2019 DrawRanger. All rights reserved.
//

import UIKit

class AttachmentsVC: BaseViewController {
    
    @IBOutlet weak var scrView: UIScrollView!
    @IBOutlet weak var lblAddress: UILabel!
    
    var xaction_detail: TransactionDetail?
    var attachments: [Any] = []
    
    let refreshCtrl: UIRefreshControl = UIRefreshControl()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.lblAddress.text = xaction_detail?.address?.addressLineString
        refreshCtrl.frame = CGRect(x: 0, y: 50, width: refreshCtrl.frame.width, height: refreshCtrl.frame.height)
        refreshCtrl.tintColor = UIColor(red: 200 / 255, green: 200 / 255, blue: 200 / 255, alpha: 1.0)
        refreshCtrl.addTarget(self, action: #selector(self.getXactionAttachments), for: .valueChanged)
        self.scrView.refreshControl = refreshCtrl
        self.getXactionAttachments()
    }
    
    @objc func getXactionAttachments() {
//        self.showHUD()
        API.sharedInstance.api_xaction_attatchments(self.xaction_detail!.xactionId!) { (attachments) in
            DispatchQueue.main.async {
//                self.hideHUD()
                self.refreshCtrl.endRefreshing()
                if attachments != nil {
                    self.attachments.removeAll()
                    for i in 0 ..< attachments!.count {
                        if attachments![i].folder?.folderId != nil {
                            self.attachments.append(attachments![i].folder!.name!)
                        }
                        for attachment in attachments![i].apiXactionAttachments {
                            self.attachments.append(attachment)
                        }
                    }
                    self.drawCells()
                }
            }
        }
    }
    
    func drawCells() {
        var cell: AttachmentCell?
        var last_cell: AttachmentCell?
        var offset_y: CGFloat = 61.0
        self.scrView.subviews.forEach { (view) in
            if view is AttachmentCell {
                view.removeFromSuperview()
            }
        }
        for attachment in self.attachments {
            if last_cell != nil {
                offset_y = last_cell!.frame.origin.y + last_cell!.frame.height
            }
            var offset_x: CGFloat = 0
            if !(attachment is String) && (attachment as! XActionAttachmentDetail).folder?.folderId != nil {
                offset_x = 10
            }
            cell = AttachmentCell(frame: CGRect(x: offset_x, y: offset_y, width: self.scrView.frame.width - offset_x, height: 60))
            if attachment is String {
                cell?.loadNib(1)
            }else {
                cell?.loadNib(0)
            }
            cell?.attachment = attachment
            last_cell = cell
            self.scrView.addSubview(cell!)
            self.scrView.contentSize = CGSize(width: 0, height: last_cell!.frame.origin.y + last_cell!.frame.height)
        }
    }
    
    @IBAction func actionBack(_ sender: UIButton) {
        self.navigationController?.popViewController(animated: true)
    }
    
    @IBAction func actionGotoLink(_ sender: UIButton) {
        if URL(string: self.xaction_detail?.siteUrl ?? "") != nil {
            UIApplication.shared.open(URL(string: self.xaction_detail?.siteUrl ?? "")!, options: [:], completionHandler: nil)
        }
    }
    
}
