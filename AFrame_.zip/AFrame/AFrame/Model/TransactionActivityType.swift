//
//  TransactionActivityType.swift
//  AFrame
//
//  Created by Lee Sheng Jin on 2019/2/27.
//  Copyright © 2019 DrawRanger. All rights reserved.
//

import UIKit

class TransactionActivityType: NSObject {
    var xactionActivityTypeId: Int?
    var name: String?
    init?(_ info: NSDictionary) {
        self.xactionActivityTypeId = info.value(forKey: "xactionActivityTypeId") as? Int
        self.name = info.value(forKey: "name") as? String
    }
}
