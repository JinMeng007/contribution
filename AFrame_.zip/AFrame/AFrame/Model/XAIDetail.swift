//
//  XAIDetail.swift
//  AFrame
//
//  Created by Lee Sheng Jin on 2019/3/11.
//  Copyright © 2019 DrawRanger. All rights reserved.
//

import UIKit

class XAIDetail: NSObject {
    var xactionActivityImportId: Int?
    var showingImportActivityId: Int?
    var isPrivate: Bool?
    var isPublished: Bool?
    var activityDate: String?
    var editDateTime: Double?
    var showType: String?
    var showStatus: String?
    var showTime: String?
    var listMlsId: String?
    var listAgentId: String?
    var feedback: String?
    var hasCustomFeedback: Bool?
    var isNoShow: Bool?
    var isSecondShowing: Bool?
    var showAgentId: String?
    var showAgentName: String?
    var showAgentCompany: String?
    var showAgentPhone1: String?
    var showAgentPhone1Desc: String?
    var showAgentPhone2: String?
    var showAgentPhone2Desc: String?
    var showAgentPhone3: String?
    var showAgentPhone3Desc: String?
    var showAgentEmail: String?
    var xactionId: Int?
    var is_private: Bool?
    var noShow: Bool?
    var secondShowing: Bool?
    var deleted: Bool?
    var published: Bool?
    init? (_ info: NSDictionary) {
        self.xactionActivityImportId = info.value(forKey: "xactionActivityImportId") as? Int
        self.showingImportActivityId = info.value(forKey: "showingImportActivityId") as? Int
        self.isPrivate = info.value(forKey: "isPrivate") as? Bool ?? false
        self.isPublished = info.value(forKey: "isPublished") as? Bool ?? false
        self.activityDate = info.value(forKey: "activityDate") as? String
        self.editDateTime = info.value(forKey: "editDateTime") as? Double
        self.showType = info.value(forKey: "showType") as? String
        self.showStatus = info.value(forKey: "showStatus") as? String
        self.showTime = info.value(forKey: "showTime") as? String
        self.listMlsId = info.value(forKey: "listMlsId") as? String
        self.listAgentId = info.value(forKey: "listAgentId") as? String
        self.feedback = info.value(forKey: "feedback") as? String
        self.hasCustomFeedback = info.value(forKey: "hasCustomFeedback") as? Bool ?? false
        self.isNoShow = info.value(forKey: "isNoShow") as? Bool ?? false
        self.isSecondShowing = info.value(forKey: "isSecondShowing") as? Bool ?? false
        self.showAgentId = info.value(forKey: "showAgentId") as? String
        self.showAgentName = info.value(forKey: "showAgentName") as? String
        self.showAgentCompany = info.value(forKey: "showAgentCompany") as? String
        self.showAgentPhone1 = info.value(forKey: "showAgentPhone1") as? String
        self.showAgentPhone1Desc = info.value(forKey: "showAgentPhone1Desc") as? String
        self.showAgentPhone2 = info.value(forKey: "showAgentPhone2") as? String
        self.showAgentPhone2Desc = info.value(forKey: "showAgentPhone2Desc") as? String
        self.showAgentPhone3 = info.value(forKey: "showAgentPhone3") as? String
        self.showAgentPhone3Desc = info.value(forKey: "showAgentPhone3Desc") as? String
        self.showAgentEmail = info.value(forKey: "showAgentEmail") as? String
        self.xactionId = info.value(forKey: "xactionId") as? Int
        self.is_private = info.value(forKey: "private") as? Bool ?? false
        self.noShow = info.value(forKey: "noShow") as? Bool ?? false
        self.secondShowing = info.value(forKey: "secondShowing") as? Bool ?? false
        self.deleted = info.value(forKey: "deleted") as? Bool ?? false
        self.published = info.value(forKey: "published") as? Bool ?? false
    }
}
