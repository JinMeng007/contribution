//
//  TransactionActivity.swift
//  AFrame
//
//  Created by Lee Sheng Jin on 2019/2/27.
//  Copyright © 2019 DrawRanger. All rights reserved.
//

import UIKit

class TransactionActivity: NSObject {
    var xactionActivityClass: String?
    var xactionActivityGeneric: TransactionGeneric?
    var xactionActivityImport: TransactionImport?
    var task: Task?
    init?(_ info: NSDictionary) {
        self.xactionActivityClass = info.value(forKey: "xactionActivityClass") as? String
        if !(info.value(forKey: "xactionActivityImport") is NSNull) {
            self.xactionActivityImport = TransactionImport(info.value(forKey: "xactionActivityImport") as! NSDictionary)
        }
        if !(info.value(forKey: "xactionActivityGeneric") is NSNull) {
            self.xactionActivityGeneric = TransactionGeneric(info.value(forKey: "xactionActivityGeneric") as! NSDictionary)
        }
        if !(info.value(forKey: "task") is NSNull) {
            self.task = Task(info.value(forKey: "task") as! NSDictionary)
        }
    }
}
