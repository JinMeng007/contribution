//
//  TransactionGeneric.swift
//  AFrame
//
//  Created by Lee Sheng Jin on 2019/2/27.
//  Copyright © 2019 DrawRanger. All rights reserved.
//

import UIKit

class TransactionGeneric: NSObject {
    var xactionActivityId: Int?
    var isPrivate: Bool?
    var isPublished: Bool?
    var activityDate: String?
    var note: String?
    var expense: Float?
    var isSecondShowing: Bool?
    var isNoShow: Bool?
    var contactName: String?
    var contactCompany: String?
    var contactPhone1: String?
    var contactPhone1Desc: String?
    var contactPhone2: String?
    var contactPhone2Desc: String?
    var contactEmail: String?
    var url: String?
    var fileName: String?
    var xactionId: Int?
    var appUserId: Int?
    var appUser: AppUser?
    var xactionActivityTypeId: Int?
    var xactionActivityType: TransactionActivityType?
    var fileUrl: String?
    
    init?(_ info: NSDictionary) {
        self.xactionActivityId = info.value(forKey: "xactionActivityId") as? Int
        self.isPrivate = info.value(forKey: "isPrivate") as? Bool
        self.isPublished = info.value(forKey: "isPublished") as? Bool
        self.activityDate = info.value(forKey: "activityDate") as? String
        self.note = info.value(forKey: "note") as? String
        self.expense = info.value(forKey: "expense") as? Float
        self.isSecondShowing = info.value(forKey: "isSecondShowing") as? Bool
        self.isNoShow = info.value(forKey: "isNoShow") as? Bool
        self.contactName = info.value(forKey: "contactName") as? String
        self.contactCompany = info.value(forKey: "contactCompany") as? String
        self.contactPhone1 = info.value(forKey: "contactPhone1") as? String
        self.contactPhone1Desc = info.value(forKey: "contactPhone1Desc") as? String
        self.contactPhone2 = info.value(forKey: "contactPhone2") as? String
        self.contactPhone2Desc = info.value(forKey: "contactPhone2Desc") as? String
        self.contactEmail = info.value(forKey: "contactEmail") as? String
        self.url = info.value(forKey: "url") as? String
        self.fileName = info.value(forKey: "fileName") as? String
        self.xactionId = info.value(forKey: "xactionId") as? Int
        self.appUserId = info.value(forKey: "appUserId") as? Int
        self.appUser = AppUser(info.value(forKey: "appUser") as! NSDictionary)
        self.xactionActivityTypeId = info.value(forKey: "xactionActivityTypeId") as? Int
        self.xactionActivityType = TransactionActivityType(info.value(forKey: "xactionActivityType") as! NSDictionary)
        self.fileUrl = info.value(forKey: "fileUrl") as? String
    }
}
