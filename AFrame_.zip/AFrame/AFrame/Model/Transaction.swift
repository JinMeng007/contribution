//
//  Transaction.swift
//  AFrame
//
//  Created by Lee Sheng Jin on 2019/2/21.
//  Copyright © 2019 DrawRanger. All rights reserved.
//

import UIKit

class Transaction: NSObject {
    var xactionId: Int?
    var address: Address?
    var status: String?
    var statusColorHex: String?
    var statusStage: Int?
    var price: Int?
    var listDate: String?
    var closingDate: String?
    var closedDate: String?
    var listPrice: String?
    var listPriceOriginal: String?
    var contractPrice: Int?
    var expireDate: String?
    var effectiveDate: String?
    var xactionSide: String?
    var createDateTime: Double?
    var editDateTime: Double?
    var contact: Contact?
    init?(_ info: NSDictionary) {
        self.xactionId = info.value(forKey: "xactionId") as? Int
        self.address = Address(info.value(forKey: "address") as! NSDictionary)
        self.status = info.value(forKey: "status") as? String
        self.statusColorHex = info.value(forKey: "statusColorHex") as? String
        self.statusStage = info.value(forKey: "statusStage") as? Int
        self.price = info.value(forKey: "price") as? Int
        self.listDate = info.value(forKey: "listDate") as? String
        self.closingDate = info.value(forKey: "closingDate") as? String
        self.closedDate = info.value(forKey: "closedDate") as? String
        self.listPrice = info.value(forKey: "listPrice") as? String
        self.listPriceOriginal = info.value(forKey: "listPriceOriginal") as? String
        self.contractPrice = info.value(forKey: "contractPrice") as? Int
        self.expireDate = info.value(forKey: "expireDate") as? String
        self.effectiveDate = info.value(forKey: "effectiveDate") as? String
        self.xactionSide = info.value(forKey: "xactionSide") as? String
        self.createDateTime = info.value(forKey: "createDateTime") as? Double
        self.editDateTime = info.value(forKey: "editDateTime") as? Double
        self.contact = Contact(info.value(forKey: "contact") as! NSDictionary)
    }
}
