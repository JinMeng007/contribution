//
//  TaskDetail.swift
//  AFrame
//
//  Created by Lee Sheng Jin on 2019/3/14.
//  Copyright © 2019 DrawRanger. All rights reserved.
//

import UIKit

class TaskDetail: NSObject {
    var taskId: Int?
    var subject: String?
    var note: String?
    var taskType: String?
    var status: String?
    var dueDate: String?
    var isRecurring: Bool?
    var recurringFrequency: String?
    var recurringSeparationCount: Int?
    var recurringEndDate: String?
    var recurringDayOfWeek: String?
    var recurringDayOfMonth: Int?
    var recurringMonthOfYear: String?
    var completeDate: String?
    var isPublished: Bool?
    var reminderSet: Bool?
    var reminderDate: String?
    var reminderTimeMinutes: Int?
    var expense: Float?
    var sort: Int?
    var editDateTime: Double?
    var createDateTime: Double?
    var appUser: AppUser?
    var appUserId: Int?
    var contact: Contact?
    var contactId: Int?
    var xaction: TransactionDetail?
    var xactionId: Int?
    var letterTemplate: String?
    var letterTemplateId: Int?
    var prospecting: Bool?
    var recurring: Bool?
    var published: Bool?
    
    init?(_ info: NSDictionary) {
        self.taskId = info.value(forKey: "taskId") as? Int
        self.subject = info.value(forKey: "subject") as? String
        self.note = info.value(forKey: "note") as? String
        self.taskType = info.value(forKey: "taskType") as? String
        self.status = info.value(forKey: "status") as? String
        self.dueDate = info.value(forKey: "dueDate") as? String
        self.isRecurring = info.value(forKey: "isRecurring") as? Bool ?? false
        self.recurringFrequency = info.value(forKey: "recurringFrequency") as? String
        self.recurringSeparationCount = info.value(forKey: "recurringSeparationCount") as? Int
        self.recurringEndDate = info.value(forKey: "recurringEndDate") as? String
        self.recurringDayOfWeek = info.value(forKey: "recurringDayOfWeek") as? String
        self.recurringDayOfMonth = info.value(forKey: "recurringDayOfMonth") as? Int
        self.recurringMonthOfYear = info.value(forKey: "recurringMonthOfYear") as? String
        self.completeDate = info.value(forKey: "completeDate") as? String
        self.isPublished = info.value(forKey: "isPublished") as? Bool ?? false
        self.reminderSet = info.value(forKey: "reminderSet") as? Bool ?? false
        self.reminderDate = info.value(forKey: "reminderDate") as? String
        self.reminderTimeMinutes = info.value(forKey: "reminderTimeMinutes") as? Int
        self.expense = info.value(forKey: "expense") as? Float
        self.sort = info.value(forKey: "sort") as? Int
        self.editDateTime = info.value(forKey: "editDateTime") as? Double
        self.createDateTime = info.value(forKey: "createDateTime") as? Double
        if !(info.value(forKey: "appUser") is NSNull) && info.value(forKey: "appUser") != nil {
            self.appUser = AppUser(info.value(forKey: "appUser") as! NSDictionary)
        }
        self.appUserId = info.value(forKey: "appUserId") as? Int
        if !(info.value(forKey: "contact") is NSNull) && info.value(forKey: "contact") != nil {
            self.contact = Contact(info.value(forKey: "contact") as! NSDictionary)
        }
        self.contactId = info.value(forKey: "contactId") as? Int
        if !(info.value(forKey: "xaction") is NSNull) && info.value(forKey: "xaction") != nil {
            self.xaction = TransactionDetail(info.value(forKey: "xaction") as! NSDictionary)
        }
        self.xactionId = info.value(forKey: "xactionId") as? Int
        self.letterTemplate = info.value(forKey: "letterTemplate") as? String
        self.letterTemplateId = info.value(forKey: "letterTemplateId") as? Int
        self.prospecting = info.value(forKey: "prospecting") as? Bool ?? false
        self.recurring = info.value(forKey: "recurring") as? Bool ?? false
        self.published = info.value(forKey: "published") as? Bool ?? false
    }
}
