//
//  XAGDetail.swift
//  AFrame
//
//  Created by Lee Sheng Jin on 2019/3/11.
//  Copyright © 2019 DrawRanger. All rights reserved.
//

import UIKit

class XAGDetail: NSObject {
    var xactionActivityId: Int?
    var uidRef: String?
    var isPrivate: Bool?
    var isPublished: Bool?
    var activityDate: String?
    var editDateTime: Double?
    var note: String?
    var expense: Float?
    var isSecondShowing: Bool?
    var isNoShow: Bool?
    var contactName: String?
    var contactCompany: String?
    var contactPhone1: String?
    var contactPhone1Desc: String?
    var contactPhone2: String?
    var contactPhone2Desc: String?
    var contactEmail: String?
    var url: String?
    var physicalFileName: String?
    var contentType: String?
    var fileSizeByes: Double?
    var fileName: String?
    var xactionId: Int?
    var appUserId: Int?
    var appUser: AppUser?
    var xactionActivityTypeId: Int?
    var xactionActivityType: TransactionActivityType?
    var is_private: Bool?
    var secondShowing: Bool?
    var noShow: Bool?
    var published: Bool?
    
    init?(_ info: NSDictionary) {
        self.xactionActivityId = info.value(forKey: "xactionActivityId") as? Int
        self.uidRef = info.value(forKey: "uidRef") as? String
        self.isPrivate = info.value(forKey: "isPrivate") as? Bool ?? false
        self.isPublished = info.value(forKey: "isPublished") as? Bool ?? false
        self.activityDate = info.value(forKey: "activityDate") as? String
        self.editDateTime = info.value(forKey: "editDateTime") as? Double
        self.note = info.value(forKey: "note") as? String
        self.expense = info.value(forKey: "expense") as? Float ?? 0
        self.isSecondShowing = info.value(forKey: "isSecondShowing") as? Bool ?? false
        self.isNoShow = info.value(forKey: "isNoShow") as? Bool ?? false
        self.contactName = info.value(forKey: "contactName") as? String
        self.contactCompany = info.value(forKey: "contactCompany") as? String
        self.contactPhone1 = info.value(forKey: "contactPhone1") as? String
        self.contactPhone1Desc = info.value(forKey: "contactPhone1Desc") as? String
        self.contactPhone2 = info.value(forKey: "contactPhone2") as? String
        self.contactPhone2Desc = info.value(forKey: "contactPhone2Desc") as? String
        self.contactEmail = info.value(forKey: "contactEmail") as? String
        self.url = info.value(forKey: "url") as? String
        self.physicalFileName = info.value(forKey: "physicalFileName") as? String
        self.contentType = info.value(forKey: "contentType") as? String
        self.fileSizeByes = info.value(forKey: "fileSizeByes") as? Double
        self.fileName = info.value(forKey: "fileName") as? String
        self.xactionId = info.value(forKey: "xactionId") as? Int
        self.appUserId = info.value(forKey: "appUserId") as? Int
        if info.value(forKey: "appUser") != nil {
            self.appUser = AppUser(info.value(forKey: "appUser") as! NSDictionary)
        }
        self.xactionActivityTypeId = info.value(forKey: "xactionActivityTypeId") as? Int
        if info.value(forKey: "xactionActivityType") != nil {
            self.xactionActivityType = TransactionActivityType(info.value(forKey: "xactionActivityType") as! NSDictionary)
        }
        self.is_private = info.value(forKey: "private") as? Bool ?? false
        self.secondShowing = info.value(forKey: "secondShowing") as? Bool ?? false
        self.noShow = info.value(forKey: "noShow") as? Bool ?? false
        self.published = info.value(forKey: "published") as? Bool ?? false
    }
}
