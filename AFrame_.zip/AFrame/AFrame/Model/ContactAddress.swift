//
//  ContactAddress.swift
//  AFrame
//
//  Created by Lee Sheng Jin on 2019/2/25.
//  Copyright © 2019 DrawRanger. All rights reserved.
//

import UIKit

class ContactAddress: NSObject {
    var address1: String?
    var address2: String?
    var city: String?
    var state: String?
    var zip: String?
    var country: String?
    var latitude: Double?
    var longitude: Double?
    var addressLineString: String?
    var cszstring: String?
    var addressFullString: String?
    var googleMapsUrlString: String?
    var addressComplete: Bool?
    init?(_ info: NSDictionary) {
        self.address1 = info.value(forKey: "address1") as? String
        self.address2 = info.value(forKey: "address2") as? String
        self.city = info.value(forKey: "city") as? String
        self.state = info.value(forKey: "state") as? String
        self.zip = info.value(forKey: "zip") as? String
        self.country = info.value(forKey: "country") as? String
        self.latitude = info.value(forKey: "latitude") as? Double
        self.longitude = info.value(forKey: "longitude") as? Double
        self.addressLineString = info.value(forKey: "addressLineString") as? String ?? info.value(forKey: "addressLine") as? String
        self.cszstring = info.value(forKey: "cszstring") as? String ?? info.value(forKey: "addressCSZ") as? String
        self.addressFullString = info.value(forKey: "addressFullString") as? String ?? info.value(forKey: "addressFull") as? String
        self.googleMapsUrlString = info.value(forKey: "googleMapsUrl") as? String
        self.addressComplete = info.value(forKey: "addressComplete") as? Bool
    }
}
