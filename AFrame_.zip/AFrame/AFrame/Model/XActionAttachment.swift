//
//  XActionAttachment.swift
//  AFrame
//
//  Created by Lee Sheng Jin on 2019/2/27.
//  Copyright © 2019 DrawRanger. All rights reserved.
//

import UIKit

class XActionAttachment: NSObject {
    var folder: Folder?
    var apiXactionAttachments: [XActionAttachmentDetail] = []
    init?(_ info: NSDictionary) {
        self.folder = Folder(info.value(forKey: "folder") as! NSDictionary)
        let apiXactionAttachments_arr = info.value(forKey: "apiXactionAttachments") as? NSArray
        for attachment in apiXactionAttachments_arr! {
            self.apiXactionAttachments.append(XActionAttachmentDetail(attachment as! NSDictionary)!)
        }
    }
}
