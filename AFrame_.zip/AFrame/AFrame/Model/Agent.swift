//
//  Agent.swift
//  AFrame
//
//  Created by Lee Sheng Jin on 2019/4/4.
//  Copyright © 2019 DrawRanger. All rights reserved.
//

import UIKit

class Agent: NSObject {
    var lastName: String?
    var phones: [Phone] = []
    var userName: String?
    var firstName: String?
    var calendarFeedUrl: String?
    var active: Int?
    var email: String?
    var displayLastFirst: String?
    var displayFirstLast: String?
    var appUserId: Int?
    
    init?(_ info: NSDictionary) {
        self.lastName = info.value(forKey: "lastName") as? String
        if info.value(forKey: "phones") != nil {
            for item in info.value(forKey: "phones") as! NSArray {
                self.phones.append(Phone(item as! NSDictionary)!)
            }
        }
        self.userName = info.value(forKey: "userName") as? String
        self.firstName = info.value(forKey: "firstName") as? String
        self.calendarFeedUrl = info.value(forKey: "calendarFeedUrl") as? String
        self.active = info.value(forKey: "active") as? Int ?? 0
        self.email = info.value(forKey: "email") as? String
        self.displayLastFirst = info.value(forKey: "displayLastFirst") as? String
        self.displayFirstLast = info.value(forKey: "displayFirstLast") as? String
        self.appUserId = info.value(forKey: "appUserId") as? Int ?? 0
    }
}
