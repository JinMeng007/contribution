//
//  AppUser.swift
//  AFrame
//
//  Created by Lee Sheng Jin on 2019/2/21.
//  Copyright © 2019 DrawRanger. All rights reserved.
//

import UIKit

class AppUser: NSObject {
    var appUserId: Int?
    var firstName: String?
    var lastName: String?
    var displayLastFirst: String?
    var displayFirstLast: String?
    
    init?(_ info: NSDictionary) {
        self.appUserId = info.value(forKey: "appUserId") as? Int
        self.firstName = info.value(forKey: "firstName") as? String
        self.lastName = info.value(forKey: "lastName") as? String
        self.displayLastFirst = info.value(forKey: "displayLastFirst") as? String
        self.displayFirstLast = info.value(forKey: "displayFirstLast") as? String
    }
}
