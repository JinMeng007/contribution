//
//  XactionActivityType.swift
//  AFrame
//
//  Created by Lee Sheng Jin on 2019/3/14.
//  Copyright © 2019 DrawRanger. All rights reserved.
//

import UIKit

class XactionActivityType: NSObject {
    var xactionActivityTypeId: Int?
    var name: String?
    var systemType: Bool?

    init?(_ info: NSDictionary) {
        self.xactionActivityTypeId = info.value(forKey: "xactionActivityTypeId") as? Int
        self.name = info.value(forKey: "name") as? String
        self.systemType = info.value(forKey: "systemType") as? Bool ?? false
    }
}
