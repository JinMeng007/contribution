//
//  User.swift
//  AFrame
//
//  Created by Lee Sheng Jin on 2019/2/21.
//  Copyright © 2019 DrawRanger. All rights reserved.
//

import UIKit

class User: NSObject {
    
    class var sharedInstance: User {
        struct Static {
            static let instance: User = User()
        }
        return Static.instance
    }
    
    var appUserId: Int?
    var userName: String?
    var firstName: String?
    var lastName: String?
    var email: String?
    var phones: [Phone] = []
    var displayLastFirst: String?
    var displayFirstLast: String?
    var calendarFeedUrl: String?
    var active: Bool?
    var password: String?
    var is_loggedin: Bool = false
    
    func loadUserInfo(_ info: NSDictionary) {
        self.appUserId = info.value(forKey: "appUserId") as? Int
        self.userName = info.value(forKey: "userName") as? String
        self.firstName = info.value(forKey: "firstName") as? String
        self.lastName = info.value(forKey: "lastName") as? String
        self.email = info.value(forKey: "email") as? String
        
        let phones_arr = info.value(forKey: "phones") as? NSArray
        for phone_dic in phones_arr! {
            self.phones.append(Phone(phone_dic as! NSDictionary)!)
        }
        
        self.displayFirstLast = info.value(forKey: "displayFirstLast") as? String
        self.displayLastFirst = info.value(forKey: "displayLastFirst") as? String
        self.calendarFeedUrl = info.value(forKey: "calendarFeedUrl") as? String
        self.active = info.value(forKey: "active") as? Bool
    }
    
    func initInstance() {
        self.appUserId = nil
        self.userName = nil
        self.firstName = nil
        self.lastName = nil
        self.email = nil
        self.phones.removeAll()
        self.displayFirstLast = nil
        self.displayLastFirst = nil
        self.calendarFeedUrl = nil
        self.active = nil
        self.password = nil
        self.is_loggedin = false
    }
}
