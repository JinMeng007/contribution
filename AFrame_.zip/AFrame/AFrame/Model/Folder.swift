//
//  Folder.swift
//  AFrame
//
//  Created by Lee Sheng Jin on 2019/2/27.
//  Copyright © 2019 DrawRanger. All rights reserved.
//

import UIKit

class Folder: NSObject {
    var folderId: Int?
    var name: String?
    var sort: Int?
    init?(_ info: NSDictionary) {
        self.folderId = info.value(forKey: "folderId") as? Int
        self.name = info.value(forKey: "name") as? String
        self.sort = info.value(forKey: "sort") as? Int
    }
}
