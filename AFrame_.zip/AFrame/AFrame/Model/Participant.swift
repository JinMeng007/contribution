//
//  Participant.swift
//  AFrame
//
//  Created by Lee Sheng Jin on 2019/3/7.
//  Copyright © 2019 DrawRanger. All rights reserved.
//

import UIKit

class Participant: NSObject {
    var xactionParticipantId: Int?
    var xactionParticipantRole: String?
    var company: String?
    var firstName: String?
    var lastName: String?
    var email: String?
    var phones: [Phone] = []
    var spouseFirstName: String?
    var spouseLastName: String?
    var spouseEmail: String?
    var spousePhones: [Phone] = []
    var address: ContactAddress?
    var website: String?
    var isPublished: Bool?
    var displayLastFirst: String?
    var displayFirstLast: String?
    var contactIdReference: String?
    var xactionId: Int?
    
    init?(_ info: NSDictionary) {
        self.xactionParticipantId = info.value(forKey: "xactionParticipantId") as? Int
        self.xactionParticipantRole = info.value(forKey: "xactionParticipantRole") as? String
        self.company = info.value(forKey: "company") as? String
        self.firstName = info.value(forKey: "firstName") as? String
        self.lastName = info.value(forKey: "lastName") as? String
        self.email = info.value(forKey: "email") as? String
        let phone_arr = info.value(forKey: "phones") as! NSArray
        for phone_dic in phone_arr {
            self.phones.append(Phone(phone_dic as! NSDictionary)!)
        }
        self.spouseFirstName = info.value(forKey: "spouseFirstName") as? String
        self.spouseLastName = info.value(forKey: "spouseLastName") as? String
        self.spouseEmail = info.value(forKey: "spouseEmail") as? String
        let sphone_arr = info.value(forKey: "spousePhones") as! NSArray
        for phone_dic in sphone_arr {
            self.spousePhones.append(Phone(phone_dic as! NSDictionary)!)
        }
        self.address = ContactAddress(info.value(forKey: "address") as! NSDictionary)
        self.website = info.value(forKey: "website") as? String
        self.isPublished = info.value(forKey: "isPublished") as? Bool ?? false
        self.displayFirstLast = info.value(forKey: "displayFirstLast") as? String
        self.displayLastFirst = info.value(forKey: "displayLastFirst") as? String
        self.contactIdReference = info.value(forKey: "contactIdReference") as? String
        self.xactionId = info.value(forKey: "xactionId") as? Int
    }
}
