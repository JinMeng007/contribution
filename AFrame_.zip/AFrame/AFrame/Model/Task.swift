//
//  Task.swift
//  AFrame
//
//  Created by Lee Sheng Jin on 2019/2/21.
//  Copyright © 2019 DrawRanger. All rights reserved.
//

import UIKit

class Task: NSObject {
    var taskId: Int?
    var subject: String?
    var note: String?
    var taskType: String?
    var taskTypeDisplay: String?
    var status: String?
    var statusDisplay: String?
    var dueDate: String?
    var isRecurring: Bool?
    var completeDate: String?
    var isPublished: Bool?
    var reminderSet: Bool?
    var sort: Int?
    var editDateTime: Double?
    var createDateTime: Double?
    var appUser: AppUser?
    var contact: Contact?
    var xaction: Transaction?
    var letterTemplate: String?
    
    init?(_ info: NSDictionary) {
        self.taskId = info.value(forKey: "taskId") as? Int
        self.subject = info.value(forKey: "subject") as? String
        self.note = info.value(forKey: "note") as? String
        self.taskType = info.value(forKey: "taskType") as? String
        self.taskTypeDisplay = info.value(forKey: "taskTypeDisplay") as? String
        self.status = info.value(forKey: "status") as? String
        self.statusDisplay = info.value(forKey: "statusDisplay") as? String
        self.dueDate = info.value(forKey: "dueDate") as? String
        self.isRecurring = info.value(forKey: "isRecurring") as? Bool
        self.completeDate = info.value(forKey: "completeDate") as? String
        self.isPublished = info.value(forKey: "isPublished") as? Bool
        self.reminderSet = info.value(forKey: "reminderSet") as? Bool
        self.sort = info.value(forKey: "sort") as? Int
        self.editDateTime = info.value(forKey: "editDateTime") as? Double
        self.createDateTime = info.value(forKey: "createDateTime") as? Double
        if info.value(forKey: "appUser") != nil && !(info.value(forKey: "appUser") is NSNull) {
            self.appUser = AppUser(info.value(forKey: "appUser") as! NSDictionary)
        }
        if !(info.value(forKey: "contact") is NSNull) && info.value(forKey: "contact") != nil {
            self.contact = Contact(info.value(forKey: "contact") as! NSDictionary)
        }
        if !(info.value(forKey: "xaction") is NSNull) && info.value(forKey: "xaction") != nil {
            self.xaction = Transaction(info.value(forKey: "xaction") as! NSDictionary)
        }
        self.letterTemplate = info.value(forKey: "letterTemplate") as? String
    }
}
