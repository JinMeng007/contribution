//
//  Address.swift
//  AFrame
//
//  Created by Lee Sheng Jin on 2019/2/21.
//  Copyright © 2019 DrawRanger. All rights reserved.
//

import UIKit

class Address: NSObject {
    var addressLine: String?
    var addressCSZ: String?
    var addressFull: String?
    init?(_ info: NSDictionary) {
        self.addressLine = info.value(forKey: "addressLine") as? String
        self.addressCSZ = info.value(forKey: "addressCSZ") as? String
        self.addressFull = info.value(forKey: "addressFull") as? String
    }
}
