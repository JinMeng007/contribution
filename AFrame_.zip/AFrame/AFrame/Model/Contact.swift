//
//  Contact.swift
//  AFrame
//
//  Created by Lee Sheng Jin on 2019/2/21.
//  Copyright © 2019 DrawRanger. All rights reserved.
//

import UIKit

class Contact: NSObject {
    var contactId: Int?
    var company: String?
    var title: String?
    var firstName: String?
    var lastName: String?
    var email: String?
    var phones: [Phone] = []
    var spouseTitle: String?
    var spouseFirstName: String?
    var spouseLastName: String?
    var spouseEmail: String?
    var spousePhones: [Phone] = []
    var displayLastFirst: String?
    var displayFirstLast: String?
    var xactionCount: Int?
    init?(_ info: NSDictionary) {
        self.contactId = info.value(forKey: "contactId") as? Int
        self.company = info.value(forKey: "company") as? String
        self.title = info.value(forKey: "title") as? String
        self.firstName = info.value(forKey: "firstName") as? String
        self.lastName = info.value(forKey: "lastName") as? String
        self.email = info.value(forKey: "email") as? String
        
        let phones_arr = info.value(forKey: "phones") as? NSArray
        if phones_arr != nil {
            for phone_dic in phones_arr! {
                self.phones.append(Phone(phone_dic as! NSDictionary)!)
            }
        }
        self.spouseTitle = info.value(forKey: "spouseTitle") as? String
        self.spouseFirstName = info.value(forKey: "spouseFirstName") as? String
        self.spouseLastName = info.value(forKey: "spouseLastName") as? String
        self.spouseEmail = info.value(forKey: "spouseEmail") as? String
        
        let spouse_phones = info.value(forKey: "spousePhones") as? NSArray
        if spouse_phones != nil {
            for phone_dic in phones_arr! {
                self.spousePhones.append(Phone(phone_dic as! NSDictionary)!)
            }
        }
        self.displayFirstLast = info.value(forKey: "displayFirstLast") as? String
        self.displayLastFirst = info.value(forKey: "displayLastFirst") as? String
        self.xactionCount = info.value(forKey: "xactionCount") as? Int
    }
}
