//
//  Notification.swift
//  AFrame
//
//  Created by Lee Sheng Jin on 2019/2/24.
//  Copyright © 2019 DrawRanger. All rights reserved.
//

import UIKit

class AFNotification: NSObject {
    var notificationId: Int?
    var displayText: String?
    var hasBeenRead: Bool?
    var notificationType: String?
    var appUser: AppUser?
    var contact: Contact?
    var xaction: Transaction?
    var event: Event?
    var task: Task?
    
    init?(_ info: NSDictionary) {
        self.notificationId = info.value(forKey: "notificationId") as? Int
        self.displayText = info.value(forKey: "displayText") as? String
        self.hasBeenRead = info.value(forKey: "hasBeenRead") as? Bool
        self.notificationType = info.value(forKey: "notificationType") as? String
        self.appUser = AppUser(info.value(forKey: "appUser") as! NSDictionary)
        
        if !(info.value(forKey: "contact") is NSNull) {
            self.contact = Contact(info.value(forKey: "contact") as! NSDictionary)
        }
        if !(info.value(forKey: "xaction") is NSNull) {
            self.xaction = Transaction(info.value(forKey: "xaction") as! NSDictionary)
        }
        if !(info.value(forKey: "event") is NSNull) {
            self.event = Event(info.value(forKey: "event") as! NSDictionary)
        }
        if !(info.value(forKey: "task") is NSNull) {
            self.task = Task(info.value(forKey: "task") as! NSDictionary)
        }
    }
}
