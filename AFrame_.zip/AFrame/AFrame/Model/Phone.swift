//
//  Phone.swift
//  AFrame
//
//  Created by Lee Sheng Jin on 2019/2/21.
//  Copyright © 2019 DrawRanger. All rights reserved.
//

import UIKit

class Phone: NSObject {
    var phone: String?
    var phoneType: String?
    var phoneDesc: String?
    var phoneDigits: String?
    
    init?(_ info: NSDictionary){
        self.phone = info.value(forKey: "phone") as? String
        self.phoneType = info.value(forKey: "phoneType") as? String
        self.phoneDesc = info.value(forKey: "phoneDesc") as? String
        self.phoneDigits = info.value(forKey: "phoneDigits") as? String
    }
}
