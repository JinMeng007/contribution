//
//  Event.swift
//  AFrame
//
//  Created by Lee Sheng Jin on 2019/2/24.
//  Copyright © 2019 DrawRanger. All rights reserved.
//

import UIKit

class Event: NSObject {
    var eventId: Int?
    var title: String?
    var location: String?
    var descript: String?
    var startDate: String?
    var startTimeMinutes: Int?
    var allDayEvent: Bool?
    var reminderSet: Bool?
    var contactId: Int?
    var contact: Contact?
    var xactionId: Int?
    var xaction: Transaction?
    
    init? (_ info: NSDictionary) {
        self.eventId = info.value(forKey: "eventId") as? Int
        self.title = info.value(forKey: "title") as? String
        self.location = info.value(forKey: "location") as? String
        self.descript = info.value(forKey: "description") as? String
        self.startDate = info.value(forKey: "startDate") as? String
        self.startTimeMinutes = info.value(forKey: "startTimeMinutes") as? Int
        self.allDayEvent = info.value(forKey: "allDayEvent") as? Bool
        self.reminderSet = info.value(forKey: "reminderSet") as? Bool
        self.contactId = info.value(forKey: "contactId") as? Int
        self.xactionId = info.value(forKey: "xactionId") as? Int
        if !(info.value(forKey: "contact") is NSNull) {
            self.contact = Contact(info.value(forKey: "contact") as! NSDictionary)
        }
        if !(info.value(forKey: "xaction") is NSNull) {
            self.xaction = Transaction(info.value(forKey: "xaction") as! NSDictionary)
        }
    }
}
