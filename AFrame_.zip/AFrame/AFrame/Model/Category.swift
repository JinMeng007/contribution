//
//  Category.swift
//  AFrame
//
//  Created by Lee Sheng Jin on 2019/2/25.
//  Copyright © 2019 DrawRanger. All rights reserved.
//

import UIKit

class Category: NSObject {
    var categoryId: Int?
    var name: String?
    var isSystemCategory: Bool?
    init?(_ info: NSDictionary) {
        self.categoryId = info.value(forKey: "categoryId") as? Int
        self.name = info.value(forKey: "name") as? String
        self.isSystemCategory = info.value(forKey: "isSystemCategory") as? Bool
    }
}
