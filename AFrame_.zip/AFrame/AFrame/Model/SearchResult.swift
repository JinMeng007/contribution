//
//  SearchResult.swift
//  AFrame
//
//  Created by Lee Sheng Jin on 2019/2/21.
//  Copyright © 2019 DrawRanger. All rights reserved.
//

import UIKit

class SearchResult: NSObject {
    var display: String?
    var searchResultType: String?
    var contact: Contact?
    var xaction: Transaction?
    init?(_ info: NSDictionary) {
        self.display = info.value(forKey: "display") as? String
        self.searchResultType = info.value(forKey: "searchResultType") as? String
        if !(info.value(forKey: "contact") is NSNull) {
            self.contact = Contact(info.value(forKey: "contact") as! NSDictionary)
        }
        if !(info.value(forKey: "xaction") is NSNull) {
            self.xaction = Transaction(info.value(forKey: "xaction") as! NSDictionary)
        }
    }
}
