//
//  Note.swift
//  AFrame
//
//  Created by Lee Sheng Jin on 2019/2/26.
//  Copyright © 2019 DrawRanger. All rights reserved.
//

import UIKit

class Note: NSObject {
    var contactNoteId: Int?
    var note: String?
    var noteType: String?
    var noteDate: String?
    var fileName: String?
    var isProspecting: Bool?
    var contactId: Int?
    var appUserId: Int?
    var fileUrl: String?
    
    init?(_ info: NSDictionary) {
        self.contactNoteId = info.value(forKey: "contactNoteId") as? Int
        self.note = info.value(forKey: "note") as? String
        self.noteType = info.value(forKey: "noteType") as? String
        self.noteDate = info.value(forKey: "noteDate") as? String
        self.fileName = info.value(forKey: "fileName") as? String
        self.isProspecting = info.value(forKey: "isProspecting") as? Bool ?? false
        self.contactId = info.value(forKey: "contactId") as? Int
        self.appUserId = info.value(forKey: "appUserId") as? Int
        self.fileUrl = info.value(forKey: "fileUrl") as? String
    }
}
