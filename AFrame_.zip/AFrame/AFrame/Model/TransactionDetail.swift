//
//  TransactionDetail.swift
//  AFrame
//
//  Created by Lee Sheng Jin on 2019/2/25.
//  Copyright © 2019 DrawRanger. All rights reserved.
//

import UIKit

class TransactionDetail: NSObject {
    var xactionId: Int?
    var address: ContactAddress?
    var status: String?
    var statusColorHex: String?
    var statusStage: Int?
    var price: Int?
    var listDate: String?
    var closingDate: String?
    var closedDate: String?
    var xactionStatusLookup: String?
    var xactionPropTypeLookup: String?
    var xactionSourceLookup: String?
    var propNum: String?
    var propStreetDir: String?
    var propStreet: String?
    var propStreetUnit: String?
    var city: String?
    var state: String?
    var zip: String?
    var mlsId: String?
    var taxId: String?
    var listPrice: Int?
    var listPriceOriginal: Int?
    var sqFt: Int?
    var sqFtSource: String?
    var beds: Int?
    var baths: Double?
    var yearBuilt: Int?
    var lotSize: String?
    var schools: String?
    var subdivision: String?
    var lockBox: String?
    var securityCode: String?
    var remarks: String?
    var instructions: String?
    var listOtherInfo: String?
    var contractPrice: Int?
    var otherParty: String?
    var earnestMoney: String?
    var specialProvisions: String?
    var contractOtherInfo: String?
    var possession: String?
    var expireDate: String?
    var effectiveDate: String?
    var xactionSide: String?
    var percentageCommission: Double?
    var commissionNote: String?
    var splitTeamLead: String?
    var splitPrimaryAgent: Double?
    var splitCoAgent: Double?
    var splitAssistant: String?
    var payoutEstimated: Int?
    var payoutActual: Int?
    var payoutReferral: String?
    var payoutBroker: String?
    var payoutTeamLead: String?
    var payoutPrimaryAgent: Double?
    var payoutCoAgent: Double?
    var payoutAssistant: String?
    var expensesBroker: String?
    var expensesTeamLead: String?
    var geoLatitude: Double?
    var geoLongitude: Double?
    var createDateTime: Double?
    var editDateTime: Double?
    var appUserPrimaryAgent: Agent?
    var appUserCoAgent: Agent?
    var appUserAssistant: String?
    var contact: ContactDetail?
    var propType: String?
    var siteUrl: String?
    
    init?(_ info: NSDictionary) {
        self.xactionId = info.value(forKey: "xactionId") as? Int
        self.address = ContactAddress(info.value(forKey: "address") as! NSDictionary)
        self.status = info.value(forKey: "status") as? String
        self.statusColorHex = info.value(forKey: "statusColorHex") as? String
        self.statusStage = info.value(forKey: "statusStage") as? Int
        self.price = info.value(forKey: "price") as? Int
        self.listDate = info.value(forKey: "listDate") as? String
        self.closingDate = info.value(forKey: "closingDate") as? String
        self.closedDate = info.value(forKey: "closedDate") as? String
        self.xactionStatusLookup = info.value(forKey: "xactionStatusLookup") as? String
        self.xactionPropTypeLookup = info.value(forKey: "xactionPropTypeLookup") as? String
        self.xactionSourceLookup = info.value(forKey: "xactionSourceLookup") as? String
        self.propNum = info.value(forKey: "propNum") as? String
        self.propType = info.value(forKey: "propType") as? String
        self.propStreetDir = info.value(forKey: "propStreetDir") as? String
        self.propStreet = info.value(forKey: "propStreet") as? String
        self.propStreetUnit = info.value(forKey: "propStreetUnit") as? String
        self.city = info.value(forKey: "city") as? String
        self.state = info.value(forKey: "state") as? String
        self.zip = info.value(forKey: "zip") as? String
        self.mlsId = info.value(forKey: "mlsId") as? String
        self.taxId = info.value(forKey: "taxId") as? String
        self.listPrice = info.value(forKey: "listPrice") as? Int
        self.listPriceOriginal = info.value(forKey: "listPriceOriginal") as? Int
        self.sqFt = info.value(forKey: "sqFt") as? Int
        self.sqFtSource = info.value(forKey: "sqFtSource") as? String
        self.beds = info.value(forKey: "beds") as? Int
        self.baths = info.value(forKey: "baths") as? Double
        self.yearBuilt = info.value(forKey: "yearBuilt") as? Int
        self.lotSize = info.value(forKey: "lotSize") as? String
        self.schools = info.value(forKey: "schools") as? String
        self.subdivision = info.value(forKey: "subdivision") as? String
        self.lockBox = info.value(forKey: "lockBox") as? String
        self.securityCode = info.value(forKey: "securityCode") as? String
        self.remarks = info.value(forKey: "remarks") as? String
        self.instructions = info.value(forKey: "instructions") as? String
        self.listOtherInfo = info.value(forKey: "listOtherInfo") as? String
        self.contractPrice = info.value(forKey: "contractPrice") as? Int
        self.otherParty = info.value(forKey: "otherParty") as? String
        self.earnestMoney = info.value(forKey: "earnestMoney") as? String
        self.specialProvisions = info.value(forKey: "specialProvisions") as? String
        self.contractOtherInfo = info.value(forKey: "contractOtherInfo") as? String
        self.possession = info.value(forKey: "possession") as? String
        self.expireDate = info.value(forKey: "expireDate") as? String
        self.effectiveDate = info.value(forKey: "effectiveDate") as? String
        self.xactionSide = info.value(forKey: "xactionSide") as? String
        self.percentageCommission = info.value(forKey: "percentageCommission") as? Double
        self.commissionNote = info.value(forKey: "commissionNote") as? String
        self.splitTeamLead = info.value(forKey: "splitTeamLead") as? String
        self.splitPrimaryAgent = info.value(forKey: "splitPrimaryAgent") as? Double ?? 0
//        if info.value(forKey: "splitCoAgent") != nil && !(info.value(forKey: "splitCoAgent") is NSNull) {
            self.splitCoAgent = info.value(forKey: "splitCoAgent") as? Double
//        }
        self.splitAssistant = info.value(forKey: "splitAssistant") as? String
        self.payoutEstimated = info.value(forKey: "payoutEstimated") as? Int
        self.payoutActual = info.value(forKey: "payoutActual") as? Int
        self.payoutReferral = info.value(forKey: "payoutReferral") as? String
        self.payoutBroker = info.value(forKey: "payoutBroker") as? String
        self.payoutTeamLead = info.value(forKey: "payoutTeamLead") as? String
        self.payoutPrimaryAgent = info.value(forKey: "payoutPrimaryAgent") as? Double
        self.payoutCoAgent = info.value(forKey: "payoutCoAgent") as? Double
        self.payoutAssistant = info.value(forKey: "payoutAssistant") as? String
        self.expensesBroker = info.value(forKey: "expensesBroker") as? String
        self.expensesTeamLead = info.value(forKey: "expensesTeamLead") as? String
        self.geoLatitude = info.value(forKey: "geoLatitude") as? Double
        self.geoLongitude = info.value(forKey: "geoLongitude") as? Double
        self.createDateTime = info.value(forKey: "createDateTime") as? Double
        self.editDateTime = info.value(forKey: "editDateTime") as? Double
        if info.value(forKey: "appUserPrimaryAgent") != nil && !(info.value(forKey: "appUserPrimaryAgent") is NSNull) {
            self.appUserPrimaryAgent = Agent(info.value(forKey: "appUserPrimaryAgent") as! NSDictionary)
        }
        if info.value(forKey: "appUserCoAgent") != nil && !(info.value(forKey: "appUserCoAgent") is NSNull) {
            self.appUserCoAgent = Agent(info.value(forKey: "appUserCoAgent") as! NSDictionary)
        }
        self.appUserAssistant = info.value(forKey: "appUserAssistant") as? String
        self.contact = ContactDetail(info.value(forKey: "contact") as! NSDictionary)
        self.siteUrl = info.value(forKey: "siteUrl") as? String
    }
}
