//
//  TransactionImportant.swift
//  AFrame
//
//  Created by Lee Sheng Jin on 2019/2/27.
//  Copyright © 2019 DrawRanger. All rights reserved.
//

import UIKit

class TransactionImport: NSObject {
    var xactionActivityImportId: Int?
    var showingImportActivityId: Int?
    var isPrivate: Bool?
    var isPublished: Bool?
    var activityDate: String?
    var showType: String?
    var showStatus: String?
    var showTime: String?
    var feedback: String?
    var isNowShow: Bool?
    var isSecondShowing: Bool?
    var showAgentName: String?
    var showAgentCompany: String?
    var showAgentPhone1: String?
    var showAgentPhone1Desc: String?
    var showAgentPhone2: String?
    var showAgentPhone2Desc: String?
    var showAgentPhone3: String?
    var showAgentPhone3Desc: String?
    var showAgentEmail: String?
    var xactionId: Int?
    init?(_ info: NSDictionary) {
        self.xactionActivityImportId = info.value(forKey: "xactionActivityImportId") as? Int
        self.showingImportActivityId = info.value(forKey: "showingImportActivityId") as? Int
        self.isPrivate = info.value(forKey: "isPrivate") as? Bool
        self.isPublished = info.value(forKey: "isPublished") as? Bool
        self.activityDate = info.value(forKey: "activityDate") as? String
        self.showType = info.value(forKey: "showType") as? String
        self.showStatus = info.value(forKey: "showStatus") as? String
        self.showTime = info.value(forKey: "showTime") as? String
        self.feedback = info.value(forKey: "feedback") as? String
        self.isNowShow = info.value(forKey: "isNowShow") as? Bool
        self.isSecondShowing = info.value(forKey: "isSecondShowing") as? Bool
        self.showAgentName = info.value(forKey: "showAgentName") as? String
        self.showAgentCompany = info.value(forKey: "showAgentCompany") as? String
        self.showAgentPhone1 = info.value(forKey: "showAgentPhone1") as? String
        self.showAgentPhone1Desc = info.value(forKey: "showAgentPhone1Desc") as? String
        self.showAgentPhone2 = info.value(forKey: "showAgentPhone2") as? String
        self.showAgentPhone2Desc = info.value(forKey: "showAgentPhone2Desc") as? String
        self.showAgentPhone3 = info.value(forKey: "showAgentPhone3") as? String
        self.showAgentPhone3Desc = info.value(forKey: "showAgentPhone3Desc") as? String
        self.showAgentEmail = info.value(forKey: "showAgentEmail") as? String
        self.xactionId = info.value(forKey: "xactionId") as? Int
    }
}
