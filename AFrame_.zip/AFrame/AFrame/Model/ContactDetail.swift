//
//  ContactDetail.swift
//  AFrame
//
//  Created by Lee Sheng Jin on 2019/2/25.
//  Copyright © 2019 DrawRanger. All rights reserved.
//

import UIKit

class ContactDetail: NSObject {
    var contactId: Int?
    var company: String?
    var title: String?
    var firstName: String?
    var lastName: String?
    var email: String?
    var phones: [Phone] = []
    var spouseTitle: String?
    var spouseFirstName: String?
    var spouseLastName: String?
    var spouseEmail: String?
    var spousePhones: [Phone] = []
    var addressHome: ContactAddress?
    var addressWork: ContactAddress?
    var mailingAddress: String?
    var birthday: [Int]?
    var birthdaySpouse: [Int]?
    var anniversary: [Int]?
    var categories: [Category] = []
    var ownersString: String?
    var displayLastFirst: String?
    var displayFirstLast: String?
    var xactionCount: Int?
    var siteUrl: String?
    
    init?(_ info: NSDictionary) {
        self.contactId = info.value(forKey: "contactId") as? Int
        self.company = info.value(forKey: "company") as? String
        self.title = info.value(forKey: "title") as? String
        self.firstName = info.value(forKey: "firstName") as? String
        self.lastName = info.value(forKey: "lastName") as? String
        self.email = info.value(forKey: "email") as? String
        for phone_dic in info.value(forKey: "phones") as! NSArray {
            self.phones.append(Phone(phone_dic as! NSDictionary)!)
        }
        self.spouseTitle = info.value(forKey: "spouseTitle") as? String
        self.spouseFirstName = info.value(forKey: "spouseFirstName") as? String
        self.spouseLastName = info.value(forKey: "spouseLastName") as? String
        self.spouseEmail = info.value(forKey: "spouseEmail") as? String
        self.siteUrl = info.value(forKey: "siteUrl") as? String
        for phone_dic in info.value(forKey: "spousePhones") as! NSArray {
            self.spousePhones.append(Phone(phone_dic as! NSDictionary)!)
        }
        self.addressHome = ContactAddress(info.value(forKey: "addressHome") as! NSDictionary)
        self.addressWork = ContactAddress(info.value(forKey: "addressWork") as! NSDictionary)
        self.mailingAddress = info.value(forKey: "mailingAddress") as? String
        if info.value(forKey: "birthday") as? [Int] != nil {
            self.birthday = info.value(forKey: "birthday") as? [Int]
        }
        if info.value(forKey: "birthdaySpouse") as? [Int] != nil {
            self.birthdaySpouse = info.value(forKey: "birthdaySpouse") as? [Int]
        }
        if info.value(forKey: "anniversary") as? [Int] != nil {
            self.anniversary = info.value(forKey: "anniversary") as? [Int]
        }
        for cat_dic in info.value(forKey: "categories") as! NSArray {
            self.categories.append(Category(cat_dic as! NSDictionary)!)
        }
        self.ownersString = info.value(forKey: "ownersString") as? String
        self.displayFirstLast = info.value(forKey: "displayFirstLast") as? String
        self.displayLastFirst = info.value(forKey: "displayLastFirst") as? String
        self.xactionCount = info.value(forKey: "xactionCount") as? Int
    }
}
