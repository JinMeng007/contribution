//
//  XActionAttachmentDetail.swift
//  AFrame
//
//  Created by Lee Sheng Jin on 2019/2/27.
//  Copyright © 2019 DrawRanger. All rights reserved.
//

import UIKit

class XActionAttachmentDetail: NSObject {
    var xactionAttachmentId: Int?
    var attachmentType: String?
    var fileName: String?
    var webLink: String?
    var descript: String?
    var uploadedDateTime: Double?
    var fileSizeBytes: Int?
    var sort: Int?
    var isPublished: Bool?
    var appUserId: Int?
    var appUser: AppUser?
    var folderId: Int?
    var folder: Folder?
    var xactionId: Int?
    var fileUrl: String?
    
    init?(_ info: NSDictionary) {
        self.xactionAttachmentId = info.value(forKey: "xactionAttachmentId") as? Int
        self.attachmentType = info.value(forKey: "attachmentType") as? String
        self.fileName = info.value(forKey: "fileName") as? String
        self.webLink = info.value(forKey: "webLink") as? String
        self.descript = info.value(forKey: "description") as? String
        self.uploadedDateTime = info.value(forKey: "uploadedDateTime") as? Double
        self.fileSizeBytes = info.value(forKey: "fileSizeBytes") as? Int
        self.sort = info.value(forKey: "sort") as? Int
        self.isPublished = info.value(forKey: "isPublished") as? Bool
        self.appUserId = info.value(forKey: "appUserId") as? Int
        self.appUser = AppUser(info.value(forKey: "appUser") as! NSDictionary)
        self.folderId = info.value(forKey: "folderId") as? Int
        if !(info.value(forKey: "folder") is NSNull) {
            self.folder = Folder(info.value(forKey: "folder") as! NSDictionary)
        }
        self.xactionId = info.value(forKey: "xactionId") as? Int
        self.fileUrl = info.value(forKey: "fileUrl") as? String
    }
}
