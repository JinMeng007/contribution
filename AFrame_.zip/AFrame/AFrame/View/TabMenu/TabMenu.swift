//
//  TabMenu.swift
//  AFrame
//
//  Created by Lee Sheng Jin on 2019/2/10.
//  Copyright © 2019 DrawRanger. All rights reserved.
//

import UIKit

class TabMenu: UIView {
    
    let appDelegate: AppDelegate = UIApplication.shared.delegate as! AppDelegate

    override init(frame: CGRect) {
        super.init(frame: frame)
        self.loadNib()
    }
    
    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
        self.loadNib()
    }
    
    func loadNib() {
        let item = Bundle.main.loadNibNamed("TabMenu", owner: self, options: nil)?.first as! UIView
        item.frame = self.bounds
        self.addSubview(item)
        
        self.layer.borderColor = APP_BLUE_COLOR.cgColor
        self.layer.borderWidth = 1.0
    }
    
    @IBAction func actionMenu(_ sender: UIButton) {
        switch sender.tag {
        case 100:
            if URL(string: APIURL.website_link) != nil {
                UIApplication.shared.open(URL(string: APIURL.website_link)!, options: [:], completionHandler: nil)
            }
            break
        case 101:
            if URL(string: User.sharedInstance.calendarFeedUrl ?? "") != nil {
                UIApplication.shared.open(URL(string: User.sharedInstance.calendarFeedUrl ?? "")!, options: [:], completionHandler: nil)
            }
            break
        default:
            let vc = self.findViewController() as! BaseViewController
            let alert = UIAlertController(title: "Alert", message: "Are you sure you want to log out?", preferredStyle: .alert)
            alert.addAction(UIAlertAction(title: "Ok", style: .default, handler: { (action) in
                self.appDelegate.deleteUser()
                User.sharedInstance.initInstance()
                self.appDelegate.makingRoot("initial")
            }))
            alert.addAction(UIAlertAction(title: "Cancel", style: .cancel, handler: nil))
            vc.present(alert, animated: true, completion: nil)
            break
        }
    }
    

}
