//
//  AFPhoneButton.swift
//  AFrame
//
//  Created by Lee Sheng Jin on 2019/3/6.
//  Copyright © 2019 DrawRanger. All rights reserved.
//

import UIKit

class AFPhoneButton: UIButton {
    
    var number: String? {
        didSet {
            self.addTarget(self, action: #selector(self.makePhoneCall), for: .touchUpInside)
        }
    }
    
    @objc func makePhoneCall() {
        if let url = URL(string: "tel://\(number?.onlyDigits() ?? "")") {
            UIApplication.shared.open(url, options: [:], completionHandler: nil)
        }
    }
    
    override func layoutSubviews() {
        super.layoutSubviews()
    }
}
