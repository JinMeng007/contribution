//
//  AFSMSButton.swift
//  AFrame
//
//  Created by Lee Sheng Jin on 2019/3/24.
//  Copyright © 2019 DrawRanger. All rights reserved.
//

import UIKit
import MessageUI

class AFSMSButton: UIButton, MFMessageComposeViewControllerDelegate {
    
    var number: String? {
        didSet {
            self.addTarget(self, action: #selector(self.sendSMS), for: .touchUpInside)
        }
    }

    func messageComposeViewController(_ controller: MFMessageComposeViewController, didFinishWith result: MessageComposeResult) {
        controller.dismiss(animated: true, completion: nil)
    }
    
    @objc func sendSMS() {
        let vc = self.findViewController() as! BaseViewController
        let alert = UIAlertController(title: "", message: "Would you like to send an SMS?", preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "Ok", style: .default, handler: { (action) in
            DispatchQueue.main.async {
                if (MFMessageComposeViewController.canSendText()) {
                    let controller = MFMessageComposeViewController()
                    controller.body = ""
                    controller.recipients = [self.number!]
                    controller.messageComposeDelegate = self
                    vc.present(controller, animated: true, completion: nil)
                }
            }
        }))
        alert.addAction(UIAlertAction(title: "Cancel", style: .cancel, handler: nil))
        vc.present(alert, animated: true, completion: nil)
        
    }

}
