//
//  IconLabel.swift
//  AFrame
//
//  Created by Lee Sheng Jin on 2019/2/26.
//  Copyright © 2019 DrawRanger. All rights reserved.
//

import UIKit

class IconLabel: UILabel {
    var text_color: UIColor?
    override func layoutSubviews() {
        self.font = UIFont(name: "FontAwesome5ProLight", size: 17)!
        self.textColor = text_color == nil ? APP_GRAY_COLOR : text_color!
    }
}
