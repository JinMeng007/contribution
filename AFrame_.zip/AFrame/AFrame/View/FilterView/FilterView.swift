//
//  FilterView.swift
//  AFrame
//
//  Created by Lee Sheng Jin on 2019/3/18.
//  Copyright © 2019 DrawRanger. All rights reserved.
//

import UIKit

class FilterView: UIView {
    
    @IBOutlet var filterBtns: [UIButton]!
    var prevBtn: Int = 100
    var type: Int = 0

    override init(frame: CGRect) {
        super.init(frame: frame)
    }
    
    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
    }
    
    func loadNib(_ type: Int) {
        let item = Bundle.main.loadNibNamed("FilterView", owner: self, options: nil)?[type] as! UIView
        item.frame = self.bounds
        self.addSubview(item)
        
        self.type = type
        self.layer.borderColor = APP_BLUE_COLOR.cgColor
        self.layer.borderWidth = 1.0
    }
    
    @IBAction func actionFilter(_ sender: UIButton) {
        let normFont = UIFont(name: "Gordita-Regular", size: 15.0)!
        let boldFont = UIFont(name: "Gordita-Medium", size: 15.0)!
        filterBtns[prevBtn - 100].titleLabel?.font = normFont
        sender.titleLabel?.font = boldFont
        prevBtn = sender.tag
        
        if type == 0 {
            let vc = self.findViewController() as! TransactionVC
            vc.filterView.alpha = 0.0
            vc.filterClicked = true
            if sender.tag == 100 {
                vc.current_filter = "appuser"
                vc.getAllOpenTransactions()
            }else {
                vc.current_filter = "team"
                vc.getAllOpenTransactions()
            }
        }else {
            let vc = self.findViewController() as! SearchVC
            vc.filterView.alpha = 0.0
            vc.filterClicked = true
        }
        
    }
    
}
