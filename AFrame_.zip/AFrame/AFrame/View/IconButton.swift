//
//  IconButton.swift
//  AFrame
//
//  Created by Lee Sheng Jin on 2019/2/26.
//  Copyright © 2019 DrawRanger. All rights reserved.
//

import UIKit

class IconButton: UIButton {
    
    var mapLink: String? {
        didSet {
            self.addTarget(self, action: #selector(gotoLocation), for: .touchUpInside)
        }
    }
    
    @objc func gotoLocation() {
        if URL(string: self.mapLink ?? "") != nil {
            UIApplication.shared.open(URL(string: self.mapLink ?? "")!, options: [:], completionHandler: nil)
        }else {
            let vc = self.findViewController() as! BaseViewController
            vc.alertViewController(title: "Oops!", message: "Invalid Map link.")
        }
    }
}
