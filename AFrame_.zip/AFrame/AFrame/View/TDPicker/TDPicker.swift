//
//  TDPicker.swift
//  AFrame
//
//  Created by Lee Sheng Jin on 2019/3/15.
//  Copyright © 2019 DrawRanger. All rights reserved.
//

import UIKit

protocol TDPickerDelegate {
    func setTimeDuration(_ result: String)
}

class TDPicker: UIView, UIPickerViewDelegate, UIPickerViewDataSource {

    @IBOutlet weak var pickerView: UIPickerView!
    
    let maxV = 25000
    var td_delegate: TDPickerDelegate?
    var is_init: Bool = true
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        self.loadNib()
    }
    
    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
        self.loadNib()
    }
    
    func loadNib() {
        let item = Bundle.main.loadNibNamed("TDPicker", owner: self, options: nil)?.first as! UIView
        item.frame = self.bounds
        self.addSubview(item)
        self.is_init = true
        self.pickerView.delegate = self
        self.pickerView.dataSource = self
        self.pickerViewLoaded(row: 0, component: 0)
        self.pickerViewLoaded(row: 0, component: 1)
        self.pickerViewLoaded(row: 0, component: 3)
        self.pickerViewLoaded(row: 0, component: 4)
        self.is_init = false
    }
    
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 6
    }
    
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int
    {
        if(component == 2 || component == 5)
        {
            return 2
        }
        else
        {
            return maxV
        }
    }
    
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String?
    {
        if(component == 0 || component == 3)
        {
            return String(format: "%02d", (row%12)+1)
        }
        else if(component == 1 || component == 4)
        {
            
            return String(format: "%02d", (row%12)*5)
        }
        else
        {
            return row == 0 ? "AM" : "PM"
        }
    }
    
    func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
        self.pickerViewLoaded(row: row,component: component)
    }
    
    func pickerViewLoaded(row:Int,component:Int)
    {
        let base12 = (maxV/2)-(maxV/2)%12;
        if !self.is_init {
            var arr: [String] = []
            for i in 0 ..< 6 {
                let tmpR = self.pickerView.selectedRow(inComponent: i)
                if(i == 0 || i == 3)
                {
                    arr.append(String(format: "%02d", (tmpR%12)+1))
                }
                else if(i == 1 || i == 4)
                {
                    arr.append(String(format: "%02d", (tmpR%12)*5))
                }
                else
                {
                    arr.append(tmpR == 0 ? "AM" : "PM")
                }
            }
            self.td_delegate?.setTimeDuration("\(arr[0]):\(arr[1]) \(arr[2]) to \(arr[3]):\(arr[4]) \(arr[5])")
        }
        self.pickerView.selectRow(row%12+base12, inComponent: component, animated: false)
    }
    
    @IBAction func actionDone(_ sender: UIButton) {
        UIView.animate(withDuration: 0.3, animations: {
            self.transform = CGAffineTransform(translationX: 0, y: 0)
        }, completion:{(finished : Bool)  in
            
        })
    }
    
}
