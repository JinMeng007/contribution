//
//  AFEmailButton.swift
//  AFrame
//
//  Created by Lee Sheng Jin on 2019/3/6.
//  Copyright © 2019 DrawRanger. All rights reserved.
//

import UIKit
import MessageUI

class AFEmailButton: UIButton, MFMailComposeViewControllerDelegate {
    var email: String? {
        didSet {
            self.addTarget(self, action: #selector(self.directMail), for: .touchUpInside)
        }
    }
    var subject: String = ""
    
    @objc func directMail() {
        
        let mailComposeViewController = configuredMailComposeViewController()
        if MFMailComposeViewController.canSendMail() {
            let vc = self.findViewController() as! BaseViewController
            vc.present(mailComposeViewController, animated: true, completion: nil)
        } else {
            self.showSendMailErrorAlert()
        }
        
    }
    
    func configuredMailComposeViewController() -> MFMailComposeViewController {
        let mailComposerVC = MFMailComposeViewController()
        mailComposerVC.mailComposeDelegate = self // Extremely important to set the --mailComposeDelegate-- property, NOT the --delegate-- property
        
        mailComposerVC.setToRecipients([self.email ?? ""])
        mailComposerVC.setSubject(self.subject)
        mailComposerVC.setMessageBody("", isHTML: false)
        
        return mailComposerVC
    }
    
    func showSendMailErrorAlert() {
        let sendMailErrorAlert = UIAlertView(title: "Could Not Send Email", message: "Your device could not send e-mail.  Please check e-mail configuration and try again.", delegate: self, cancelButtonTitle: "OK")
        sendMailErrorAlert.show()
    }
    
    // MARK: MFMailComposeViewControllerDelegate Method
    func mailComposeController(_ controller: MFMailComposeViewController, didFinishWith result: MFMailComposeResult, error: Error?) {
        controller.dismiss(animated: true, completion: nil)
    }
}
