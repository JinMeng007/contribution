//
//  AFAddressButton.swift
//  AFrame
//
//  Created by Lee Sheng Jin on 2019/4/2.
//  Copyright © 2019 DrawRanger. All rights reserved.
//

import UIKit
import Contacts
import ContactsUI

class AFAddressButton: UIButton {
    
    var contact: CNMutableContact? {
        didSet {
            self.addTarget(self, action: #selector(self.createAddress), for: .touchUpInside)
        }
    }
    
    @objc func createAddress() {
        let viewCon = self.findViewController() as! BaseViewController
        let vc = CNContactViewController(forNewContact: contact)
        vc.delegate = viewCon
        let navCon = UINavigationController(rootViewController: vc)
        viewCon.present(navCon, animated: true, completion: nil)
    }
    
}
