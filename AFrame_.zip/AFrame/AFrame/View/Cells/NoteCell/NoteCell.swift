//
//  NoteCell.swift
//  AFrame
//
//  Created by Lee Sheng Jin on 2019/2/13.
//  Copyright © 2019 DrawRanger. All rights reserved.
//

import UIKit

class NoteCell: UIView {
    
    // Type #1
    @IBOutlet weak var lblIcon1: UILabel!
    @IBOutlet weak var lblCont1: UILabel!
    @IBOutlet weak var lblDate1: UILabel!
    @IBOutlet weak var lblName1: UILabel!
    
    // Type #2
    @IBOutlet weak var lblIcon2: UILabel!
    @IBOutlet weak var lblCont2: UILabel!
    @IBOutlet weak var lblName2: UILabel!
    @IBOutlet weak var lblDate2: UILabel!
    @IBOutlet weak var btnFile: UIButton!
    
    // Type #3

    var type: Int = 0
    var contact_object: ContactDetail?
    var note: Note? {
        didSet {
            let dateFormatter = DateFormatter()
            dateFormatter.dateFormat = "yyyy-MM-dd"
            let noteDate = note?.noteDate?.utcToLocal(dateFormatter.dateFormat)
            switch self.type {
            case 0:
                self.lblCont1.setAttrTxt(note?.note ?? "")
                self.lblIcon1.text = note?.noteType?.getFontIcon()
                dateFormatter.dateFormat = "MMM d (E)"
                self.lblDate1.text = dateFormatter.string(from: noteDate!)
                break
            case 1:
                self.lblCont2.setAttrTxt(note?.note ?? "")
                self.lblIcon2.text = note?.noteType?.getFontIcon()
                self.lblDate2.text = dateFormatter.string(from: noteDate!)
                self.btnFile.setTitle(note?.fileName, for: .normal)
                break
            default:
                break
            }
        }
    }
    
    override init(frame: CGRect) {
        super.init(frame: frame)
    }
    
    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
    }
    
    func loadNib(_ type: Int) {
        let item = Bundle.main.loadNibNamed("NoteCell", owner: self, options: nil)?[type] as! UIView
        item.frame = self.bounds
        self.addSubview(item)
        self.type = type
    }
    
    @IBAction func actionDetail(_ sender: UIButton) {
//        let vc = self.findViewController() as! BaseViewController
//        let viewCon = vc.storyboard?.instantiateViewController(withIdentifier: "EditContactNoteVC") as! EditContactNoteVC
//        viewCon.note = self.note
//        viewCon.contact_object = self.contact_object
//        vc.navigationController?.pushViewController(viewCon, animated: true)
    }
    
    @IBAction func actionFileView(_ sender: UIButton) {
        if URL(string: note?.fileUrl ?? "") != nil {
            UIApplication.shared.open(URL(string: note?.fileUrl ?? "")!, options: [:], completionHandler: nil)
        }
    }
    
}
