//
//  TaskCell.swift
//  AFrame
//
//  Created by Lee Sheng Jin on 2019/2/10.
//  Copyright © 2019 DrawRanger. All rights reserved.
//

import UIKit

protocol TaskCellDelegate {
    func removeTask(_ cell: TaskCell)
    func snoozeTask(_ cell: TaskCell)
}

class TaskCell: UIView {
    // Header Components
    @IBOutlet weak var headerIcon: UILabel!
    @IBOutlet weak var lblHeader: UILabel!
    // Open Task Components
    @IBOutlet weak var taskIcon: UIButton!
    @IBOutlet weak var lblTaskCont: UILabel!
    @IBOutlet weak var lblTaskUser: UILabel!
    @IBOutlet weak var lblTaskTodo: UILabel!
    @IBOutlet weak var lblTaskTodoCont: UILabel!
    @IBOutlet weak var lblOpenDate: UILabel!
    @IBOutlet weak var btnOpenSnooze: UIButton!
    @IBOutlet weak var lblOpenStatus: UILabel!
    @IBOutlet weak var lblStatusIcon: UILabel!
    // Pending Task Components
    @IBOutlet weak var lblPendingIcon: UILabel!
    @IBOutlet weak var lblPendingCont: UILabel!
    @IBOutlet weak var lblBed: UILabel!
    @IBOutlet weak var lblPendingDate: UILabel!
    @IBOutlet weak var lblPendingTaskCont: UILabel!
    @IBOutlet weak var lblPendingTaskIcon: UILabel!
    @IBOutlet weak var btnPendingSnooze: UIButton!
    @IBOutlet weak var lblPendingStatus: UILabel!
    
    //Completed Task Components
    @IBOutlet weak var lblCompletedTaskCont: UILabel!
    @IBOutlet weak var lblCompletedDate: UILabel!
    @IBOutlet weak var lblCompletedTaskIcon: UILabel!
    @IBOutlet weak var lblCompletedTaskStatus: UILabel!
    
    var delegate: TaskCellDelegate?
    
    var task: Any? {
        didSet {
            let dateFormatter = DateFormatter()
            dateFormatter.locale = Locale(identifier: "en_US_POSIX")
            dateFormatter.dateFormat = "yyyy-MM-dd"
            let calendar = NSCalendar.current
            switch self.type {
            case 0:
                if self.task as? String == "Overdue" {
                    self.headerIcon.textColor = UIColor.red
                    self.lblHeader.textColor = UIColor.red
                    self.lblHeader.text = "Overdue"
                }else if self.task as? String == "Today" {
                    self.headerIcon.textColor = APP_ORANGE_COLOR
                    self.lblHeader.textColor = APP_ORANGE_COLOR
                    self.lblHeader.text = "Today"
                }else {
                    self.headerIcon.textColor = APP_BLUE_COLOR
                    self.lblHeader.textColor = APP_BLUE_COLOR
                    self.lblHeader.text = self.task as? String
                }
                break
            case 1:
                let task_instance = self.task as? Task
                let date1 = Date().utcToLocal(dateFormatter.dateFormat)
                let date2 = task_instance?.dueDate?.utcToLocal(dateFormatter.dateFormat) ?? Date().utcToLocal(dateFormatter.dateFormat)
                let components = calendar.dateComponents([.day], from: date1, to: date2)
                if components.day == 0 {
                    self.taskIcon.setTitleColor(APP_ORANGE_COLOR, for: .normal)
                }
                if components.day! < 0 {
                    self.taskIcon.setTitleColor(UIColor.red, for: .normal)
                }
                
                if components.day! > 0 {
                    if btnOpenSnooze != nil {
                        btnOpenSnooze.alpha = 0.0
                    }
                    if btnPendingSnooze != nil {
                        btnPendingSnooze.alpha = 0.0
                    }
                }
                
                self.lblTaskCont.setAttrTxt(task_instance?.subject ?? "")
                
                if task_instance?.contact != nil {
                    self.lblTaskUser.text = task_instance?.contact?.displayFirstLast
                }else if task_instance?.xaction != nil {
                    self.lblTaskUser.text = "\(task_instance?.xaction?.address?.addressLine ?? "") - \(task_instance?.xaction?.contact?.lastName ?? task_instance?.xaction?.contact?.company ?? "")"
                }else {
                    self.lblTaskUser.text = task_instance?.appUser?.displayFirstLast
                }
                
                dateFormatter.dateFormat = "MMM d (E)"
                self.lblOpenDate.text = dateFormatter.string(from: date2)
                self.lblTaskTodoCont.text = task_instance?.taskTypeDisplay
                self.lblTaskTodo.text = task_instance?.taskTypeDisplay?.getFontIcon()
                self.lblOpenStatus.text = task_instance?.statusDisplay
                if task_instance?.status != "OPEN" {
                    self.lblStatusIcon.textColor = APP_ORANGE_COLOR
                }
                break
            case 2:
                let task_instance = self.task as? Task
                let date1 = Date().utcToLocal(dateFormatter.dateFormat)
                let date2 = task_instance?.dueDate?.utcToLocal(dateFormatter.dateFormat) ?? Date().utcToLocal(dateFormatter.dateFormat)
                let components = calendar.dateComponents([.day], from: date1, to: date2)
                if components.day == 0 {
                    self.lblPendingIcon.textColor = APP_ORANGE_COLOR
                }
                if components.day! < 0 {
                    self.lblPendingIcon.textColor = UIColor.red
                }
                
                self.lblPendingCont.setAttrTxt(task_instance?.subject ?? "") //.text = task_instance?.subject
                
                dateFormatter.dateFormat = "MMM d (E)"
                self.lblPendingDate.text = dateFormatter.string(from: date2)
                self.lblPendingTaskCont.text = task_instance?.taskTypeDisplay
                self.lblPendingStatus.text = task_instance?.statusDisplay
                self.lblPendingTaskIcon.text = task_instance?.taskTypeDisplay?.getFontIcon()
                break
            case 4:
                let task_instance = self.task as? Task
                let completedDate = task_instance?.completeDate?.utcToLocal(dateFormatter.dateFormat)
                dateFormatter.dateFormat = "MMM d (E)"
                self.lblCompletedDate.text = dateFormatter.string(from: completedDate!)
                self.lblCompletedTaskCont.setAttrTxt(task_instance?.subject ?? "")
//                self.lblCompletedTaskCont.text = task_instance?.subject
                self.lblCompletedTaskStatus.text = task_instance?.taskTypeDisplay
                self.lblCompletedTaskIcon.text = task_instance?.taskTypeDisplay?.getFontIcon()
                break
            default:
                break
            }
        }
    }
    
    var type: Int = 0
    
    override init(frame: CGRect) {
        super.init(frame: frame)
    }
    
    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
    }
    
    func loadNib(_ type: Int) {
        let item = Bundle.main.loadNibNamed("TaskCell", owner: self, options: nil)?[type] as! UIView
        item.frame = self.bounds
        self.addSubview(item)
        self.type = type
    }
    
    @IBAction func actionDetail(_ sender: UIButton) {
//        let vc = self.findViewController() as! BaseViewController
//        let viewCon = vc.storyboard?.instantiateViewController(withIdentifier: "EditTaskVC") as! EditTaskVC
//        vc.showHUD()
//        API.sharedInstance.api_task_detail((task as! Task).taskId!) { (taskDetail) in
//            DispatchQueue.main.async {
//                vc.hideHUD()
//                viewCon.task = taskDetail
//                vc.navigationController?.pushViewController(viewCon, animated: true)
//            }
//        }
    }
    
    @IBAction func actionRemoveTask(_ sender: UIButton) {
        sender.setTitle(AppIcons.task.rawValue, for: .normal)
        self.delegate?.removeTask(self)
    }
    
    @IBAction func actionGotoDetail(_ sender: UIButton) {
        let vc = self.findViewController() as! BaseViewController
        let task_instance = task as! Task
        var contact_id: Int = 0
        
        if task_instance.xaction != nil {
            vc.showHUD()
            API.sharedInstance.api_xaction_detail(task_instance.xaction!.xactionId!) { (detail) in
                DispatchQueue.main.async {
                    if detail != nil {
                        let viewCon = vc.storyboard?.instantiateViewController(withIdentifier: "TransactionDetailVC") as! TransactionDetailVC
                        viewCon.xaction_detail = detail
                        API.sharedInstance.api_xaction_participants(task_instance.xaction!.xactionId!) { (participants) in
                            DispatchQueue.main.async {
                                vc.hideHUD()
                                viewCon.xaction_participants = participants ?? []
                                vc.navigationController?.pushViewController(viewCon, animated: true)
                            }
                        }
                    }else {
                        vc.hideHUD()
                    }
                }
            }
        }else {
            if task_instance.contact == nil {
                contact_id = task_instance.xaction!.contact!.contactId!
            }else {
                contact_id = task_instance.contact!.contactId!
            }
            vc.showHUD()
            API.sharedInstance.api_contact(contact_id) { (contact_detail) in
                DispatchQueue.main.async {
                    vc.hideHUD()
                    if contact_detail != nil {
                        let viewCon = vc.storyboard?.instantiateViewController(withIdentifier: "ContactDetailVC") as! ContactDetailVC
                        viewCon.contact_object = contact_detail
                        vc.navigationController?.pushViewController(viewCon, animated: true)
                    }
                }
            }
        }

    }
    
    @IBAction func actionSnooze(_ sender: UIButton) {
        let task_instance = self.task as! Task
        let dateFormatter = DateFormatter()
        dateFormatter.locale = Locale(identifier: "en_US_POSIX")
        dateFormatter.dateFormat = "yyyy-MM-dd"
        
//        let oldDue = task_instance.dueDate?.utcToLocal(dateFormatter.dateFormat) ?? Date().utcToLocal(dateFormatter.dateFormat)
//        print("TODAY IS == \(Date().utcToLocal(dateFormatter.dateFormat))")
        let newDue = Calendar.current.date(byAdding: .day, value: 1, to: Date().utcToLocal(dateFormatter.dateFormat))
        
//        print("TASK INFO -- \(task_instance.subject)")
//        print("Original Due Date --> \(task_instance.dueDate)")
//        print("NEW DUE --> \(dateFormatter.string(from: newDue!))")

        task_instance.dueDate = dateFormatter.string(from: newDue!)
//        print("NEW SET Due --> \(task_instance.dueDate)")

        
        dateFormatter.dateFormat = "MMM dd (E)"
        
        if self.lblOpenDate != nil {
//               let newDue = Calendar.current.date(byAdding: .day, value: 1, to: task_instance.dueDate?.utcToLocal(dateFormatter))
            self.lblOpenDate.text = dateFormatter.string(from: newDue!)
            print("NEW SET TEXT --> \(dateFormatter.string(from: newDue!))")
        }
        if self.lblPendingDate != nil {
            self.lblPendingDate.text = dateFormatter.string(from: newDue!)
            print("NEW SET TEXT --> \(dateFormatter.string(from: newDue!))")
        }
        
//        print("SENT DATE --> \(task_instance.dueDate)")

        API.sharedInstance.api_snooze_task(task_instance)
        self.delegate?.snoozeTask(self)
    }
    
}
