//
//  ContractDateCell.swift
//  AFrame
//
//  Created by Lee Sheng Jin on 2019/2/14.
//  Copyright © 2019 DrawRanger. All rights reserved.
//

import UIKit

class ContractDateCell: UIView {
    
    @IBOutlet weak var lblIcon: UILabel!
    @IBOutlet weak var lblTitle: UILabel!
    @IBOutlet weak var lblSubTitle: UILabel!
    @IBOutlet weak var lblEye: UILabel!
    @IBOutlet weak var lblBtmLine: UIView!
    
    var contractDate: ContractDate? {
        didSet {
            self.lblTitle.setAttrTxt(contractDate?.title ?? "") 
            let dateFormatter = DateFormatter()
            dateFormatter.dateFormat = "yyyy-MM-dd"
            let date = contractDate?.startDate?.utcToLocal(dateFormatter.dateFormat) ?? Date().utcToLocal(dateFormatter.dateFormat)
            let differenceDays = Calendar.current.dateComponents([.day], from: Date().utcToLocal(dateFormatter.dateFormat), to: date)
            dateFormatter.dateFormat = "MMM d (EEEE)"
            if differenceDays.day! == 0 {
                self.lblSubTitle.text = "\(dateFormatter.string(from: date)) Today"
            }
            if differenceDays.day! > 0 {
                self.lblSubTitle.text = "\(dateFormatter.string(from: date)) In \(differenceDays.day!) days"
            }
            if differenceDays.day! < 0 {
                self.lblSubTitle.text = "\(dateFormatter.string(from: date)) \(-differenceDays.day!) days ago"
                self.lblIcon.textColor = APP_GRAY_COLOR
                self.lblTitle.textColor = APP_GRAY_COLOR
            }
        }
    }
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        self.loadNib()
    }
    
    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
        self.loadNib()
    }
    
    func loadNib() {
        let item = Bundle.main.loadNibNamed("ContractDateCell", owner: self, options: nil)?.first as! UIView
        item.frame = self.bounds
        self.addSubview(item)
    }
    
    @IBAction func actionGotoDetail(_ sender: UIButton) {
//        let vc = self.findViewController() as! BaseViewController
//        if contractDate?.xactionId != nil {
//            let viewCon = vc.storyboard?.instantiateViewController(withIdentifier: "TransactionDetailVC") as! TransactionDetailVC
//            vc.showHUD()
//            API.sharedInstance.api_xaction_detail(contractDate?.xactionId ?? 0) { (detail) in
//                DispatchQueue.main.async {
//                    if detail != nil {
//                        viewCon.xaction_detail = detail
//                        API.sharedInstance.api_xaction_participants(self.contractDate?.xactionId ?? 0) { (participants) in
//                            DispatchQueue.main.async {
//                                vc.hideHUD()
//                                viewCon.xaction_participants = participants ?? []
//                                vc.navigationController?.pushViewController(viewCon, animated: true)
//                            }
//                        }
//                    }else {
//                        vc.hideHUD()
//                    }
//                }
//            }
//        }else {
//            let viewCon = vc.storyboard?.instantiateViewController(withIdentifier: "ContactDetailVC") as! ContactDetailVC
//            vc.showHUD()
//            API.sharedInstance.api_contact(contractDate?.contactId ?? 0) { (contact_detail) in
//                DispatchQueue.main.async {
//                    vc.hideHUD()
//                    if contact_detail != nil {
//                        viewCon.contact_object = contact_detail
//                        vc.navigationController?.pushViewController(viewCon, animated: true)
//                    }
//                }
//            }
//        }
    }
    
}
