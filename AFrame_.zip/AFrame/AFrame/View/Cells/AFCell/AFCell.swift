//
//  AFCell.swift
//  AFrame
//
//  Created by Lee Sheng Jin on 2019/3/3.
//  Copyright © 2019 DrawRanger. All rights reserved.
//

import UIKit

class AFCell: UITableViewCell {

    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
}
