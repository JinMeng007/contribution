//
//  AttachmentCell.swift
//  AFrame
//
//  Created by Lee Sheng Jin on 2019/2/14.
//  Copyright © 2019 DrawRanger. All rights reserved.
//

import UIKit

class AttachmentCell: UIView {
    
    // Type #1
    @IBOutlet weak var lblIcon1: UILabel!
    @IBOutlet weak var lblTitle1: UIButton!
    @IBOutlet weak var lblDate1: UILabel!
    @IBOutlet weak var lblEye: UILabel!
    
    // Type #2
    @IBOutlet weak var lblTitle2: UIButton!
    
    var attachment: Any? {
        didSet {
            if attachment is String {
                self.lblTitle2.setTitle(attachment as? String, for: .normal)
            }else {
                let attach_instance = attachment as! XActionAttachmentDetail
                if attach_instance.fileSizeBytes == nil {
                    self.lblIcon1.text = AppIcons.link.rawValue
                    self.lblTitle1.setTitle(attach_instance.descript, for: .normal)
                }else {
                    self.lblTitle1.setTitle(attach_instance.fileName, for: .normal)
                    self.lblIcon1.text = AppIcons.file.rawValue
                }
                if (attach_instance.isPublished!) {
                    self.lblEye.text = AppIcons.eye.rawValue
                    self.lblEye.textColor = APP_GREEN_COLOR
                }else {
                    self.lblEye.text = AppIcons.eye_slash.rawValue
                    self.lblEye.textColor = UIColor.red
                }
                let date = Date(timeIntervalSince1970: attach_instance.uploadedDateTime! / 1000).utcToLocal("MMM d (E)")
                let dateFormatter = DateFormatter()
                dateFormatter.dateFormat = "MMM d (E)"
                self.lblDate1.text = dateFormatter.string(from: date)
            }
        }
    }
    
    override init(frame: CGRect) {
        super.init(frame: frame)
    }
    
    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
    }
    
    func loadNib(_ type: Int) {
        let item = Bundle.main.loadNibNamed("AttachmentCell", owner: self, options: nil)?[type] as! UIView
        item.frame = self.bounds
        self.addSubview(item)
    }
    
    @IBAction func actionOpenLink(_ sender: UIButton) {
        if !(self.attachment is String) {
            let attach_instance = attachment as! XActionAttachmentDetail
            if attach_instance.webLink != nil {
                if URL(string: attach_instance.webLink!) != nil {
                    UIApplication.shared.open(URL(string: attach_instance.webLink!)!, options: [:], completionHandler: nil)
                }
            }
            if attach_instance.fileUrl != nil {
                if URL(string: attach_instance.fileUrl ?? "") != nil {
                    UIApplication.shared.open(URL(string: attach_instance.fileUrl ?? "")!, options: [:], completionHandler: nil)
                }
            }
        }
    }
    
    @IBAction func actionToggle(_ sender: UIButton) {
        let attach_instance = attachment as! XActionAttachmentDetail
        attach_instance.isPublished = attach_instance.isPublished != nil ? !attach_instance.isPublished! : true
        if (attach_instance.isPublished!) {
            self.lblEye.text = AppIcons.eye.rawValue
            self.lblEye.textColor = APP_GREEN_COLOR
        }else {
            self.lblEye.text = AppIcons.eye_slash.rawValue
            self.lblEye.textColor = UIColor.red
        }
        let param: [String: Any] = [
            "isPublished": attach_instance.isPublished!
        ]
        API.sharedInstance.api_xaction_attach_patch(attach_instance.xactionAttachmentId!, param)
    }
    
}
