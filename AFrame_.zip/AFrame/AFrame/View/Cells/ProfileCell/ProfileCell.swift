//
//  ProfileCell.swift
//  AFrame
//
//  Created by Lee Sheng Jin on 2019/2/10.
//  Copyright © 2019 DrawRanger. All rights reserved.
//

import UIKit

class ProfileCell: UIView {
    
    @IBOutlet weak var lblUsername: UILabel!
    @IBOutlet weak var lblCount: UILabel!
    @IBOutlet weak var lblHome: UILabel!
    
    var contact: Contact? {
        didSet {
            lblUsername.text = contact?.displayFirstLast
            if contact?.xactionCount == nil || contact?.xactionCount == 0 {
                lblCount.text = ""
                lblHome.alpha = 0.0
            }else {
                lblCount.text = "\(contact?.xactionCount ?? 0)"
            }
        }
    }
    
    var appUser: AppUser? {
        didSet {
            lblUsername.text = appUser?.displayFirstLast
            lblCount.text = ""
        }
    }

    override init(frame: CGRect) {
        super.init(frame: frame)
        self.loadNib()
    }
    
    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
        self.loadNib()
    }
    
    func loadNib() {
        let item = Bundle.main.loadNibNamed("ProfileCell", owner: self, options: nil)?.first as! UIView
        item.frame = self.bounds
        self.addSubview(item)
    }
    
    @IBAction func actionContactDetail(_ sender: UIButton) {
        let vc = self.findViewController() as! BaseViewController
        if vc is UsersVC {
            let appDelegate: AppDelegate = UIApplication.shared.delegate as! AppDelegate
            appDelegate.selected_appUser = self.appUser
            vc.dismiss(animated: true, completion: nil)
        }else {
            vc.showHUD()
            API.sharedInstance.api_contact(contact!.contactId!) { (contact_detail) in
                DispatchQueue.main.async {
                    vc.hideHUD()
                    if contact_detail != nil {
                        let viewCon = vc.storyboard?.instantiateViewController(withIdentifier: "ContactDetailVC") as! ContactDetailVC
                        viewCon.contact_object = contact_detail
                        vc.navigationController?.pushViewController(viewCon, animated: true)
                    }
                }
            }
        }
    }
    
}
