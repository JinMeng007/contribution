//
//  TransactionCell.swift
//  AFrame
//
//  Created by Lee Sheng Jin on 2019/2/9.
//  Copyright © 2019 DrawRanger. All rights reserved.
//

import UIKit

class TransactionCell: UIView {
    
    @IBOutlet weak var lblAddress: UILabel!
    @IBOutlet weak var lblDispFL: UILabel!
    @IBOutlet weak var lblSide: UILabel!
    @IBOutlet weak var lblPrice: UILabel!
    @IBOutlet weak var badgeView: UIView!
    @IBOutlet weak var lblStatus: UILabel!
    
    var transaction: Transaction? {
        didSet {
            lblAddress.text = transaction?.address?.addressLine
            lblDispFL.text = transaction?.contact?.displayFirstLast
            lblSide.text = transaction?.xactionSide?.capitalized
            let price = transaction?.price ?? 0
            lblPrice.text = price.getCurrency()
            badgeView.backgroundColor = transaction?.statusColorHex?.getColor() ?? UIColor.black
            if transaction?.statusStage == 3 || transaction?.statusStage == 4 {
               let dateFormatter = DateFormatter()
               dateFormatter.dateFormat = "yyyy-MM-dd"
               var date = transaction?.closingDate?.utcToLocal("yyyy-MM-dd") ?? Date().utcToLocal(dateFormatter.dateFormat)
               if transaction?.statusStage == 4 {
                  date = transaction?.closedDate?.utcToLocal("yyyy-MM-dd") ?? Date().utcToLocal(dateFormatter.dateFormat)
               }
               dateFormatter.dateFormat = "MMM d, yyyy"
               
               let attrText = NSMutableAttributedString.init(string: "\(transaction?.status?.capitalized ?? "") (\(dateFormatter.string(from: date)))")
               attrText.setAttributes([NSAttributedString.Key.font: UIFont(name: "Gordita-Regular", size: 11.0)!, NSAttributedString.Key.foregroundColor: UIColor.black], range: NSMakeRange(0, "\(transaction?.status?.capitalized ?? "")".count))
               
               lblStatus.attributedText = attrText
            }else {
               let attrText = NSMutableAttributedString.init(string: "\(transaction?.status?.capitalized ?? "")")
               attrText.setAttributes([NSAttributedString.Key.font: UIFont(name: "Gordita-Regular", size: 11.0)!, NSAttributedString.Key.foregroundColor: UIColor.black], range: NSMakeRange(0, "\(transaction?.status?.capitalized ?? "")".count))
               lblStatus.attributedText = attrText
            }
        }
    }
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        self.loadNib()
    }
    
    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
        self.loadNib()
    }
    
    func loadNib() {
        let item = Bundle.main.loadNibNamed("TransactionCell", owner: self, options: nil)?.first as! UIView
        item.frame = self.bounds
        self.addSubview(item)
    }
    
    @IBAction func actionGotoDetail(_ sender: UIButton) {
        let vc = self.findViewController() as! BaseViewController
        let viewCon = vc.storyboard?.instantiateViewController(withIdentifier: "TransactionDetailVC") as! TransactionDetailVC
         vc.showHUD()
         API.sharedInstance.api_xaction_detail(transaction!.xactionId!) { (detail) in
            DispatchQueue.main.async {
               if detail != nil {
                  viewCon.xaction_detail = detail
                  API.sharedInstance.api_xaction_participants(self.transaction!.xactionId!) { (participants) in
                     DispatchQueue.main.async {
                        vc.hideHUD()
                        viewCon.xaction_participants = participants ?? []
                        vc.navigationController?.pushViewController(viewCon, animated: true)
                     }
                  }
               }else {
                  vc.hideHUD()
               }
            }
         }
    }
    
}
