//
//  UpcomingDateCell.swift
//  AFrame
//
//  Created by Lee Sheng Jin on 2019/2/10.
//  Copyright © 2019 DrawRanger. All rights reserved.
//

import UIKit

class UpcomingDateCell: UIView {
    
    @IBOutlet weak var badgeIcon: UILabel!
    @IBOutlet weak var lblUpcomingCont: UILabel!
    @IBOutlet weak var lblUpcomingUser: UILabel!
    @IBOutlet weak var taskIcon: UILabel!
    @IBOutlet weak var lblTaskTitle: UILabel!
    @IBOutlet weak var lblDate: UILabel!
    
    var event: Event? {
        didSet {
            lblUpcomingCont.text = event?.title
            if event?.xaction != nil {
                lblUpcomingUser.text = "\(event?.xaction?.address?.addressLine ?? "") - \(event?.xaction?.contact?.lastName ?? event?.xaction?.contact?.company ?? "")"
                lblTaskTitle.text = "Transaction"
                taskIcon.text = AppIcons.home.rawValue
            }else if event?.contact != nil {
                lblUpcomingUser.text = event?.contact?.displayFirstLast
                lblTaskTitle.text = "Contact"
                taskIcon.text = AppIcons.profile.rawValue
            }
            if event?.contact == nil && event?.xaction == nil {
                lblUpcomingUser.alpha = 0.0
            }
            let dateFormatter = DateFormatter()
            dateFormatter.dateFormat = "yyyy-MM-dd"
            let date = event?.startDate?.utcToLocal(dateFormatter.dateFormat)
            switch date!.compare(Date().utcToLocal(dateFormatter.dateFormat)) {
            case .orderedAscending:
                badgeIcon.textColor = UIColor(red: 153 / 255, green: 153 / 255, blue: 153 / 255, alpha: 1.0)
                break
            case .orderedDescending:
                badgeIcon.textColor = APP_BLUE_COLOR
                break
            default:
                badgeIcon.textColor = APP_ORANGE_COLOR
                break
            }
            dateFormatter.dateFormat = "MMM d (E)"
            if self.event?.startTimeMinutes != nil && self.event?.startTimeMinutes != 0 {
                var hour = Int(self.event!.startTimeMinutes! / 60)
                let minute = self.event!.startTimeMinutes! % 60
                var suffix = "am"
                if hour > 12 {
                    hour = hour - 12
                    suffix = "pm"
                }
                if minute > 9 {
                    self.lblDate.text = "\(dateFormatter.string(from: date!)) \(hour):\(minute) \(suffix)"
                }else {
                    self.lblDate.text = "\(dateFormatter.string(from: date!)) \(hour):0\(minute) \(suffix)"
                }
            }else {
                self.lblDate.text = dateFormatter.string(from: date!)
            }
        }
    }
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        self.loadNib()
    }
    
    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
        self.loadNib()
    }
    
    func loadNib() {
        let item = Bundle.main.loadNibNamed("UpcomingDateCell", owner: self, options: nil)?.first as! UIView
        item.frame = self.bounds
        self.addSubview(item)
    }
    
    @IBAction func actionGotoDetail(_ sender: UIButton) {
        if event?.xaction != nil {
            let vc = self.findViewController() as! BaseViewController
            let viewCon = vc.storyboard?.instantiateViewController(withIdentifier: "TransactionDetailVC") as! TransactionDetailVC
            vc.showHUD()
            API.sharedInstance.api_xaction_detail(self.event!.xactionId!) { (detail) in
                DispatchQueue.main.async {
                    if detail != nil {
                        viewCon.xaction_detail = detail
                        API.sharedInstance.api_xaction_participants(self.event!.xactionId!) { (participants) in
                            DispatchQueue.main.async {
                                vc.hideHUD()
                                viewCon.xaction_participants = participants ?? []
                                vc.navigationController?.pushViewController(viewCon, animated: true)
                            }
                        }
                    }else {
                        vc.hideHUD()
                    }
                }
            }
        }else {
            let vc = self.findViewController() as! BaseViewController
            vc.showHUD()
            API.sharedInstance.api_contact(self.event!.contactId!) { (contact_detail) in
                DispatchQueue.main.async {
                    vc.hideHUD()
                    if contact_detail != nil {
                        let viewCon = vc.storyboard?.instantiateViewController(withIdentifier: "ContactDetailVC") as! ContactDetailVC
                        viewCon.contact_object = contact_detail
                        vc.navigationController?.pushViewController(viewCon, animated: true)
                    }
                }
            }
        }
    }
    
}
