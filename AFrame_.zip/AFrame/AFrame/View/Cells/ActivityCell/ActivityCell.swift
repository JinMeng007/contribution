//
//  ActivityCell.swift
//  AFrame
//
//  Created by Lee Sheng Jin on 2019/2/14.
//  Copyright © 2019 DrawRanger. All rights reserved.
//

import UIKit

class ActivityCell: UIView {
    
    // Import Type
    @IBOutlet weak var lblGTitle: UILabel!
    @IBOutlet weak var lblGName: UILabel!
    @IBOutlet weak var lblGDate: UILabel!
    @IBOutlet weak var lblGCellPhone: UILabel!
    @IBOutlet weak var lblGNormPhone: UILabel!
    @IBOutlet weak var lblGEmail: UILabel!
    @IBOutlet weak var typeIcon: UILabel!
    @IBOutlet weak var lblGRepeatShow: UILabel!
    
    // Generic Type 1
    @IBOutlet weak var type1Icon: UILabel!
    @IBOutlet weak var t1_lblTitle: UILabel!
    @IBOutlet weak var t1_btnFile: UIButton!
    @IBOutlet weak var t1_lblDate: UILabel!
    @IBOutlet weak var t1_fileIcon: UILabel!
    @IBOutlet weak var t1_phoneIcon: UILabel!
    @IBOutlet weak var t1_callIcon: UILabel!
    @IBOutlet weak var t1_mailIcon: UILabel!
    
    // Generic Type 2
    @IBOutlet weak var t2_typeIcon: UILabel!
    @IBOutlet weak var t2_lblTitle: UILabel!
    @IBOutlet weak var t2_lblDate: UILabel!
    
    
    // Generic Type 3
    @IBOutlet weak var t3_typeIcon: UILabel!
    @IBOutlet weak var t3_lblTitle: UILabel!
    @IBOutlet weak var t3_lblNote: UILabel!
    @IBOutlet weak var t3_lblFile: UIButton!
    @IBOutlet weak var t3_lblDate: UILabel!
    
    @IBOutlet var lblEyes: [UILabel]!

    var type: Int = 0
    var activity: TransactionActivity? {
        didSet {
            switch type {
            case 0:
                type1Icon.text = activity?.xactionActivityGeneric?.xactionActivityType?.name?.getFontIcon()
                t1_lblTitle.setAttrTxt(activity?.xactionActivityGeneric?.note ?? "") //.text = activity?.xactionActivityGeneric?.note
                if activity?.xactionActivityGeneric?.fileName == nil || activity?.xactionActivityGeneric?.fileName == "" {
                    t1_fileIcon.text = AppIcons.link.rawValue
                    t1_btnFile.setTitle(activity?.xactionActivityGeneric?.url, for: .normal)
                }else {
                    t1_fileIcon.text = AppIcons.file.rawValue
                    t1_btnFile.setTitle(activity?.xactionActivityGeneric?.fileName, for: .normal)
                }
                let dateFormatter = DateFormatter()
                dateFormatter.dateFormat = "yyyy-MM-dd"
                let activityDate = activity!.xactionActivityGeneric!.activityDate!.utcToLocal(dateFormatter.dateFormat)
                dateFormatter.dateFormat = "MMM d, (E)"
                t1_lblDate.text = dateFormatter.string(from: activityDate)
                self.lblEyes[0].textColor = self.activity!.xactionActivityGeneric!.isPublished! ? APP_GREEN_COLOR : UIColor.red
                self.lblEyes[0].text = self.activity!.xactionActivityGeneric!.isPublished! ? AppIcons.eye.rawValue : AppIcons.eye_slash.rawValue
                break
            case 1:
                self.lblGTitle.setAttrTxt(activity?.xactionActivityImport?.feedback ?? "")
//                lblGTitle.text = activity?.xactionActivityImport?.feedback
                lblGName.text = activity?.xactionActivityImport?.showAgentName
                lblGCellPhone.text = activity?.xactionActivityImport?.showAgentPhone2
                lblGNormPhone.text = activity?.xactionActivityImport?.showAgentPhone1
                lblGEmail.text = activity?.xactionActivityImport?.showAgentEmail
                lblGRepeatShow.alpha = activity?.xactionActivityImport?.isSecondShowing ?? false ? 1 : 0
                
                if activity?.xactionActivityImport?.showAgentName == nil || activity?.xactionActivityImport?.showAgentName == "" {
                    lblGName.alpha = 0.0
                }
                if activity?.xactionActivityImport?.showAgentPhone2 == nil || activity?.xactionActivityImport?.showAgentPhone2 == "" {
                    lblGCellPhone.alpha = 0.0
                    t1_phoneIcon.alpha = 0.0
                }
                if activity?.xactionActivityImport?.showAgentPhone1 == nil || activity?.xactionActivityImport?.showAgentPhone1 == "" {
                    lblGNormPhone.alpha = 0.0
                    t1_callIcon.alpha = 0.0
                }
                if activity?.xactionActivityImport?.showAgentEmail == nil || activity?.xactionActivityImport?.showAgentEmail == "" {
                    lblGEmail.alpha = 0.0
                    t1_mailIcon.alpha = 0.0
                }
                let dateFormatter = DateFormatter()
                dateFormatter.dateFormat = "yyyy-MM-dd"
                let activityDate = activity!.xactionActivityImport!.activityDate!.utcToLocal(dateFormatter.dateFormat)
                dateFormatter.dateFormat = "MMM d, (E)"
                lblGDate.text = dateFormatter.string(from: activityDate)
                self.lblEyes[1].textColor = self.activity!.xactionActivityImport!.isPublished! ? APP_GREEN_COLOR : UIColor.red
                self.lblEyes[1].text = self.activity!.xactionActivityImport!.isPublished! ? AppIcons.eye.rawValue : AppIcons.eye_slash.rawValue
                break
            case 2:
                t2_typeIcon.text = activity?.xactionActivityGeneric?.xactionActivityType?.name?.getFontIcon()
                t2_lblTitle.setAttrTxt(activity?.xactionActivityGeneric?.note ?? "") //.text = activity?.xactionActivityGeneric?.note
                let dateFormatter = DateFormatter()
                dateFormatter.dateFormat = "yyyy-MM-dd"
                let activityDate = activity!.xactionActivityGeneric!.activityDate!.utcToLocal(dateFormatter.dateFormat)
                dateFormatter.dateFormat = "MMM d, (E)"
                t2_lblDate.text = dateFormatter.string(from: activityDate)
                self.lblEyes[2].textColor = self.activity!.xactionActivityGeneric!.isPublished! ? APP_GREEN_COLOR : UIColor.red
                self.lblEyes[2].text = self.activity!.xactionActivityGeneric!.isPublished! ? AppIcons.eye.rawValue : AppIcons.eye_slash.rawValue
                break
            default:
                break
            }
        }
    }
    
    override init(frame: CGRect) {
        super.init(frame: frame)
    }
    
    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
    }
    
    func loadNib(_ type: Int) {
        let item = Bundle.main.loadNibNamed("ActivityCell", owner: self, options: nil)?[type] as! UIView
        item.frame = self.bounds
        self.addSubview(item)
        self.type = type
    }
    
    @IBAction func actionGotoFile(_ sender: UIButton) {
        if activity?.xactionActivityGeneric != nil {
            if activity?.xactionActivityGeneric?.fileUrl != nil {
                if URL(string: activity?.xactionActivityGeneric?.fileUrl ?? "") != nil {
                    UIApplication.shared.open(URL(string: activity?.xactionActivityGeneric?.fileUrl ?? "")!, options: [:], completionHandler: nil)
                }
            }else if activity?.xactionActivityGeneric?.url != nil {
                if URL(string: activity?.xactionActivityGeneric?.url ?? "") != nil {
                    UIApplication.shared.open(URL(string: activity?.xactionActivityGeneric?.url ?? "")!, options: [:], completionHandler: nil)
                }
            }
        }
        if activity?.xactionActivityImport != nil {
            let xactionID = activity?.xactionActivityImport?.xactionId ?? 0
            if URL(string: APIURL.xaction_file_view.appending("\(xactionID)")) != nil {
                UIApplication.shared.open(URL(string: APIURL.xaction_file_view.appending("\(xactionID)"))!, options: [:], completionHandler: nil)
            }
        }
        
    }
    
    @IBAction func actionGotoDetail(_ sender: UIButton) {
//        let vc = self.findViewController() as! BaseViewController
//        let viewCon = vc.storyboard?.instantiateViewController(withIdentifier: "XActivityGenericVC") as! XActivityGenericVC
//
//        vc.showHUD()
//        API.sharedInstance.api_xactionactivity_generic_detail(self.activity!.xactionActivityGeneric!.xactionActivityId!) { (xagdetail) in
//            DispatchQueue.main.async {
//                vc.hideHUD()
//                if xagdetail != nil {
//                    viewCon.activity = xagdetail
//                    vc.navigationController?.pushViewController(viewCon, animated: true)
//                }
//            }
//        }
    }
    
    @IBAction func actionGotoImportDetail(_ sender: UIButton) {
//        let vc = self.findViewController() as! BaseViewController
//        let viewCon = vc.storyboard?.instantiateViewController(withIdentifier: "XActivityImportVC") as! XActivityImportVC
//        vc.showHUD()
//        API.sharedInstance.api_xactionactivity_import_detail(self.activity!.xactionActivityImport!.xactionActivityImportId!) { (xaidetail) in
//            DispatchQueue.main.async {
//                vc.hideHUD()
//                if xaidetail != nil {
//                    viewCon.activity = xaidetail
//                    vc.navigationController?.pushViewController(viewCon, animated: true)
//                }
//            }
//        }
    }
    
    @IBAction func actionToggle(_ sender: UIButton) {
        if self.type == 1 {
            self.activity?.xactionActivityImport?.isPublished = self.activity?.xactionActivityImport?.isPublished != nil ? !self.activity!.xactionActivityImport!.isPublished! : false
            self.lblEyes[sender.tag - 100].textColor = self.activity!.xactionActivityImport!.isPublished! ? APP_GREEN_COLOR : UIColor.red
            self.lblEyes[sender.tag - 100].text = self.activity!.xactionActivityImport!.isPublished! ? AppIcons.eye.rawValue : AppIcons.eye_slash.rawValue
            let param: [String: Any] = [
                "isPublished": self.activity!.xactionActivityImport!.isPublished!
            ]
            API.sharedInstance.api_xactionactivity_import_patch(activity!.xactionActivityImport!.xactionActivityImportId!, param)
        }else {
            self.activity?.xactionActivityGeneric?.isPublished = self.activity?.xactionActivityGeneric?.isPublished != nil ? !self.activity!.xactionActivityGeneric!.isPublished! : false
            self.lblEyes[sender.tag - 100].textColor = self.activity!.xactionActivityGeneric!.isPublished! ? APP_GREEN_COLOR : UIColor.red
            self.lblEyes[sender.tag - 100].text = self.activity!.xactionActivityGeneric!.isPublished! ? AppIcons.eye.rawValue : AppIcons.eye_slash.rawValue
            let param: [String: Any] = [
                "isPublished": self.activity!.xactionActivityGeneric!.isPublished!
            ]
            API.sharedInstance.api_xactionactivity_generic_patch(activity!.xactionActivityGeneric!.xactionActivityId!, param)
        }
    }
    
}
