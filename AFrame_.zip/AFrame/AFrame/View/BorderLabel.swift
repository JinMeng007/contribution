//
//  BorderView.swift
//  AFrame
//
//  Created by Lee Sheng Jin on 2019/2/13.
//  Copyright © 2019 DrawRanger. All rights reserved.
//

import UIKit

class BorderLabel: UILabel {

    override func layoutSubviews() {
        self.clipsToBounds = true
        self.textColor = APP_BLUE_COLOR
        self.textAlignment = .center
        self.layer.cornerRadius = 8.0
        self.layer.borderColor = UIColor(red: 240 / 255, green: 240 / 255, blue: 240 / 255, alpha: 1.0).cgColor
        self.layer.borderWidth = 1.0
    }

}
