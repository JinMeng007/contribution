//
//  AFSwitch.swift
//  AFrame
//
//  Created by Lee Sheng Jin on 2019/2/15.
//  Copyright © 2019 DrawRanger. All rights reserved.
//

import UIKit

class AFSwitch: UISwitch {
    override func awakeFromNib() {
        super.awakeFromNib()
    }
    
    override func layoutSubviews() {
        super.layoutSubviews()
        self.initialize()
    }
    
    func initialize() {
        self.transform = CGAffineTransform(scaleX: 0.75, y: 0.75)
    }
}
