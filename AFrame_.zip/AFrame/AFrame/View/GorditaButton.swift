//
//  GorditaButton.swift
//  AFrame
//
//  Created by Lee Sheng Jin on 2019/2/26.
//  Copyright © 2019 DrawRanger. All rights reserved.
//

import UIKit

class GorditaButton: UIButton {
    override func layoutSubviews() {
        self.titleLabel?.font = UIFont(name: "Gordita-Medium", size: 15)!
        self.titleLabel?.textColor = APP_BLUE_COLOR
    }
}
