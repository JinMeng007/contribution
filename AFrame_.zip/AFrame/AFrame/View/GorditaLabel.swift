//
//  GorditaLabel.swift
//  AFrame
//
//  Created by Lee Sheng Jin on 2019/2/26.
//  Copyright © 2019 DrawRanger. All rights reserved.
//

import UIKit

class GorditaLabel: UILabel {
    var fontSize: CGFloat = 15
    override func layoutSubviews() {
        self.font = UIFont(name: "Gordita-Medium", size: fontSize)!
        self.textColor = APP_BLUE_COLOR
    }
}
