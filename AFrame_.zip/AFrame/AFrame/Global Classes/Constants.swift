//
//  Constants.swift
//  AFrame
//
//  Created by Lee Sheng Jin on 2019/2/9.
//  Copyright © 2019 DrawRanger. All rights reserved.
//

import UIKit

let APP_ORANGE_COLOR = UIColor(red: 255 / 255, green: 100 / 255, blue: 35 / 255, alpha: 1.0)
let APP_BLUE_COLOR = UIColor(red: 45 / 255, green: 46 / 255, blue: 80 / 255, alpha: 1.0)
let APP_GRAY_COLOR = UIColor(red: 153 / 255, green: 153 / 255, blue: 153 / 255, alpha: 1.0)
let APP_GREEN_COLOR = UIColor(red: 0, green: 104 / 255, blue: 55 / 255, alpha: 1.0)
let APP_LIGHT_GRAY_COLOR = UIColor(red: 200 / 255, green: 200 / 255, blue: 200 / 255, alpha: 1.0)

//let baseURL: String = "http://staging.aframeonline.com/afsApi/api/v1/"
let baseURL: String = "http://app.aframeonline.com/afsApi/api/v1/"

enum AppIcons: String {
    case todo = ""
    case calendar = ""
    case letter = ""
    case email = ""
    case phone = ""
    case task = ""
    case profile = ""
    case home = ""
    case dob = ""
    case right_arrow = ""
    case drop_arrow = ""
    case up_arrow = ""
    case comment = ""
    case dollar = ""
    case file = ""
    case link = ""
    case list = ""
    case folder_open = ""
    case btm_line_box = ""
    case circle_notch = ""
    case user_profile = ""
    case eye = ""
    case eye_slash = ""
    case save = ""
    case sms = ""
    case map = ""
}

struct APIURL {
    static let sign_up: String = "https://www.aframeonline.com/afs/CreateNewAccount.action"
    static let forgot_password: String = "https://www.aframeonline.com/afs/ForgotPassword.action"
    static let contact_detail_edit: String = "https://www.aframeonline.com/afs/app/ContactDetail_edit.action?contactId="
    static let contact_create: String = "https://www.aframeonline.com/afs/app/ContactDetail_new.action"
    static let xaction_activity_summary: String = "https://www.aframeonline.com/afs/app/ActivitySummary.action"
    static let xaction_edit: String = "https://www.aframeonline.com/afs/app/XactionDetail_edit.action?xactionId="
    static let attach_file_view: String = "https://www.aframeonline.com/afs/app/FileView_user.action?xactionAttachmentId="
    static let note_file_view: String = "https://www.aframeonline.com/afs/app/FileView_user.action?contactNoteId="
    static let xaction_file_view: String = "https://www.aframeonline.com/afs/app/FileView_user.action?xactionId="
    
    static let authentication: String = baseURL.appending("authentication")
    static let user_object_detail: String = baseURL.appending("app/appusers/appuser/")
    static let current_login_users: String = baseURL.appending("app/appusers/appuser/current")
    static let active_app_users: String = baseURL.appending("app/appusers/active?includeAppUserId=")
    static let search: String = baseURL.appending("app/search?")
    static let contact: String = baseURL.appending("app/contacts/contact/")
    static let contact_note: String = baseURL.appending("app/contactnotes/contactnote/")
    static let contact_notes: String = baseURL.appending("app/contactnotes?contactId=")
    static let xaction_detail: String = baseURL.appending("app/xactions/xaction/")
    static let get_open_xactions: String = baseURL.appending("app/xactions/open?view=")
    static let get_contact_xactions: String = baseURL.appending("app/xactions?contactId=")
    static let xactionactivity_generic: String = baseURL.appending("app/xactionactivities/xactionactivity/")
    static let xactionactivity_import: String = baseURL.appending("app/xactionactivities/xactionactivityimport/")
    static let xaction_activities: String = baseURL.appending("app/xactionactivities?xactionId=")
    static let xaction_attatchments: String = baseURL.appending("app/xactionattachments?xactionId=")
    static let xaction_attatchment: String = baseURL.appending("app/xactionattachments/xactionattachment/")
    static let task: String = baseURL.appending("app/tasks/task/")
    static let open_tasks: String = baseURL.appending("app/tasks/open?dayOut=")
    static let con_xac_tasks: String = baseURL.appending("app/tasks?")
    static let all_user_events: String = baseURL.appending("app/events/importantdates/current?daysOut=")
    static let notification: String = baseURL.appending("app/notifications/notification")
    static let current_notifications: String = baseURL.appending("app/notifications/current")
    static let one_notification: String = baseURL.appending("app/notifications/notification/")
    static let notification_count: String = baseURL.appending("app/notifications/unviewed/count")
    static let xaction_participants: String = baseURL.appending("app/xactionparticipants?xactionId=")
    static let xaction_participant_detail: String = baseURL.appending("app/xactionparticipants/xactionparticipant/")
    static let xaction_activitytypes: String = baseURL.appending("app/xactionactivitytypes")
    static let xactionactivity_generic_create: String = baseURL.appending("app/xactionactivities/xactionactivity")
    static let contract_dates: String = baseURL.appending("app/events?")
    
    static let website_link: String = "https://www.aframeonline.com/afs/app/Dashboard.action"
}


//Lastly, I added the parameter "groupResults" to the Tasks api endpoints. If set to true (default is false), then the Tasks will be grouped by day with the "completed" Tasks at the end of the Map list. You may or may not find this helpful, but it was easy to implement so feel free to use.
