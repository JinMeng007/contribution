//
//  API.swift
//  Uptime
//
//  Created by RSS on 6/1/18.
//  Copyright © 2018 HTK. All rights reserved.
//

import UIKit
import Alamofire

struct CustomEncoding: ParameterEncoding {
    func encode(_ urlRequest: URLRequestConvertible, with parameters: Parameters?) throws -> URLRequest {
        var request = try! URLEncoding().encode(urlRequest, with: parameters)
        let urlString = request.url?.absoluteString.replacingOccurrences(of: "%5B%5D=", with: "=")
        request.url = URL(string: urlString!)
        return request
    }
}

struct CustomPATCHEncoding: ParameterEncoding {
    func encode(_ urlRequest: URLRequestConvertible, with parameters: Parameters?) throws -> URLRequest {
        let mutableRequest = try! URLEncoding().encode(urlRequest, with: parameters) as? NSMutableURLRequest
        
        do {
            let jsonData = try JSONSerialization.data(withJSONObject: parameters!, options: .prettyPrinted)
            mutableRequest?.httpBody = jsonData
        } catch {
            print(error.localizedDescription)
        }
        
        return mutableRequest! as URLRequest
    }
}

class API: NSObject {
    class var sharedInstance: API {
        struct Static {
            static let instance: API = API()
        }
        return Static.instance
    }
    var headers = ["Content-Type": "application/json"]
    let appDelegate: AppDelegate = UIApplication.shared.delegate as! AppDelegate
    
    func api_authentication(_ username: String, _ password: String, completion: @escaping (_ errMsg: String?) -> Void) {
        let params: [String: String] = [
            "username": username,
            "password": password
        ]
        Alamofire.request(APIURL.authentication, method: .post, parameters: params, encoding: JSONEncoding.default, headers: headers).responseJSON { response in

            if response.result.isSuccess {
                let dic = response.result.value as! NSDictionary
                if dic.value(forKey: "code") != nil && dic.value(forKey: "code") as! Int == 200 {
                    self.appDelegate.saveUser()
                    User.sharedInstance.loadUserInfo(dic.value(forKeyPath: "result.appUser") as! NSDictionary)
                    User.sharedInstance.is_loggedin = true
                    completion(nil)
                }else {
                    completion(dic.value(forKey: "message") as? String)
                }
            }else {
                completion("Internet error.")
            }
        }
    }
    
    func api_xaction_participants(_ xactionId: Int, completion: @escaping (_ participants: [Participant]?) -> Void) {
        let loginStr = String(format: "%@:%@", User.sharedInstance.userName!, User.sharedInstance.password!)
        let loginData = loginStr.data(using: .utf8)
        let base64LoginStr = loginData?.base64EncodedString(options: [])
        
        let headers = ["Authorization": "Basic \(base64LoginStr ?? "")"]
        
        Alamofire.request(APIURL.xaction_participants.appending("\(xactionId)"), method: .get, parameters: nil, encoding: URLEncoding.default , headers: headers).responseJSON { (response) in
            if response.result.isSuccess {
                var participants: [Participant] = []
                let dic = response.result.value as! NSDictionary
                if dic.value(forKey: "code") as! Int == 200 {
                    let results = dic.value(forKeyPath: "result") as? NSArray
                    if results != nil {
                        for res in results! {
                            participants.append(Participant(res as! NSDictionary)!)
                        }
                    }
                    completion(participants)
                }else {
                    completion(nil)
                }
            }else {
                completion(nil)
            }
        }
    }
    
    func api_xaction_participant_detail() {
        
    }
    
    func api_contract_dates(_ suffix: String, completion: @escaping (_ contract_dates: [ContractDate]?) -> Void) {
        let loginStr = String(format: "%@:%@", User.sharedInstance.userName!, User.sharedInstance.password!)
        let loginData = loginStr.data(using: .utf8)
        let base64LoginStr = loginData?.base64EncodedString(options: [])
        
        let headers = ["Authorization": "Basic \(base64LoginStr ?? "")"]
        
        Alamofire.request(APIURL.contract_dates.appending(suffix), method: .get, parameters: nil, encoding: URLEncoding.default , headers: headers).responseJSON { (response) in
            if response.result.isSuccess {
                var contract_dates: [ContractDate] = []
                let dic = response.result.value as! NSDictionary
                if dic.value(forKey: "code") as! Int == 200 {
                    let results = dic.value(forKeyPath: "result") as? NSArray
                    if results != nil {
                        for res in results! {
                            contract_dates.append(ContractDate(res as! NSDictionary)!)
                        }
                    }
                    completion(contract_dates)
                }else {
                    completion(nil)
                }
            }else {
                completion(nil)
            }
        }
    }
    
    func api_task_detail(_ taskId: Int, completion: @escaping (_ taskDetail: TaskDetail?) -> Void) {
        let loginStr = String(format: "%@:%@", User.sharedInstance.userName!, User.sharedInstance.password!)
        let loginData = loginStr.data(using: .utf8)
        let base64LoginStr = loginData?.base64EncodedString(options: [])
        
        let headers = ["Authorization": "Basic \(base64LoginStr ?? "")"]
        
        Alamofire.request(APIURL.task.appending("\(taskId)"), method: .get, parameters: nil, encoding: URLEncoding.default , headers: headers).responseJSON { (response) in
            if response.result.isSuccess {
                let dic = response.result.value as! NSDictionary
                if dic.value(forKey: "code") as! Int == 200 {                    
                    completion(TaskDetail(dic.value(forKeyPath: "result") as! NSDictionary))
                }else {
                    completion(nil)
                }
            }else {
                completion(nil)
            }
        }
    }
    
    func api_patch_task(_ param: [String: Any], _ taskId: Int) {
        let loginStr = String(format: "%@:%@", User.sharedInstance.userName!, User.sharedInstance.password!)
        let loginData = loginStr.data(using: .utf8)
        let base64LoginStr = loginData?.base64EncodedString(options: [])
        
        let headers = ["Content-Type": "application/json", "Authorization": "Basic \(base64LoginStr ?? "")"]
        
        Alamofire.request(APIURL.task.appending("\(taskId)"), method: .patch, parameters: param, encoding: CustomPATCHEncoding() , headers: headers).responseJSON { (response) in
            if response.result.isSuccess {
                print("Successfully deleted.")
            }else {
                print("Something went wrong....")
            }
        }
    }
    
    func api_create_task(_ param: [String: Any]) {
        let loginStr = String(format: "%@:%@", User.sharedInstance.userName!, User.sharedInstance.password!)
        let loginData = loginStr.data(using: .utf8)
        let base64LoginStr = loginData?.base64EncodedString(options: [])
        
        let headers = ["Content-Type": "application/json", "Authorization": "Basic \(base64LoginStr ?? "")"]
        
        Alamofire.request(APIURL.task, method: .post, parameters: param, encoding: JSONEncoding.default , headers: headers).responseJSON { (response) in
            if response.result.isSuccess {
                print("Successfully created task.")
            }else {
                print("Something went wrong....")
            }
        }
    }
    
    func api_complete_task(_ taskId: Int) {
        let loginStr = String(format: "%@:%@", User.sharedInstance.userName!, User.sharedInstance.password!)
        let loginData = loginStr.data(using: .utf8)
        let base64LoginStr = loginData?.base64EncodedString(options: [])
        
        let headers = ["Content-Type": "application/json", "Authorization": "Basic \(base64LoginStr ?? "")"]
        
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "M/d/yyyy"
        
        let param: [String: Any] = [
            "status": "COMPLETE",
            "completeDate": dateFormatter.string(from: Date().utcToLocal(dateFormatter.dateFormat))
        ]
        
        Alamofire.request(APIURL.task.appending("\(taskId)"), method: .patch, parameters: param, encoding: CustomPATCHEncoding() , headers: headers).responseJSON { (response) in
            if response.result.isSuccess {
                print("Successfully deleted.")
            }else {
                print("Something went wrong....")
            }
        }
    }
    
    func api_snooze_task(_ task: Task) {
        let loginStr = String(format: "%@:%@", User.sharedInstance.userName!, User.sharedInstance.password!)
        let loginData = loginStr.data(using: .utf8)
        let base64LoginStr = loginData?.base64EncodedString(options: [])
        
        let headers = ["Content-Type": "application/json", "Authorization": "Basic \(base64LoginStr ?? "")"]
        
        let dateFormatter = DateFormatter()
        dateFormatter.locale = Locale(identifier: "en_US_POSIX")
        dateFormatter.dateFormat = "yyyy-MM-dd"
        let newDue = task.dueDate!.utcToLocal(dateFormatter.dateFormat)
//        let newDue = Calendar.current.date(byAdding: .day, value: 1, to: oldDue)
        dateFormatter.dateFormat = "MM/dd/yyyy"
        
        print("SENT IN API DATE --> \(newDue)")
        print("SENT IN API DATE --> \(dateFormatter.string(from: newDue))")

        let param: [String: Any] = [
            "dueDate": dateFormatter.string(from: newDue)
        ]
        
    
        Alamofire.request(APIURL.task.appending("\(task.taskId!)"), method: .patch, parameters: param, encoding: CustomPATCHEncoding() , headers: headers).responseJSON { (response) in
            if response.result.isSuccess {
                print("Successfully updated -- \(response.description)")
            }else {
                print("Something went wrong....")
            }
        }
    }
    
    func api_search(_ filter: String, completion: @escaping (_ searchResults: [SearchResult]?) -> Void) {
        let loginStr = String(format: "%@:%@", User.sharedInstance.userName!, User.sharedInstance.password!)
        let loginData = loginStr.data(using: .utf8)
        let base64LoginStr = loginData?.base64EncodedString(options: [])
        
        let headers = ["Authorization": "Basic \(base64LoginStr ?? "")"]
        
        Alamofire.request(APIURL.search.appending(filter), method: .get, parameters: nil, encoding: URLEncoding.default , headers: headers).responseJSON { (response) in
            if response.result.isSuccess {
                var searchResults: [SearchResult] = []
                let dic = response.result.value as! NSDictionary
                if dic.value(forKey: "code") as! Int == 200 {
                    let results = dic.value(forKeyPath: "result.searchResults") as? NSArray
                    if results != nil {
                        for s_res in results! {
                            searchResults.append(SearchResult(s_res as! NSDictionary)!)
                        }
                    }
                    completion(searchResults)
                }else {
                    completion(nil)
                }
            }else {
                completion(nil)
            }
        }
    }
    
    func api_contact(_ contactId: Int, completion: @escaping (_ contact_detail: ContactDetail?) -> Void) {
        let loginStr = String(format: "%@:%@", User.sharedInstance.userName!, User.sharedInstance.password!)
        let loginData = loginStr.data(using: .utf8)
        let base64LoginStr = loginData?.base64EncodedString(options: [])
        
        let headers = ["Authorization": "Basic \(base64LoginStr ?? "")"]
        
        Alamofire.request(APIURL.contact.appending("\(contactId)"), method: .get, parameters: nil, encoding: URLEncoding.default , headers: headers).responseJSON { (response) in
            if response.result.isSuccess {
                let dic = response.result.value as! NSDictionary
                if dic.value(forKey: "code") as! Int == 200 {
                    completion(ContactDetail(dic.value(forKeyPath: "result") as! NSDictionary))
                }else {
                    completion(nil)
                }
            }else {
                completion(nil)
            }
        }
    }
    
    func api_create_note(_ param: [String: Any]) {
        let loginStr = String(format: "%@:%@", User.sharedInstance.userName!, User.sharedInstance.password!)
        let loginData = loginStr.data(using: .utf8)
        let base64LoginStr = loginData?.base64EncodedString(options: [])
        
        let headers = ["Content-Type": "application/json", "Authorization": "Basic \(base64LoginStr ?? "")"]
        
        Alamofire.request(APIURL.contact_note, method: .post, parameters: param, encoding: JSONEncoding.default , headers: headers).responseJSON { (response) in
            if response.result.isSuccess {
                let dic = response.result.value as! NSDictionary
                if dic.value(forKey: "code") as! Int == 200 {
                    
                }else {
                    
                }
            }else {
                
            }
        }
    }
    
    func api_patch_note(_ param: [String: Any], _ contactNoteId: Int) {
        let loginStr = String(format: "%@:%@", User.sharedInstance.userName!, User.sharedInstance.password!)
        let loginData = loginStr.data(using: .utf8)
        let base64LoginStr = loginData?.base64EncodedString(options: [])
        
        let headers = ["Content-Type": "application/json", "Authorization": "Basic \(base64LoginStr ?? "")"]
        
        Alamofire.request(APIURL.contact_note.appending("\(contactNoteId)"), method: .patch, parameters: param, encoding: CustomPATCHEncoding() , headers: headers).responseJSON { (response) in
            if response.result.isSuccess {
                print("Successfully patched.")
            }else {
                print("Something went wrong....")
            }
        }
    }
    
    func api_delete_note(_ noteId: Int) {
        let loginStr = String(format: "%@:%@", User.sharedInstance.userName!, User.sharedInstance.password!)
        let loginData = loginStr.data(using: .utf8)
        let base64LoginStr = loginData?.base64EncodedString(options: [])
        
        let headers = ["Authorization": "Basic \(base64LoginStr ?? "")"]
        
        Alamofire.request(APIURL.contact_note.appending("\(noteId)"), method: .delete, parameters: nil, encoding: URLEncoding.default , headers: headers).responseJSON { (response) in
            if response.result.isSuccess {
                print("Successfully deleted.")
            }else {
                print("Something went wrong....")
            }
        }
    }
    
    func api_contact_notes(_ contactId: Int, completion: @escaping (_ contact_notes: [Note]?) -> Void) {
        let loginStr = String(format: "%@:%@", User.sharedInstance.userName!, User.sharedInstance.password!)
        let loginData = loginStr.data(using: .utf8)
        let base64LoginStr = loginData?.base64EncodedString(options: [])
        
        let headers = ["Authorization": "Basic \(base64LoginStr ?? "")"]
        
        Alamofire.request(APIURL.contact_notes.appending("\(contactId)"), method: .get, parameters: nil, encoding: URLEncoding.default , headers: headers).responseJSON { (response) in
            if response.result.isSuccess {
                var contact_notes: [Note] = []
                let dic = response.result.value as! NSDictionary
                if dic.value(forKey: "code") as! Int == 200 {
                    let results = dic.value(forKeyPath: "result") as? NSArray
                    if results != nil {
                        for cn_dic in results! {
                            contact_notes.append(Note(cn_dic as! NSDictionary)!)
                        }
                    }
                    completion(contact_notes)
                }else {
                    completion(nil)
                }
            }else {
                completion(nil)
            }
        }
    }
    
    func api_xaction_detail(_ xactionId: Int, completion: @escaping (_ contact_notes: TransactionDetail?) -> Void) {
        let loginStr = String(format: "%@:%@", User.sharedInstance.userName!, User.sharedInstance.password!)
        let loginData = loginStr.data(using: .utf8)
        let base64LoginStr = loginData?.base64EncodedString(options: [])
        
        let headers = ["Authorization": "Basic \(base64LoginStr ?? "")"]
        
        Alamofire.request(APIURL.xaction_detail.appending("\(xactionId)"), method: .get, parameters: nil, encoding: URLEncoding.default , headers: headers).responseJSON { (response) in
            if response.result.isSuccess {
                let dic = response.result.value as! NSDictionary
                if dic.value(forKey: "code") as! Int == 200 {
                    let result = dic.value(forKeyPath: "result") as? NSDictionary
                    completion(TransactionDetail(result!))
                }else {
                    completion(nil)
                }
            }else {
                completion(nil)
            }
        }
    }
    
    func api_get_open_xactions(_ filter: String, completion: @escaping (_ open_transactions: [Transaction]?) -> Void) {
        
        let loginStr = String(format: "%@:%@", User.sharedInstance.userName!, User.sharedInstance.password!)
        let loginData = loginStr.data(using: .utf8)
        let base64LoginStr = loginData?.base64EncodedString(options: [])
        
        let headers = ["Authorization": "Basic \(base64LoginStr ?? "")"]
        
        Alamofire.request(APIURL.get_open_xactions.appending(filter), method: .get, parameters: nil, encoding: URLEncoding.default , headers: headers).responseJSON { (response) in
            if response.result.isSuccess {
                var open_transactions: [Transaction] = []
                let dic = response.result.value as! NSDictionary
                if dic.value(forKey: "code") as! Int == 200 {
                    let results = dic.value(forKey: "result") as? NSArray
                    if results != nil {
                        for xdic in results! {
                            open_transactions.append(Transaction(xdic as! NSDictionary)!)
                        }
                    }
                    completion(open_transactions)
                }else {
                    completion(nil)
                }
            }else {
                completion(nil)
            }
        }
    }
    
    func api_get_contact_xactions(_ contactId: Int, completion: @escaping (_ contact_xactions: [Transaction]?) -> Void) {
        let loginStr = String(format: "%@:%@", User.sharedInstance.userName!, User.sharedInstance.password!)
        let loginData = loginStr.data(using: .utf8)
        let base64LoginStr = loginData?.base64EncodedString(options: [])
        
        let headers = ["Authorization": "Basic \(base64LoginStr ?? "")"]
        
        Alamofire.request(APIURL.get_contact_xactions.appending("\(contactId)"), method: .get, parameters: nil, encoding: URLEncoding.default , headers: headers).responseJSON { (response) in
            if response.result.isSuccess {
                var contact_xactions: [Transaction] = []
                let dic = response.result.value as! NSDictionary
                if dic.value(forKey: "code") as! Int == 200 {
                    let results = dic.value(forKey: "result") as? NSArray
                    if results != nil {
                        for xdic in results! {
                            contact_xactions.append(Transaction(xdic as! NSDictionary)!)
                        }
                    }
                    completion(contact_xactions)
                }else {
                    completion(nil)
                }
            }else {
                completion(nil)
            }
        }
    }
    
    func api_xactionactivity_generic_detail(_ xactionGenericId: Int, completion: @escaping (_ xaction_generic: XAGDetail?) -> Void) {
        let loginStr = String(format: "%@:%@", User.sharedInstance.userName!, User.sharedInstance.password!)
        let loginData = loginStr.data(using: .utf8)
        let base64LoginStr = loginData?.base64EncodedString(options: [])
        
        let headers = ["Authorization": "Basic \(base64LoginStr ?? "")"]
        
        Alamofire.request(APIURL.xactionactivity_generic.appending("\(xactionGenericId)"), method: .get, parameters: nil, encoding: URLEncoding.default , headers: headers).responseJSON { (response) in
            if response.result.isSuccess {
                let dic = response.result.value as! NSDictionary
                if dic.value(forKey: "code") as! Int == 200 {
                    completion(XAGDetail(dic.value(forKey: "result") as! NSDictionary))
                }else {
                    completion(nil)
                }
            }else {
                completion(nil)
            }
        }
    }
    
    func api_xactionactivity_generic_patch(_ xactionActivityId: Int, _ param: [String: Any]) {
        let loginStr = String(format: "%@:%@", User.sharedInstance.userName!, User.sharedInstance.password!)
        let loginData = loginStr.data(using: .utf8)
        let base64LoginStr = loginData?.base64EncodedString(options: [])
        
        let headers = ["Content-Type": "application/json", "Authorization": "Basic \(base64LoginStr ?? "")"]
        
        Alamofire.request(APIURL.xactionactivity_generic.appending("\(xactionActivityId)"), method: .patch, parameters: param, encoding: CustomPATCHEncoding() , headers: headers).responseJSON { (response) in
            if response.result.isSuccess {
                
            }else {
                
            }
        }
    }
    
    func api_xactionactivity_import_detail(_ xactionImportId: Int, completion: @escaping (_ xaction_import: XAIDetail?) -> Void) {
        let loginStr = String(format: "%@:%@", User.sharedInstance.userName!, User.sharedInstance.password!)
        let loginData = loginStr.data(using: .utf8)
        let base64LoginStr = loginData?.base64EncodedString(options: [])
        
        let headers = ["Authorization": "Basic \(base64LoginStr ?? "")"]
        
        Alamofire.request(APIURL.xactionactivity_import.appending("\(xactionImportId)"), method: .get, parameters: nil, encoding: URLEncoding.default , headers: headers).responseJSON { (response) in
            if response.result.isSuccess {
                let dic = response.result.value as! NSDictionary
                if dic.value(forKey: "code") as! Int == 200 {
                    completion(XAIDetail(dic.value(forKey: "result") as! NSDictionary))
                }else {
                    completion(nil)
                }
            }else {
                completion(nil)
            }
        }
    }
    
    func api_xactionactivity_import_patch(_ xactionActivityId: Int, _ param: [String: Any]) {
        let loginStr = String(format: "%@:%@", User.sharedInstance.userName!, User.sharedInstance.password!)
        let loginData = loginStr.data(using: .utf8)
        let base64LoginStr = loginData?.base64EncodedString(options: [])
        
        let headers = ["Content-Type": "application/json", "Authorization": "Basic \(base64LoginStr ?? "")"]
        
        Alamofire.request(APIURL.xactionactivity_import.appending("\(xactionActivityId)"), method: .patch, parameters: param, encoding: CustomPATCHEncoding() , headers: headers).responseJSON { (response) in
            if response.result.isSuccess {
                
            }else {
                
            }
        }
    }
    
    func api_xaction_attach_patch(_ xactionAttachId: Int, _ param: [String: Any]) {
        let loginStr = String(format: "%@:%@", User.sharedInstance.userName!, User.sharedInstance.password!)
        let loginData = loginStr.data(using: .utf8)
        let base64LoginStr = loginData?.base64EncodedString(options: [])
        
        let headers = ["Content-Type": "application/json", "Authorization": "Basic \(base64LoginStr ?? "")"]
        
        Alamofire.request(APIURL.xaction_attatchment.appending("\(xactionAttachId)"), method: .patch, parameters: param, encoding: CustomPATCHEncoding() , headers: headers).responseJSON { (response) in
            if response.result.isSuccess {
                
            }else {
                
            }
        }
    }
    
    func api_xaction_activities(_ xactionId: Int, completion: @escaping (_ xaction_activities: [TransactionActivity]?) -> Void) {
        
        let loginStr = String(format: "%@:%@", User.sharedInstance.userName!, User.sharedInstance.password!)
        let loginData = loginStr.data(using: .utf8)
        let base64LoginStr = loginData?.base64EncodedString(options: [])
        
        let headers = ["Authorization": "Basic \(base64LoginStr ?? "")"]
        
        Alamofire.request(APIURL.xaction_activities.appending("\(xactionId)"), method: .get, parameters: nil, encoding: URLEncoding.default , headers: headers).responseJSON { (response) in
            if response.result.isSuccess {
                var xaction_activities: [TransactionActivity] = []
                let dic = response.result.value as! NSDictionary
                if dic.value(forKey: "code") as! Int == 200 {
                    let results = dic.value(forKey: "result") as? NSArray
                    if results != nil {
                        for xdic in results! {
                            xaction_activities.append(TransactionActivity(xdic as! NSDictionary)!)
                        }
                    }
                    completion(xaction_activities)
                }else {
                    completion(nil)
                }
            }else {
                completion(nil)
            }
        }
    }
    
    func api_xaction_attatchments(_ xactionId: Int, completion: @escaping (_ xaction_attachments: [XActionAttachment]?) -> Void) {
        let loginStr = String(format: "%@:%@", User.sharedInstance.userName!, User.sharedInstance.password!)
        let loginData = loginStr.data(using: .utf8)
        let base64LoginStr = loginData?.base64EncodedString(options: [])
        
        let headers = ["Authorization": "Basic \(base64LoginStr ?? "")"]
        
        Alamofire.request(APIURL.xaction_attatchments.appending("\(xactionId)"), method: .get, parameters: nil, encoding: URLEncoding.default , headers: headers).responseJSON { (response) in
            if response.result.isSuccess {
                var xaction_attachments: [XActionAttachment] = []
                let dic = response.result.value as! NSDictionary
                if dic.value(forKey: "code") as! Int == 200 {
                    let results = dic.value(forKey: "result") as? NSArray
                    if results != nil {
                        for xdic in results! {
                            xaction_attachments.append(XActionAttachment(xdic as! NSDictionary)!)
                        }
                    }
                    completion(xaction_attachments)
                }else {
                    completion(nil)
                }
            }else {
                completion(nil)
            }
        }
    }
    
    func api_contact_tasks(_ suffix: String, completion: @escaping (_ contact_tasks: [Task]?) -> Void) {
        let loginStr = String(format: "%@:%@", User.sharedInstance.userName!, User.sharedInstance.password!)
        let loginData = loginStr.data(using: .utf8)
        let base64LoginStr = loginData?.base64EncodedString(options: [])
        
        let headers = ["Authorization": "Basic \(base64LoginStr ?? "")"]
        
        Alamofire.request(APIURL.con_xac_tasks.appending(suffix), method: .get, parameters: nil, encoding: URLEncoding.default , headers: headers).responseJSON { (response) in
            if response.result.isSuccess {
                var contact_tasks: [Task] = []
                let dic = response.result.value as! NSDictionary
                if dic.value(forKey: "code") as! Int == 200 {
                    let results = dic.value(forKey: "result") as? NSArray
                    if results != nil {
                        for task_dic in results! {
                            contact_tasks.append(Task(task_dic as! NSDictionary)!)
                        }
                    }
                    contact_tasks = contact_tasks.sorted(by: { (task1, task2) -> Bool in
                        let dateFormatter = DateFormatter()
                        dateFormatter.dateFormat = "yyyy-MM-dd"
                        let date1 = dateFormatter.date(from: task1.dueDate!)
                        let date2 = dateFormatter.date(from: task2.dueDate!)
                        return date1?.compare(date2!) == .orderedAscending ? true : false
                    })
                    completion(contact_tasks)
                }else {
                    completion(nil)
                }
            }else {
                completion(nil)
            }
        }
    }
    
    func api_open_tasks(_ daysOut: Int, completion: @escaping (_ open_tasks: [Task]?) -> Void) {
        let loginStr = String(format: "%@:%@", User.sharedInstance.userName!, User.sharedInstance.password!)
        let loginData = loginStr.data(using: .utf8)
        let base64LoginStr = loginData?.base64EncodedString(options: [])
        
        let headers = ["Authorization": "Basic \(base64LoginStr ?? "")"]
        
        Alamofire.request(APIURL.open_tasks.appending("\(daysOut)"), method: .get, parameters: nil, encoding: URLEncoding.default , headers: headers).responseJSON { (response) in
            if response.result.isSuccess {
                var open_tasks: [Task] = []
                let dic = response.result.value as! NSDictionary
                if dic.value(forKey: "code") as! Int == 200 {
                    let results = dic.value(forKey: "result") as? NSArray
                    if results != nil {
                        for task_dic in results! {
                            open_tasks.append(Task(task_dic as! NSDictionary)!)
                        }
                    }
                    open_tasks = open_tasks.sorted(by: { (task1, task2) -> Bool in
                        let dateFormatter = DateFormatter()
                        dateFormatter.dateFormat = "yyyy-MM-dd"
                        let date1 = dateFormatter.date(from: task1.dueDate!)
                        let date2 = dateFormatter.date(from: task2.dueDate!)
                        return date1?.compare(date2!) == .orderedAscending ? true : false
                    })
                    completion(open_tasks)
                }else {
                    completion(nil)
                }
            }else {
                completion(nil)
            }
        }
    }
    
    func api_all_user_events(_ daysOut: Int, completion: @escaping (_ events: [Event]?) -> Void) {
        let loginStr = String(format: "%@:%@", User.sharedInstance.userName!, User.sharedInstance.password!)
        let loginData = loginStr.data(using: .utf8)
        let base64LoginStr = loginData?.base64EncodedString(options: [])
        
        let headers = ["Authorization": "Basic \(base64LoginStr ?? "")"]
        
        Alamofire.request(APIURL.all_user_events.appending("\(daysOut)"), method: .get, parameters: nil, encoding: URLEncoding.default , headers: headers).responseJSON { (response) in
            if response.result.isSuccess {
                var events: [Event] = []
                let dic = response.result.value as! NSDictionary
                if dic.value(forKey: "code") as! Int == 200 {
                    let results = dic.value(forKey: "result") as? NSArray
                    if results != nil {
                        for event_dic in results! {
                            events.append(Event(event_dic as! NSDictionary)!)
                        }
                    }
                    completion(events)
                }else {
                    completion(nil)
                }
            }else {
                completion(nil)
            }
        }
    }
    
    func api_current_notifications(completion: @escaping (_ current_notifications: [AFNotification]?) -> Void) {
        let loginStr = String(format: "%@:%@", User.sharedInstance.userName!, User.sharedInstance.password!)
        let loginData = loginStr.data(using: .utf8)
        let base64LoginStr = loginData?.base64EncodedString(options: [])
        
        let headers = ["Authorization": "Basic \(base64LoginStr ?? "")"]
        
        Alamofire.request(APIURL.current_notifications, method: .get, parameters: nil, encoding: URLEncoding.default , headers: headers).responseJSON { (response) in
            if response.result.isSuccess {
                var current_notifications: [AFNotification] = []
                let dic = response.result.value as! NSDictionary
                if dic.value(forKey: "code") as! Int == 200 {
                    let results = dic.value(forKey: "result") as? NSArray
                    if results != nil {
                        for notification_dic in results! {
                            current_notifications.append(AFNotification(notification_dic as! NSDictionary)!)
                        }
                    }
                    completion(current_notifications)
                }else {
                    completion(nil)
                }
            }else {
                completion(nil)
            }
        }
    }
    
    func api_delete_notification(_ notificationId: Int) {
        let loginStr = String(format: "%@:%@", User.sharedInstance.userName!, User.sharedInstance.password!)
        let loginData = loginStr.data(using: .utf8)
        let base64LoginStr = loginData?.base64EncodedString(options: [])
        
        let headers = ["Authorization": "Basic \(base64LoginStr ?? "")"]
        
        Alamofire.request(APIURL.one_notification.appending("\(notificationId)"), method: .delete, parameters: nil, encoding: URLEncoding.default , headers: headers).responseJSON { (response) in
            NotificationCenter.default.post(name: Notification.Name.init("SetBadge"), object: nil, userInfo: nil)
            if response.result.isSuccess {
                print("Successfully deleted.")
            }else {
                print("Something went wrong....")
            }
        }
    }
    
    func api_mark_all_read() {
        let loginStr = String(format: "%@:%@", User.sharedInstance.userName!, User.sharedInstance.password!)
        let loginData = loginStr.data(using: .utf8)
        let base64LoginStr = loginData?.base64EncodedString(options: [])
        
        let headers = ["Content-Type": "application/json", "Authorization": "Basic \(base64LoginStr ?? "")"]
        
        let param: [String: Any] = [
            "hasBeenViewed": true,
            "hasBeenRead": true
        ]
        
        Alamofire.request(APIURL.current_notifications, method: .patch, parameters: param, encoding: CustomPATCHEncoding() , headers: headers).responseJSON { (response) in
            NotificationCenter.default.post(name: Notification.Name.init("SetBadge"), object: nil, userInfo: nil)
            if response.result.isSuccess {
                print("Successfully patched.")
            }else {
                print("Something went wrong....")
            }
        }
    }
    
    func api_mark_read(_ notificationId: Int) {
        let loginStr = String(format: "%@:%@", User.sharedInstance.userName!, User.sharedInstance.password!)
        let loginData = loginStr.data(using: .utf8)
        let base64LoginStr = loginData?.base64EncodedString(options: [])
        
        let headers = ["Content-Type": "application/json", "Authorization": "Basic \(base64LoginStr ?? "")"]

        let param: [String: Any] = [
            "hasBeenViewed": true,
            "hasBeenRead": true
        ]

        Alamofire.request(APIURL.one_notification.appending("\(notificationId)"), method: .patch, parameters: param, encoding: CustomPATCHEncoding() , headers: headers).responseJSON { (response) in
            NotificationCenter.default.post(name: Notification.Name.init("SetBadge"), object: nil, userInfo: nil)
            if response.result.isSuccess {
                print("Successfully patched.")
            }else {
                print("Something went wrong....")
            }
        }
    }
    
    func api_notification_count(completion: @escaping (_ unviewed_notifications: Int) -> Void) {
        let loginStr = String(format: "%@:%@", User.sharedInstance.userName!, User.sharedInstance.password!)
        let loginData = loginStr.data(using: .utf8)
        let base64LoginStr = loginData?.base64EncodedString(options: [])
        
        let headers = ["Authorization": "Basic \(base64LoginStr ?? "")"]
        
        Alamofire.request(APIURL.notification_count, method: .get, parameters: nil, encoding: URLEncoding.default , headers: headers).responseJSON { (response) in
            if response.result.isSuccess {
                let dic = response.result.value as! NSDictionary
                if dic.value(forKey: "code") as! Int == 200 {
                    completion(dic.value(forKey: "result") as! Int)
                }else {
                    completion(0)
                }
            }else {
                completion(0)
            }
        }
    }
    
    func api_current_login_users(completion: @escaping (_ current_user: Contact?) -> Void) {
        let loginStr = String(format: "%@:%@", User.sharedInstance.userName!, User.sharedInstance.password!)
        let loginData = loginStr.data(using: .utf8)
        let base64LoginStr = loginData?.base64EncodedString(options: [])
        
        let headers = ["Authorization": "Basic \(base64LoginStr ?? "")"]
        
        Alamofire.request(APIURL.current_login_users, method: .get, parameters: nil, encoding: URLEncoding.default , headers: headers).responseJSON { (response) in
            if response.result.isSuccess {
                let dic = response.result.value as! NSDictionary
                if dic.value(forKey: "code") as! Int == 200 {
                    
                }else {
                    completion(nil)
                }
            }else {
                completion(nil)
            }
        }
    }
    
    func api_active_app_users(_ appUserId: Int, completion: @escaping (_ active_users: [AppUser]?) -> Void) {
        let loginStr = String(format: "%@:%@", User.sharedInstance.userName!, User.sharedInstance.password!)
        let loginData = loginStr.data(using: .utf8)
        let base64LoginStr = loginData?.base64EncodedString(options: [])
        
        let headers = ["Authorization": "Basic \(base64LoginStr ?? "")"]
        
        Alamofire.request(APIURL.active_app_users.appending("\(appUserId)"), method: .get, parameters: nil, encoding: URLEncoding.default , headers: headers).responseJSON { (response) in
            if response.result.isSuccess {
                var active_users: [AppUser] = []
                let dic = response.result.value as! NSDictionary
                if dic.value(forKey: "code") as! Int == 200 {
                    let results = dic.value(forKeyPath: "result") as? NSArray
                    for item in results! {
                        active_users.append(AppUser(item as! NSDictionary)!)
                    }
                    completion(active_users)
                }else {
                    completion(nil)
                }
            }else {
                completion(nil)
            }
        }
    }
    
    func api_xaction_activitytypes(completion: @escaping (_ types: [XactionActivityType]?) -> Void) {
        let loginStr = String(format: "%@:%@", User.sharedInstance.userName!, User.sharedInstance.password!)
        let loginData = loginStr.data(using: .utf8)
        let base64LoginStr = loginData?.base64EncodedString(options: [])
        
        let headers = ["Authorization": "Basic \(base64LoginStr ?? "")"]
        
        Alamofire.request(APIURL.xaction_activitytypes, method: .get, parameters: nil, encoding: URLEncoding.default , headers: headers).responseJSON { (response) in
            if response.result.isSuccess {
                var types: [XactionActivityType] = []
                let dic = response.result.value as! NSDictionary
                if dic.value(forKey: "code") as! Int == 200 {
                    let results = dic.value(forKeyPath: "result") as? NSArray
                    for item in results! {
                        types.append(XactionActivityType(item as! NSDictionary)!)
                    }
                    completion(types)
                }else {
                    completion(nil)
                }
            }else {
                completion(nil)
            }
        }
    }
    
    func api_xactionactivity_generic_create(_ param: [String: Any]) {
        let loginStr = String(format: "%@:%@", User.sharedInstance.userName!, User.sharedInstance.password!)
        let loginData = loginStr.data(using: .utf8)
        let base64LoginStr = loginData?.base64EncodedString(options: [])
        
        let headers = ["Content-Type": "application/json", "Authorization": "Basic \(base64LoginStr ?? "")"]
        
        Alamofire.request(APIURL.xactionactivity_generic_create, method: .post, parameters: param, encoding: JSONEncoding.default , headers: headers).responseJSON { (response) in
            if response.result.isSuccess {
                let dic = response.result.value as! NSDictionary
                if dic.value(forKey: "code") as! Int == 200 {
                    
                }else {
                    
                }
            }else {
                
            }
        }
    }
    
}
