//
//  GlobalConstantClass.swift
//  Tucontenido
//
//  Created by RSS on 14/11/2017.
//  Copyright © 2017 HTK. All rights reserved.
//

import UIKit
import AVFoundation
import Contacts
import ContactsUI
import SwiftPhoneNumberFormatter

let sd_imageCache = SDImageCache(namespace: "ImageDownloadCache")
let imageCache = NSCache<AnyObject, AnyObject>()

extension UIImageView{
    
    func loadImageWithDefaultImage(urlString  : String) {
        
        if sd_imageCache.getSize() > 102400 {
            sd_imageCache.clearMemory()
            sd_imageCache.clearDisk(onCompletion: {
                
            })
        }
        sd_imageCache.queryCacheOperation(forKey: urlString, done: { (image, data, cache) in
            if image != nil {
                DispatchQueue.main.async {
                    self.image = image
                }
            }else {
                self.sd_setImage(with: URL(string: urlString), placeholderImage: UIImage(named: "background.png"), options: .continueInBackground, progress: nil) { (image, error, cache, url) in
                    DispatchQueue.main.async {
                        sd_imageCache.store(image, forKey: urlString, toDisk: true, completion: nil)
                        self.image = image
                    }
                }
            }
        })
    }
    
    func addBlurEffect(_ viewController: UIViewController) {
        /// Create Effect
        let blur = UIBlurEffect(style: .regular)
        
        /// Add Effect to an effect View
        let effectView = UIVisualEffectView(effect: blur)
        effectView.frame = viewController.view.frame
        
        /// Add the effect to the image view
        self.addSubview(effectView)
    }
}


extension UIImage {
    func resizeImage(targetSize: CGSize) -> UIImage {
        let size = self.size
        
        let widthRatio  = targetSize.width  / self.size.width
        let heightRatio = targetSize.height / self.size.height
        
        // Figure out what our orientation is, and use that to form the rectangle
        var newSize: CGSize
        if(widthRatio > heightRatio) {
            newSize = CGSize(width: size.width * heightRatio, height: size.height * heightRatio)
        } else {
            newSize = CGSize(width: size.width * widthRatio,  height: size.height * widthRatio)
        }
        
        // This is the rect that we've calculated out and this is what is actually used below
        let rect = CGRect(x: 0, y: 0, width: newSize.width, height: newSize.height)
        
        // Actually do the resizing to the rect using the ImageContext stuff
        UIGraphicsBeginImageContextWithOptions(newSize, false, 1.0)
        self.draw(in: rect)
        let newImage = UIGraphicsGetImageFromCurrentImageContext()
        UIGraphicsEndImageContext()
        
        return newImage!
        
    }
}

extension CMTime {
    var durationText: String {
        let totalSeconds = CMTimeGetSeconds(self)
        let hours: Int = Int(totalSeconds / 3600)
        let minutes: Int = Int(totalSeconds.truncatingRemainder(dividingBy: 3600) / 60)
        let seconds: Int = Int(totalSeconds.truncatingRemainder(dividingBy: 60))
        return String(format: "%02i:%02i:%02i", hours, minutes, seconds)
    }
}

extension String {
    func getColor() -> UIColor {
        let hexString: String = self.trimmingCharacters(in: CharacterSet.whitespacesAndNewlines)
        let scanner = Scanner(string: hexString)
        if (hexString.hasPrefix("#")) {
            scanner.scanLocation = 1
        }
        var color: UInt32 = 0
        scanner.scanHexInt32(&color)
        let mask = 0x000000FF
        let r = Int(color >> 16) & mask
        let g = Int(color >> 8) & mask
        let b = Int(color) & mask
        let red   = CGFloat(r) / 255.0
        let green = CGFloat(g) / 255.0
        let blue  = CGFloat(b) / 255.0
        return UIColor(red: red, green: green, blue: blue, alpha: 1.0)
    }
    
    func getPhoneType() -> String {
        switch self {
        case "Home":
            return CNLabelHome
        case "Cell" :
            return CNLabelPhoneNumberMobile
        case "iPhone" :
            return CNLabelPhoneNumberiPhone
        case "Work":
            return CNLabelWork
        case "Mobile":
            return CNLabelPhoneNumberMobile
        default:
            return CNLabelOther
        }
    }
    
    func formattedNumber(_ phoneType: String) -> String? {
        var formatter: String = "(###) ### ####"
        switch phoneType {
        case "Home":
            formatter = "(##) #### ####"
            break
        case "Other":
            formatter = "(##) #### ####"
            break
        case "Work":
            formatter = "##########"
            break
        default:
            break
        }
        let phoneFormatter = TextFormatter(textPattern: formatter)
        return phoneFormatter.formattedText(from: self)
    }
}

extension TimeInterval {
    var durationText: String {
        let totalSeconds = Float(self)
        let hours: Int = Int(totalSeconds / 3600)
        let minutes: Int = Int(totalSeconds.truncatingRemainder(dividingBy: 3600) / 60)
        let seconds: Int = Int(totalSeconds.truncatingRemainder(dividingBy: 60))
        return String(format: "%02i:%02i:%02i", hours, minutes, seconds)
    }
}

extension UILabel {
    func setAttrTxt(_ str: String) {
        let paragraphStyle = NSMutableParagraphStyle()
        paragraphStyle.lineSpacing = 5
        paragraphStyle.lineBreakMode = .byTruncatingTail
        let attrStr = NSMutableAttributedString(string: str)
        attrStr.addAttribute(.paragraphStyle, value: paragraphStyle, range: NSMakeRange(0, attrStr.length))
        self.attributedText = attrStr
    }
}

extension UIButton {
    
    func rotate(_ angle: CGFloat) {
        let radians = angle / 180 * CGFloat.pi
        let rotation = CGAffineTransform(rotationAngle: radians)
        self.transform = rotation
    }
    
    func drawBottom() {
        let view = UIView(frame: CGRect(x: 0, y: self.frame.height - 2, width: self.frame.width, height: 2))
        view.backgroundColor = UIColor.black
        view.tag = 1000
        self.addSubview(view)
    }
    func removeBottom() {
        self.subviews.forEach { (view) in
            if view.tag == 1000 {
                view.removeFromSuperview()
            }
        }
    }
    
    func loadImageWithDefaultImage(urlString  : String) {
        if sd_imageCache.getSize() > 102400 {
            sd_imageCache.clearMemory()
            sd_imageCache.clearDisk(onCompletion: {
                
            })
        }
        sd_imageCache.queryCacheOperation(forKey: urlString, done: { (image, data, cache) in
            if image != nil {
                DispatchQueue.main.async {
                    self.setImage(image, for: .normal)
                }
            }else {
                self.sd_setImage(with: URL(string: urlString), for: .normal, placeholderImage: UIImage(named: "background.png"), options: .progressiveDownload) { (image, error, cache, url) in
                    DispatchQueue.main.async {
                        sd_imageCache.store(image, forKey: urlString, toDisk: true, completion: nil)
                        self.setImage(image, for: .normal)
                    }
                }
            }
        })
    }
}

extension UIView {
    func fadeIn(completion: @escaping (_ success: Bool?) -> Void) {
        self.transform = CGAffineTransform(scaleX: 0.7, y: 0.7)
        self.alpha = 0.0
        UIView.animate(withDuration: 0.25, animations: {
            self.alpha = 1.0
            self.transform = CGAffineTransform(scaleX: 1.0, y: 1.0)
        }, completion:{(finished : Bool)  in
            completion(finished)

        })
    }
    
    func fadeOut(completion: @escaping (_ success: Bool?) -> Void) {
        UIView.animate(withDuration: 0.25, animations: {
            self.transform = CGAffineTransform(scaleX: 1.3, y: 1.3)
            self.alpha = 0.0;
        }, completion:{(finished : Bool)  in
            completion(finished)

        })
    }
    
    func findViewController() -> UIViewController? {
        if let nextResponder = self.next as? UIViewController {
            return nextResponder
        } else if let nextResponder = self.next as? UIView {
            return nextResponder.findViewController()
        } else {
            return nil
        }
    }
    
    func makeToDuel() {
        self.clipsToBounds = true
        self.layer.cornerRadius = 8.0
        self.layer.borderColor = UIColor(red: 230 / 255, green: 45 / 255, blue: 110 / 255, alpha: 1.0).cgColor
        self.layer.borderWidth = 1.0
        
        self.layer.masksToBounds = false
        self.layer.shadowColor = UIColor(red: 230 / 255, green: 45 / 255, blue: 110 / 255, alpha: 1.0).cgColor
        self.layer.shadowOpacity = 0.3
        self.layer.shadowRadius = 5.0
        self.layer.shadowOffset = CGSize.zero
        self.layer.shadowPath = UIBezierPath(rect: self.layer.bounds).cgPath
        self.layer.shouldRasterize = true
        self.layer.rasterizationScale = true ? UIScreen.main.scale : 1
    }
}

extension Notification.Name {
    static let notifyChat = Notification.Name("notifyChat")
    static let countryCodeAdded = Notification.Name("countryCodeAdded")
    static let booking_Update = Notification.Name("booking_Update")
}

extension Int {
    var ordinal: String {
        get {
            var suffix = "th"
            switch self % 10 {
            case 1:
                suffix = "st"
            case 2:
                suffix = "nd"
            case 3:
                suffix = "rd"
            default: ()
            }
            if 10 < (self % 100) && (self % 100) < 20 {
                suffix = "th"
            }
            return String(self) + suffix
        }
    }
    func getCurrency() -> String? {
        let formatter = NumberFormatter()
        formatter.numberStyle = .currency
        formatter.currencyCode = "USD"
        formatter.currencySymbol = "$"
        formatter.minimumFractionDigits = 0
        formatter.maximumFractionDigits = 0
        return formatter.string(from: NSNumber(value: self))
    }
}

extension UITextField {
    
    func isValidEmail() -> Bool {
        // print("validate calendar: \(testStr)")
        let emailRegEx = "[A-Z0-9a-z._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,64}"
        
        let emailTest = NSPredicate(format:"SELF MATCHES %@", emailRegEx)
        return emailTest.evaluate(with: self.text)
    }
}

extension Date {
    func startOfMonth() -> Date {
        return Calendar.current.date(from: Calendar.current.dateComponents([.year, .month], from: Calendar.current.startOfDay(for: self)))!
    }
    
    func endOfMonth() -> Date {
        return Calendar.current.date(byAdding: DateComponents(month: 1, day: 0), to: self.startOfMonth())!
    }
    
    func utcToLocal(_ formatter: String) -> Date {
        let dateFormatter: DateFormatter = DateFormatter()
        dateFormatter.locale = Locale(identifier: "en_US_POSIX")
        dateFormatter.dateFormat = formatter
        dateFormatter.timeZone = TimeZone.current
        
        let str = dateFormatter.string(from: self)
//        dateFormatter.timeZone = TimeZone(abbreviation: "UTC")
        
        return dateFormatter.date(from: str)!
    }
}

extension String {
    
    func monthFullWord() -> String {
        switch self {
        case "Jan":
            return "JANUARY"
        case "Feb":
            return "FEBRUARY"
        case "Mar":
            return "MARCH"
        case "Apr":
            return "APRIL"
        case "May":
            return "MAY"
        case "Jun":
            return "JUNE"
        case "Jul":
            return "JULY"
        case "Aug":
            return "AUGUST"
        case "Sep":
            return "SEPTEMBER"
        case "Oct":
            return "OCTOBER"
        case "Nov":
            return "NOVEMBER"
        default:
            return "Dec"
        }
    }
    
    func utcToLocal(_ formatter: String) -> Date {
        let dateFormatter: DateFormatter = DateFormatter()
        dateFormatter.dateFormat = formatter
        dateFormatter.timeZone = TimeZone.current
//        dateFormatter.timeZone = TimeZone(abbreviation: "UTC")
        dateFormatter.locale = Locale(identifier: "en_US_POSIX")

        return dateFormatter.date(from: self)!
    }
    func heightForView(_ font:UIFont, _ width:CGFloat) -> CGFloat{
        let label:UILabel = UILabel(frame: CGRect(x: 0, y: 0, width: width, height: CGFloat.greatestFiniteMagnitude))
        label.numberOfLines = 0
        label.lineBreakMode = NSLineBreakMode.byTruncatingTail
        label.font = font
        label.text = self
        
        label.sizeToFit()
        return label.frame.height
    }
    
    func widthOfLabel(withConstrainedHeight height: CGFloat, font: UIFont) -> CGFloat {
        let constraintRect = CGSize(width: .greatestFiniteMagnitude, height: height)
        let boundingBox = self.boundingRect(with: constraintRect, options: .usesLineFragmentOrigin, attributes: [NSAttributedString.Key.font: font], context: nil)
        return CGFloat(ceil(boundingBox.width))
    }
    func getFontIcon() -> String {
        switch self {
        case "TODO":
            return AppIcons.todo.rawValue
        case "LETTER":
            return AppIcons.letter.rawValue
        case "EMAIL":
            return AppIcons.email.rawValue
        case "CALL":
            return AppIcons.phone.rawValue
        case "PHONE":
            return AppIcons.phone.rawValue
        case "Todo":
            return AppIcons.todo.rawValue
        case "To Do":
            return AppIcons.todo.rawValue
        case "Letter":
            return AppIcons.letter.rawValue
        case "Email":
            return AppIcons.email.rawValue
        case "Call":
            return AppIcons.phone.rawValue
        case "Phone":
            return AppIcons.phone.rawValue
        case "CONTACT_BIRTHDAY":
            return AppIcons.dob.rawValue
        case "CONTACT_BIRTHDAY_SPOUSE":
            return AppIcons.dob.rawValue
        case "CONTACT_ANNIVERSARY":
            return AppIcons.calendar.rawValue
        case "XACTION_EXPIRE_DATE":
            return AppIcons.home.rawValue
        case "XACTION_CLOSING_DATE":
            return AppIcons.home.rawValue
        case "XACTION_ANNIVERSARY":
            return AppIcons.calendar.rawValue
        case "EVENT_REMINDER":
            return AppIcons.calendar.rawValue
        case "TASK_REMINDER":
            return AppIcons.task.rawValue
        case "TASK_COMPLETED":
            return AppIcons.task.rawValue
        case "CUSTOM":
            return AppIcons.calendar.rawValue
        case "NOTE":
            return AppIcons.comment.rawValue
        case "Note":
            return AppIcons.list.rawValue
        case "Showing":
            return AppIcons.btm_line_box.rawValue
        case "Price Change":
            return AppIcons.dollar.rawValue
        default:
            return AppIcons.comment.rawValue
        }
    }
    
    func onlyDigits() -> String {
        let filtredUnicodeScalars = unicodeScalars.filter{CharacterSet.decimalDigits.contains($0)}
        return String(String.UnicodeScalarView(filtredUnicodeScalars))
    }
}

extension UITextView: UITextViewDelegate {
    
    /// Resize the placeholder when the UITextView bounds change
    override open var bounds: CGRect {
        didSet {
            self.resizePlaceholder()
        }
    }
    
    /// The UITextView placeholder text
    public var placeholder: String? {
        get {
            var placeholderText: String?
            
            if let placeholderLabel = self.viewWithTag(100) as? UILabel {
                placeholderText = placeholderLabel.text
            }
            
            return placeholderText
        }
        set {
            if let placeholderLabel = self.viewWithTag(100) as! UILabel? {
                placeholderLabel.text = newValue
                placeholderLabel.sizeToFit()
            } else {
                self.addPlaceholder(newValue!)
            }
        }
    }
    
    /// When the UITextView did change, show or hide the label based on if the UITextView is empty or not
    ///
    /// - Parameter textView: The UITextView that got updated
    public func textViewDidChange(_ textView: UITextView) {
        if let placeholderLabel = self.viewWithTag(100) as? UILabel {
            placeholderLabel.isHidden = self.text.count > 0
        }
    }
    
    /// Resize the placeholder UILabel to make sure it's in the same position as the UITextView text
    private func resizePlaceholder() {
        if let placeholderLabel = self.viewWithTag(100) as! UILabel? {
            let labelX = self.textContainer.lineFragmentPadding
            let labelY = self.textContainerInset.top - 2
            let labelWidth = self.frame.width - (labelX * 2)
            let labelHeight = placeholderLabel.frame.height
            
            placeholderLabel.frame = CGRect(x: labelX, y: labelY, width: labelWidth, height: labelHeight)
        }
    }
    
    /// Adds a placeholder UILabel to this UITextView
    private func addPlaceholder(_ placeholderText: String) {
        let placeholderLabel = UILabel()
        
        placeholderLabel.text = placeholderText
        placeholderLabel.sizeToFit()
        
        placeholderLabel.font = self.font
        placeholderLabel.textColor = UIColor.lightGray
        placeholderLabel.tag = 100
        
        placeholderLabel.isHidden = self.text.count > 0
        
        self.addSubview(placeholderLabel)
        self.resizePlaceholder()
        self.delegate = self
    }
    
}
