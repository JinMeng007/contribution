//
//  UIViewControllerExtension.swift
//  AFrame
//
//  Created by Lee Sheng Jin on 2019/6/23.
//  Copyright © 2019 DrawRanger. All rights reserved.
//

import UIKit

extension UIViewController {
    func alertViewController(title: String?, message: String?){
        guard presentedViewController == nil else {
            print("Already Presenting View Controller")
            return
        }
        let alertController = UIAlertController(title: title, message: message, preferredStyle: .alert)
        let alertAction: UIAlertAction = UIAlertAction(title: "OK", style: .default, handler: nil)
        alertController.addAction(alertAction)
        present(alertController, animated: true, completion: nil)
    }
    
    func clipboardAlert(title: String?, message: String?){
        guard presentedViewController == nil else {
            print("Already Presenting View Controller")
            return
        }
        let alertController = UIAlertController(title: title, message: message, preferredStyle: .alert)
        let alertAction: UIAlertAction = UIAlertAction(title: "Copy", style: .default) { (action) in
            UIPasteboard.general.string = message
        }
        alertController.addAction(alertAction)
        present(alertController, animated: true, completion: nil)
    }
}
