//
//  LocationSearchViewCell.swift
//  RocketRides
//
//  Created by Romain Huet on 5/26/16.
//  Copyright © 2016 Romain Huet. All rights reserved.
//

import UIKit

class LocationSearchViewCell: UITableViewCell {

    @IBOutlet var nameLabel: UILabel!
    @IBOutlet var localityLabel: UILabel!

}
