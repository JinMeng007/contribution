//
//  API.swift
//  Fido Finder
//
//  Created by MaskX on 2/24/19.
//  Copyright © 2019 OnlineAppCreator.com. All rights reserved.
//

import Foundation
import Alamofire

class API: NSObject {
    class var sharedInstance: API {
        struct Static {
            static let instance: API = API()
        }
        return Static.instance
        
        let loginURL = "https://www.tabbytracker.com/signin-app.php"
        
        func loginAPI(email: String, password: String, completion: @escaping (_ success: Bool) -> Void) {
            let header = [
                "Content-Type": "application/x-www-form-urlencoded"
            ]
            let params: [String: String] = [
                "client_secret" : email,
                "code" : password,
                ]
        }
    }
}
