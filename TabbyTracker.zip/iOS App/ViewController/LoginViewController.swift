//
//  LoginViewController.swift
//  Fido Finder
//
//  Created by MaskX on 2/24/19.
//  Copyright © 2019 OnlineAppCreator.com. All rights reserved.
//

import UIKit
import OneSignal

class LoginViewController: BaseViewController, OSSubscriptionObserver {
    
    @IBOutlet weak var emailTextField: UITextField!
    @IBOutlet weak var passwordTextField: UITextField!
    @IBOutlet weak var signinButton: UIButton!
    @IBOutlet weak var registerButton: UIButton!
    @IBOutlet weak var spinner: UIActivityIndicatorView!
    @IBOutlet weak var maskView: UIView!
    
    
    let loginURL = "http://dev.tabbytracker.com/signin-app.php"
    let dashboardURL = "http://dev.tabbytracker.com/dashboard.php"
    let registerURL = "http://dev.tabbytracker.com/register.php"
    var webviewurl = "https://www.tabbytracker.com/signin-app.php"  //Your URL including http:// and www.
    var urlEx = ""
    var oneSignalID = ""
    
    override func viewDidLoad() {
        super.viewDidLoad()

        self.getOneSignalID()
        
    }
    
    func getOneSignalID() {
        self.spinnerShowing()
        if(Constants.kPushEnabled)
        {
            OneSignal.add(self as OSSubscriptionObserver)
        } else {
            self.spinnerHidden()
        }
        
        //set to true to activate OneSignal Push (set App ID in AppDelegate.swift)
        if(Constants.kPushEnabled)
        {
            let status: OSPermissionSubscriptionState = OneSignal.getPermissionSubscriptionState()
            guard let userID = status.subscriptionStatus.userId else {
                self.spinnerHidden()
                return
            }
            self.oneSignalID = userID
            
            if(Constants.kPushEnhanceUrl && userID != nil && userID.count > 0)
            {
                self.urlEx = String(format: "%@onesignal_push_id=%@", (self.loginURL.contains("?") ? "&" : "?"), userID);
                self.spinnerHidden()
                self.checkSigninWithOriginalSignalID()
            } else {
                self.spinnerHidden()
            }
        } else {
            self.spinnerHidden()
        }
    }
    
    func checkSigninWithOriginalSignalID() {
        self.spinnerShowing()
        // signin check by 'Get' method
        let originalURLString = self.loginURL + self.urlEx + "&validate=true"
        let originalURL = URL(string: originalURLString)
        var request = URLRequest(url: originalURL!)
        
        request.httpMethod = "GET"
        
        let task = URLSession.shared.dataTask(with: request) {data, response, error in
            DispatchQueue.main.async {
                self.spinnerHidden()
            }
            guard let data = data,
                let response = response as? HTTPURLResponse,
                error == nil else {
                    print("error", error ?? "Internet connection error")
                    // info alert
                    DispatchQueue.main.async {
                        let alert = UIAlertController(title: "Alert", message: "Internet connection error", preferredStyle: UIAlertControllerStyle.alert)
                        alert.addAction(UIAlertAction(title: "OK", style: UIAlertActionStyle.default) { UIAlertAction in
                        })
                        self.present(alert, animated: true, completion: nil)
                    }
                    return
            }
            
            guard (200 ... 299) ~= response.statusCode else {
                print("status code should be 2xx, but is \(response.statusCode)")
                print("response = \(response)")
                
//                DispatchQueue.main.async {
//                    // info alert
//                    let alert = UIAlertController(title: "Alert", message: "status code should be 2xx, but is \(response.statusCode)", preferredStyle: UIAlertControllerStyle.alert)
//                    alert.addAction(UIAlertAction(title: "OK", style: UIAlertActionStyle.default) { UIAlertAction in
//                    })
//                    self.present(alert, animated: true, completion: nil)
//                }
                
                return
            }
            
            let responseString = String(data: data, encoding: .utf8)
            do {
                if let json = try JSONSerialization.jsonObject(with: data, options: .mutableContainers) as? [String: Any] {
                    print(json)
                    guard let _ = json["error"] as? String else {
                        
                        let signin = json["signedin"] as! String
                        if signin == "true" {
                            // get the response url
                            let url = json["url"] as! String
                            // goto the webview with that url
                            self.appDelegate.webURL = url
                            DispatchQueue.main.async {
                                self.gotoWebViewController()
                                self.spinnerHidden()
                            }
                        }
                        return
                    }
                }
            } catch let error {
                print(error.localizedDescription)
            }
            
            print(responseString!)
        }
        task.resume()
    }
    
    func spinnerShowing(){
        self.spinner.isHidden = false
        self.spinner.startAnimating()
        self.maskViewEnable()
    }
    
    func spinnerHidden() {
        self.spinner.isHidden = true
        self.spinner.stopAnimating()
        self.maskViewDisable()
    }
    
    func maskViewDisable() {
        self.maskView.isHidden = true
        self.view.isUserInteractionEnabled = true
    }
    
    func maskViewEnable() {
        self.maskView.isHidden = false
        self.view.isUserInteractionEnabled = false
    }
    
    @IBAction func signinAction(_ sender: UIButton) {
        let email = emailTextField.text!
        let password = passwordTextField.text!
        self.spinnerShowing()
        self.signinFunc(email, password)
    }
    
    func signinFunc(_ email: String, _ password: String) {
            // for signin --  loginURL = "http://dev.tabbytracker.com/signin-app.php"
        let url = URL(string: self.loginURL)!  // http://dev.tabbytracker.com/signin-app.php
        
            //let url = URL(string: self.loginURL)!

            var request = URLRequest(url: url)
            
            request.setValue("application/x-www-form-urlencoded", forHTTPHeaderField: "Content-Type")
            
            request.httpMethod = "POST"
            let parameters: [String: Any] = [
                "email" : email,
                "password": password,
                "onesignal_push_id": self.oneSignalID
            ]
            request.httpBody = parameters.percentEscaped().data(using: .utf8)
            
            let task = URLSession.shared.dataTask(with: request) {data, response, error in
                DispatchQueue.main.async {
                    self.spinnerHidden()
                }
                guard let data = data,
                    let response = response as? HTTPURLResponse, error == nil else {
                        print("error", error ?? "Internet connection error")
                        // info alert
                        DispatchQueue.main.async {
                            let alert = UIAlertController(title: "Alert", message: "Internet connection error", preferredStyle: UIAlertControllerStyle.alert)
                            alert.addAction(UIAlertAction(title: "OK", style: UIAlertActionStyle.default) { UIAlertAction in
                            })
                            self.present(alert, animated: true, completion: nil)
                        }
                        
                        return
                }
                
                guard (200 ... 299) ~= response.statusCode else {
                    print("status code should be 2xx, but is \(response.statusCode)")
                    print("response = \(response)")
                    
                    DispatchQueue.main.async {
                        // info alert
                        let alert = UIAlertController(title: "Alert", message: "status code should be 2xx, but is \(response.statusCode)", preferredStyle: UIAlertControllerStyle.alert)
                        alert.addAction(UIAlertAction(title: "OK", style: UIAlertActionStyle.default) { UIAlertAction in
                        })
                        self.present(alert, animated: true, completion: nil)
                    }
                    
                    return
                }
                
                let responseString = String(data: data, encoding: .utf8)
                do {
                    if let json = try JSONSerialization.jsonObject(with: data, options: .mutableContainers) as? [String: Any] {
                        print(json)
                        guard let error = json["error"] as? String else {
                            
                            let signin = json["signedin"] as! String
                            if signin == "true" {
                                // get the response url
                                let url = json["url"] as! String
                                // goto the webview with that url
                                self.appDelegate.webURL = url
                                DispatchQueue.main.async {
                                    UserDefaults.standard.set(email, forKey: "email")
                                    UserDefaults.standard.set(password, forKey: "password")
                                    UserDefaults.standard.synchronize()
                                    self.gotoWebViewController()
                                    self.spinnerHidden()
                                }
                            } else {
                                print("signin false")
                                
                            }
                            
                            return
                        }
                        if error != "" {
                            DispatchQueue.main.async {
                                // info alert
                                let alert = UIAlertController(title: "Alert", message: (json["text"] as! String), preferredStyle: UIAlertControllerStyle.alert)
                                alert.addAction(UIAlertAction(title: "OK", style: UIAlertActionStyle.default) { UIAlertAction in
                                })
                                self.present(alert, animated: true, completion: nil)
                            }
                        }
                    }
                } catch let error {
                    print(error.localizedDescription)
                }
                
                print(responseString!)
            }
            
            task.resume()
        }
    
    
    
    func gotoWebViewController() {
        let storyboard: UIStoryboard? = UIStoryboard(name: "Main", bundle: nil)
        let rootVC = storyboard?.instantiateViewController(withIdentifier: "webviewVC") as? WebViewController
        self.navigationController?.pushViewController(rootVC!, animated: true)
    }
    
    @IBAction func registerAction(_ sender: UIButton) {
        self.appDelegate.webURL = self.registerURL
        self.gotoWebViewController()
    }
    
    

    func onOSSubscriptionChanged(_ stateChanges: OSSubscriptionStateChanges!) {
//        if Constants.kPushEnabled && !stateChanges.from.subscribed && stateChanges.to.subscribed
//        {
//            print("Subscribed for OneSignal push notifications!")
//
//            if(Constants.kPushReloadOnUserId)
//            {
//                let status: OSPermissionSubscriptionState = OneSignal.getPermissionSubscriptionState()
//                let userID = status.subscriptionStatus.userId
//
//                if(Constants.kPushEnhanceUrl && userID != nil && userID!.count > 0)
//                {
//                    self.urlEx = String(format: "%@onesignal_push_id=%@", (self.loginURL.contains("?") ? "&" : "?"), userID!);
//                }
//            }
//        }
//
//        print("SubscriptionStateChange: \n\(stateChanges!)")
    }
}
