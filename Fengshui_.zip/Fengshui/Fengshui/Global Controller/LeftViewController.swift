

import UIKit
import LGSideMenuController
import Firebase

class LeftViewController: BaseViewController {
    
    
    @IBOutlet weak var sideAvatar: UIImageView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        if Auth.auth().currentUser?.uid == nil{
//            handleLogout()
        } else{
            self.checkIfUserIsLoggedIn()
        }
        // Do any additional setup after loading the view.
    }
    
    func checkIfUserIsLoggedIn(){
        let uid = Auth.auth().currentUser?.uid
        Database.database().reference().child("users").child(uid!).observeSingleEvent(of: .value, with:{ (DataSnapshot) in
            
            if let dictionary = DataSnapshot.value as? NSDictionary {
                self.appDelegate.loggedin_user = User(dictionary)
                
                self.sideAvatar.layer.cornerRadius = 85
                self.sideAvatar.clipsToBounds = true
                self.sideAvatar.loadImageUsingCacheWithUrlString(urlString: (dictionary["profileImageURL"]) as! String)
            }
        }, withCancel: nil)
    }
    
    func handleLogout(){
        appDelegate.makingRoot("initial")
    }
    
    @IBAction func actionMenu(_ sender: UIButton) {
        
//
        
        switch sender.tag {
        case 100:
            menu_icon_clicked_number = 100
            gotoWebView()
        case 101:
            menu_icon_clicked_number = 101
            gotoWebView()
        case 102:
            menu_icon_clicked_number = 102
            gotoWebView()
        case 103:
            menu_icon_clicked_number = 103
            gotoWebView()
        case 104:
           appDelegate.makingRoot("initial")
        
        default:
            break
        }
    }
    
    func gotoWebView(){
        let LGSideMenu: LGSideMenuController? = (parent as? LGSideMenuController)
        let obj: WebViewController = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "WebViewVC") as! WebViewController
        
        let navController = UINavigationController(rootViewController: obj)
        navController.setNavigationBarHidden(true, animated: false)
        LGSideMenu?.rootViewController = navController
        LGSideMenu?.hideLeftView(animated: true, completionHandler: nil)
    }
    
    
}

