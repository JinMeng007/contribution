
import UIKit
import LGSideMenuController

class BaseViewController: UIViewController {
    
    let appDelegate: AppDelegate = UIApplication.shared.delegate as! AppDelegate

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        self.navigationController?.setNavigationBarHidden(true, animated: false)
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    //MARK: Gloabl Alert View Controller
    func alertViewController(title: String, message: String){
        let alert = UIAlertController(title: title.capitalized, message: message , preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "OK", style:.default, handler: nil))
        present(alert, animated: true, completion: nil)
    }
    
    func showHUD(){
//        EZLoadingActivity.Settings.ShadowEnabled = false
//        EZLoadingActivity.show("", disableUI: true)
    }
    
    func hideHUD(){
//        EZLoadingActivity.hide()
    }
    
    //MARK: Side menu Controller
    
    func setupMenuBarButton(){
        
        let menuButtonImg = UIImageView(frame: CGRect(x: 25, y: 45, width: 25, height: 20))
        menuButtonImg.image = #imageLiteral(resourceName: "hamburgerIcon")
        
        let menuButton = UIButton(frame: CGRect(x: 25, y: 45, width: 30, height: 30))
        menuButton.addTarget(self, action: #selector(BaseViewController.showLGSideMenu(_:)), for: .touchUpInside)
        self.view.addSubview(menuButtonImg)
        self.view.addSubview(menuButton)
        
    }
    
    // MARK: - Open Side menu Controller
    @objc func showLGSideMenu(_ sender: UIBarButtonItem) {
        sideMenuController?.showLeftView(animated: true, completionHandler: nil)
    }

}
