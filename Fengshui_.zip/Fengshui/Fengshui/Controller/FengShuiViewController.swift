//
//  FengShuiViewController.swift
//  Fengshui
//
//  Created by Liu Jie on 11/4/18.
//  Copyright © 2018 fullstackcoach123. All rights reserved.
//

import UIKit
import Firebase

class FengShuiViewController: BaseViewController {

    
    @IBOutlet weak var UserName_label: UILabel!
    @IBOutlet weak var UserProfileImage_view: UIImageView!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.fetch_LoggedIn_User()
    }
    
    func fetch_LoggedIn_User() {
        let uid = Auth.auth().currentUser?.uid
        Database.database().reference().child("users").child(uid!).observeSingleEvent(of: .value, with:{ (DataSnapshot) in
            
            if let dictionary = DataSnapshot.value as? NSDictionary {
                
                let user = User(dictionary)
                self.setupNavBarWithUser(user: user!)
            }
        }, withCancel: nil)
    }
    
    func setupNavBarWithUser(user : User) {
       
        self.UserName_label.text = user.name
        //
        //        if let profileImageURL = user.profileImageURL {
        //            self.UserProfileImage_view.layer.cornerRadius = 25
        //            self.UserProfileImage_view.clipsToBounds = true
        //            self.UserProfileImage_view.loadImageUsingCacheWithUrlString(urlString: profileImageURL)
        //        }
    }
    
    @IBAction func back_clicked(_ sender: UIButton) {
        self.navigationController?.popViewController(animated: true)
    }
    
    
    @IBAction func rec_end_clicked(_ sender: UIButton) {
        let storyboard: UIStoryboard? = UIStoryboard(name: "Main", bundle: nil)
        let rootVC = storyboard?.instantiateViewController(withIdentifier: "MessageVC") as? MessageViewController
        self.navigationController?.pushViewController(rootVC!, animated: true)
    }
    
    @IBAction func chatAction_clicked(_ sender: UIButton) {
//        let storyboard: UIStoryboard? = UIStoryboard(name: "Main", bundle: nil)
//        let rootVC = storyboard?.instantiateViewController(withIdentifier: "ChatVC") as? ChatViewController
//        self.navigationController?.pushViewController(rootVC!, animated: true)
    }
    
    
    

}
