//
//  ChatLogController.swift
//  Fengshui
//
//  Created by Liu Jie on 11/12/18.
//  Copyright © 2018 fullstackcoach123. All rights reserved.
//

import UIKit
import Firebase
import MobileCoreServices
import AVFoundation

class ChatLogViewController: BaseViewController, UITextFieldDelegate, UICollectionViewDelegateFlowLayout, UIImagePickerControllerDelegate, UINavigationControllerDelegate {
    
    
    @IBOutlet weak var messageBox: UITextField!
    @IBOutlet weak var messageNavbarName: UILabel!
    @IBOutlet weak var chatLogCollectionView: UICollectionView!
    var global_player: AVPlayer!
    
    
    var messages = [Message]()
    var videoMessage: Message?
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.observeMessages()
        chatLogCollectionView.backgroundColor = UIColor.white
        chatLogCollectionView.alwaysBounceVertical = true
        
        messageBox.delegate = self
//        messageBox.becomeFirstResponder()
        messageNavbarName.text = self.appDelegate.selected_user?.name
    }
    
    override func viewWillAppear(_ animated: Bool) {
        if self.appDelegate.videoLocalURL != nil && self.appDelegate.uploadVideoFlag! {
            self.uploadRecordingVideoWithURL(self.appDelegate.videoLocalURL!)
        }
    }
    
    func observeMessages() {
        
        guard let uid = Auth.auth().currentUser?.uid, let toId = self.appDelegate.selected_user?.id else {
            return
        }
        
        let userMessageRef = Database.database().reference().child("user-messages").child(uid).child(toId)
        
        userMessageRef.observe(.childAdded, with: {(DataSnapshot) in
           
            let messageId = DataSnapshot.key
            let messageRef = Database.database().reference().child("messages").child(messageId)
            messageRef.observeSingleEvent(of: .value, with: {(DataSnapshot) in

//                print(DataSnapshot)
                if let dictionary = DataSnapshot.value as? NSDictionary {

                    //potential of crashing if keys don't match
                    let message = Message(dictionary)
                    
                    //do we need to attempt filtering anymore?
                    self.messages.append(message!)
                    DispatchQueue.main.async {
                        self.chatLogCollectionView.reloadData()
                        //scroll to the last index
                        let indexPath = IndexPath(item: self.messages.count-1, section: 0)
                        self.chatLogCollectionView.scrollToItem(at: indexPath, at: .bottom, animated: true)
                    }
                    
                    
                }
            }, withCancel: nil)
            
        }, withCancel: nil)
    }
    
    @IBAction func back_clicked(_ sender: UIButton) {
        self.navigationController?.popViewController(animated: true)
    }
    
    @IBAction func videoUpload_clicked(_ sender: UIButton) {
//        self.handleUploadTap()
        
        self.gotoVideoRecorderVC()
    }
    
    func gotoVideoRecorderVC() {
        let storyboard: UIStoryboard? = UIStoryboard(name: "Main", bundle: nil)
        let rootVC = storyboard?.instantiateViewController(withIdentifier: "VideoRecorderVC") as? VideoRecorderViewController
        self.navigationController?.pushViewController(rootVC!, animated: true)
    }
    
    func handleUploadTap() {
        let imagePickerController = UIImagePickerController()
        
        imagePickerController.allowsEditing = true
        imagePickerController.delegate = self
        imagePickerController.mediaTypes = [kUTTypeImage as String, kUTTypeMovie as String]
        
        present(imagePickerController, animated: true, completion: nil)
    }
    
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [String : Any]) {
        
        if let videoURL = info[UIImagePickerControllerMediaURL] as? URL {
            //we selected a video
            let thumbnailImage = self.thumbnailImageForFileUrl(videoURL)
            //
            self.handleVideoSelectedForUrl(url: videoURL, image: thumbnailImage!)
        } else {
            //we selected an image
            self.handleImageSelectedForInfo(info: info as [String : AnyObject])
        }
        dismiss(animated: true, completion: nil)
    }
    
    public func uploadRecordingVideoWithURL(_ videoURL: URL){
        if let thumbnailImage = self.thumbnailImageForFileUrl(videoURL) {
            self.handleVideoSelectedForUrl(url: videoURL, image: thumbnailImage)
        } else {
            print("thumbnailImage -------- nil")
        }
        
    }
    
    private func handleVideoSelectedForUrl(url: URL, image: UIImage) {
        let filename = NSUUID().uuidString + ".mp4"
        let storageRef = Storage.storage().reference().child("message_movies").child(filename)
        
        let uploadTask = storageRef.putFile(from: url, metadata: nil, completion: {(metadata, error) in
            
            if error != nil {
                print("Failed upload of video: ", error)
                return
            }
            
            // You can also access to download URL after upload.
            storageRef.downloadURL { (url, error) in
                guard let downloadURL = url else {
                    // Uh-oh, an error occurred!
                    return
                }
                let videoUrl = downloadURL.absoluteString
                let thumbnailImage = image
//                if let thumbnailImage = self.thumbnailImageForFileUrl(downloadURL) {
                
                self.uploadToFirebaseStorageUsingImage(image: thumbnailImage, completion: {(imageUrl) in
                    
                    //////
                    let properties: [String: AnyObject] = ["imageUrl": imageUrl, "imageWidth": thumbnailImage.size.width, "imageHeight": thumbnailImage.size.height, "videoUrl": videoUrl] as [String: AnyObject]
                    self.sendMessageWithProperties(properties: properties)
                    
                })
                    
                    
//                }
            }
        })
        uploadTask.observe(.progress, handler: {(DataSnapshot) in
            if let completedUnitCount = DataSnapshot.progress?.completedUnitCount {
                self.messageNavbarName.text = String(completedUnitCount)
            }
        })
        uploadTask.observe(.success, handler: {(DataSnapshot) in
            self.messageNavbarName.text = self.appDelegate.selected_user?.name
        })
    }
    
    private func sendMessageWithProperties(properties: [String: AnyObject]) {
        let ref = Database.database().reference().child("messages")
        let childRef = ref.childByAutoId()
        let toId = self.appDelegate.selected_user?.id
        let fromId = Auth.auth().currentUser?.uid
        let timestamp = Int(Date().timeIntervalSince1970)
        var values: [String: AnyObject] = ["toId": toId, "fromId": fromId, "timestamp": timestamp] as [String : AnyObject]
        
        //append properties dictionary onto values somehow??
        //key $0, value $1
        properties.forEach({values[$0] = $1})
        childRef.updateChildValues(values) {(error, ref) in
            if error != nil {
                print(error)
                return
            }
            
            self.messageBox.text = nil
            let userMessagesRef = Database.database().reference().child("user-messages").child(fromId!).child(toId!)
            
            let messageId = childRef.key
            userMessagesRef.updateChildValues([messageId!: 1])
            
            let recipientUserMessageRef = Database.database().reference().child("user-messages").child(toId!).child(fromId!)
            recipientUserMessageRef.updateChildValues([messageId!: 1])
        }
    }
    
    private func thumbnailImageForFileUrl(_ url: URL) -> UIImage? {
        let asset = AVAsset(url: url)
        let imageGenerator = AVAssetImageGenerator(asset: asset)
        imageGenerator.appliesPreferredTrackTransform = true
        do {
            
            let thumbnailImage = try imageGenerator.copyCGImage(at: CMTime(seconds: 1, preferredTimescale: 2), actualTime: nil)
            return UIImage(cgImage: thumbnailImage)
        }catch let err {
            print(err.localizedDescription)
        }
        return nil
    }
    
    private func uploadToFirebaseStorageUsingImage(image: UIImage, completion: @escaping (_ imageUrl: String) -> ()) {
        let imageName = NSUUID().uuidString + ".jpg"
        let ref = Storage.storage().reference().child("message_images").child(imageName)
        
        if let uploadData = UIImageJPEGRepresentation(image,0.2) {
            ref.putData(uploadData, metadata: nil, completion: {(metadata, error) in
                if error != nil {
                    print("Failed to upload image:", error)
                    return
                }
                
                // You can also access to download URL after upload.
                ref.downloadURL { (url, error) in
                    guard let downloadURL = url else {
                        // Uh-oh, an error occurred!
                        return
                    }
                    let imageUrl = downloadURL.absoluteString
                    completion(imageUrl)
//                    self.sendMessageWithImageUrl(imageUrl: imageUrl, image: image)
                    
                }
            })
        }
    }
    
    private func sendMessageWithImageUrl(imageUrl: String, image: UIImage) {
        let properties: [String: AnyObject] = [ "imageUrl": imageUrl, "imageWidth": image.size.width, "imageHeight": image.size.height] as [String : AnyObject]
        self.sendMessageWithProperties(properties: properties)
    }
    
    private func handleImageSelectedForInfo(info: [String: AnyObject]) {
        var selectedImageFromPicker: UIImage?
        if let editedImage = info["UIImagePickerControllerEditedImage"] as? UIImage {
            selectedImageFromPicker = editedImage
        } else if let originalImage = info["UIImagePickerControllerOriginalImage"] as? UIImage {
            selectedImageFromPicker = originalImage
        }
        
        if let selectedImage = selectedImageFromPicker {
            self.uploadToFirebaseStorageUsingImage(image: selectedImage, completion: {(imageUrl) in
                self.sendMessageWithImageUrl(imageUrl: imageUrl, image: selectedImage)
            })
        }
        dismiss(animated: true, completion: nil)
    }
    
    
    @IBAction func send_clicked(_ sender: UIButton) {
        self.handleSend()
    }
    
    func handleSend() {
        let ref = Database.database().reference().child("messages")
        let childRef = ref.childByAutoId()
        let toId = appDelegate.selected_user?.id
        let fromId = Auth.auth().currentUser?.uid
        
        
        let timestamp = Int(Date().timeIntervalSince1970)
        
        // is it there best thing to include the name inside of the message node
        let values = ["text": messageBox.text, "toId": toId, "fromId": fromId, "timestamp": timestamp] as [String : Any]
//        childRef.updateChildValues(values)
        
        
        childRef.updateChildValues(values) { (error, ref) in
            if error != nil {
                print(error)
                return
            }
            
            let userMessagesRef = Database.database().reference().child("user-messages").child(fromId!).child(toId!)
            
            let messageId = childRef.key
            userMessagesRef.updateChildValues([messageId!: 1])
            
            let recipientUserMessagesRef = Database.database().reference().child("user-messages").child(toId!).child(fromId!)
            recipientUserMessagesRef.updateChildValues([messageId!: 1])
            
        }
        
        messageBox.text?.removeAll()
    }
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        handleSend()
        return true
    }
}

extension ChatLogViewController : UICollectionViewDelegate, UICollectionViewDataSource, ChatMessageDelegate {
    
    
    func playClick(_ cell: chatMessageCell) {
        
        let index = self.chatLogCollectionView.indexPath(for: cell)?.row
        self.videoMessage = messages[index!]
        
        if let videoUrlString = videoMessage?.videoUrl, let url = URL(string: videoUrlString) {
//            cell.player = AVPlayer(url: url)
            self.global_player = AVPlayer(url: url)
            
//            cell.playerLayer = AVPlayerLayer(player: cell.player)
            cell.playerLayer = AVPlayerLayer(player: global_player)
            cell.playerLayer?.frame = cell.messageImageView.bounds
            cell.playerLayer?.videoGravity = .resizeAspectFill
            
            cell.messageImageView.layer.addSublayer(cell.playerLayer!)
            cell.playButton.isHidden = true
            
//            cell.activity.startAnimating()
            
//            cell.player?.play()
            global_player.play()
//            global_player.delegate = self
            
            
            
            print("Attempting to play video..")
        }

    }
    
    func audioPlayerDidFinishPlaying(_ player: AVAudioPlayer, successfully flag: Bool) {
        
    }
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return messages.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "cellId", for: indexPath) as? chatMessageCell
        let message = messages[indexPath.item]
        cell?.textView.text = message.text
        
        if let messageImageUrl = message.imageUrl {
            cell?.messageImageView.loadImageUsingCacheWithUrlString(urlString: messageImageUrl)
            cell?.messageImageView.isHidden = false
            cell?.textView.isHidden = true
        } else {
            cell?.messageImageView.isHidden = true
            cell?.textView.isHidden = false
        }
        if message.videoUrl != nil {
            cell?.playButton.isHidden = false
        } else {
            cell?.playButton.isHidden = true
        }
//        self.videoMessage = message
        cell?.playButton.isHidden = message.videoUrl == nil
        
        
        
        
        if message.fromId == Auth.auth().currentUser?.uid {
            //outgoing blue
            
            cell?.textView.backgroundColor = UIColor(red: 59/255, green: 143/255, blue: 245/255, alpha: 1.0)
            cell?.textView.textColor = UIColor.white
            cell?.textView.textAlignment = .right
            cell?.bubbleView.frame = CGRect(x: (UIScreen.main.bounds.size.width - (cell?.bubbleView.frame.width)!), y: (cell?.bubbleView.frame.origin.y)!, width: (cell?.bubbleView.frame.width)!, height: (cell?.bubbleView.frame.height)!)
            cell?.message_profileImage.isHidden = true
            
        } else {
            //incoming gray
            cell?.textView.backgroundColor = UIColor.lightGray
            cell?.textView.textColor = UIColor.black
            cell?.textView.textAlignment = .left
            cell?.bubbleView.frame = CGRect(x: -10, y: (cell?.bubbleView.frame.origin.y)!, width: (cell?.bubbleView.frame.width)!, height: (cell?.bubbleView.frame.height)!)
            cell?.message_profileImage.isHidden = false
            cell?.message_profileImage.layer.cornerRadius = 15
            cell?.message_profileImage.clipsToBounds = true
            if let profileImageURL = self.appDelegate.selected_user?.profileImageURL {
               
                cell?.message_profileImage.layer.cornerRadius = 10
                
                cell?.message_profileImage.loadImageUsingCacheWithUrlString(urlString: profileImageURL)
                
            }
        }
        
        cell?.delegate = self
        return cell!
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        var height : CGFloat = 80
        
        //get estimated height somehow??
        
        if let text = messages[indexPath.item].text {
            height = estimateFrameForText(text: text).height + 25
//            width = estimateFrameForText(text: text).width + 10
        } else if let imageWidth = messages[indexPath.item].imageWidth?.floatValue, let imageHeight = messages[indexPath.item].imageHeight?.floatValue
        {
            height = CGFloat(imageHeight / imageWidth * 200)
            
        }
        
        return CGSize(width: view.frame.width, height: height)
    }
    
    
    func estimateFrameForText(text: String) -> CGRect {
        let size = CGSize(width: 200, height: 1000)
        let options = NSStringDrawingOptions.usesFontLeading.union(.usesLineFragmentOrigin)
        
        return NSString(string: text).boundingRect(with: size, options: options, attributes: [NSAttributedStringKey.font: UIFont.systemFont(ofSize: 14.0)], context: nil)
    }
}

protocol ChatMessageDelegate {
    func playClick(_ cell: chatMessageCell)
}

class chatMessageCell: UICollectionViewCell {
    
    @IBOutlet weak var textView: UITextView!
    @IBOutlet weak var bubbleView: UIView!
    @IBOutlet weak var message_profileImage: UIImageView!
    @IBOutlet weak var messageImageView: UIImageView!
    @IBOutlet weak var playButton: UIButton!
    var playerLayer: AVPlayerLayer?
    var player: AVPlayer?
    
    @IBOutlet weak var activity: UIActivityIndicatorView!
    
    
    var delegate: ChatMessageDelegate?
    @IBAction func playButton_Clicked(_ sender: UIButton) {
        delegate?.playClick(self)
    }
    override func prepareForReuse() {
        super.prepareForReuse()
        playerLayer?.removeFromSuperlayer()
        player?.pause()
        activity.stopAnimating()
    }
}
