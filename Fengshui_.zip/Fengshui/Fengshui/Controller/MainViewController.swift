//
//  MainViewController.swift
//  Fengshui
//
//  Created by Liu Jie on 11/4/18.
//  Copyright © 2018 fullstackcoach123. All rights reserved.
//

import UIKit
import Firebase

class MainViewController: BaseViewController{

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        self.setupMenuBarButton()
        if Auth.auth().currentUser?.uid == nil{
            handleLogout()
        } else{
            self.checkIfUserIsLoggedIn()
        }
    }
    
    
    
    func checkIfUserIsLoggedIn(){
        let uid = Auth.auth().currentUser?.uid
        Database.database().reference().child("users").child(uid!).observeSingleEvent(of: .value, with:{ (DataSnapshot) in
            
            if let dictionary = DataSnapshot.value as? NSDictionary {
                user_name = dictionary["name"] as! String
                self.appDelegate.loggedin_user = User(dictionary)
            }
        }, withCancel: nil)
    }
    
    func handleLogout(){
        appDelegate.makingRoot("initial")
    }

    func gotoWebView(){
        let storyboard: UIStoryboard? = UIStoryboard(name: "Main", bundle: nil)
        let rootVC = storyboard?.instantiateViewController(withIdentifier: "WebViewVC") as? WebViewController
        self.navigationController?.pushViewController(rootVC!, animated: true)
    }
    
    @IBAction func search_icon_clicked(_ sender: UIButton) {
        
    }
    
    @IBAction func checkout_clicked(_ sender: UIButton) {
        menu_icon_clicked_number = 10
        gotoWebView()
    }
    
    @IBAction func shopBtn_clicked(_ sender: UIButton) {
        menu_icon_clicked_number = 1
        gotoWebView()
    }
    
    @IBAction func publicationsBtn_clicked(_ sender: UIButton) {
        menu_icon_clicked_number = 2
        gotoWebView()
    }
    
    @IBAction func eventsBtn_clicked(_ sender: UIButton) {
        menu_icon_clicked_number = 3
        gotoWebView()
    }
    
    @IBAction func virtualClassroomBtn_clicked(_ sender: UIButton) {
        menu_icon_clicked_number = 4
        gotoWebView()
    }
    @IBAction func facebookBtn_clicked(_ sender: UIButton) {
        menu_icon_clicked_number = 5
        gotoWebView()
    }
    @IBAction func baziCalcBtn_clicked(_ sender: UIButton) {
        menu_icon_clicked_number = 6
        gotoWebView()
    }
    @IBAction func emailUsBtn_clicked(_ sender: UIButton) {
        let storyboard: UIStoryboard? = UIStoryboard(name: "Main", bundle: nil)
        let rootVC = storyboard?.instantiateViewController(withIdentifier: "ContactVC") as? ContactViewController
        self.navigationController?.pushViewController(rootVC!, animated: true)
    }
    
    @IBAction func proBtn_clicked(_ sender: UIButton) {
        menu_icon_clicked_number = 8
        gotoWebView()
    }
    @IBAction func callUsBtn_clicked(_ sender: UIButton) {
        guard let number = URL(string: "telprompt://6567344138")
            else {
                return
        }
        #if (arch(i386) || arch(x86_64)) && os(iOS)
            // Simulator-specific code
            NSLog("sssssss-------sssssss")
            let alert = UIAlertController(title: "", message: "Run on real device!", preferredStyle: UIAlertControllerStyle.alert)
            alert.addAction(UIAlertAction(title: "OK", style: UIAlertActionStyle.default, handler: nil))
            self.present(alert, animated: true, completion: nil)
        #else
            // Device-specific code
            NSLog("ddddddd-------dddddd")
            UIApplication.shared.open(number)
        #endif
    }
    
    @IBAction func virtualFengshui_clicked(_ sender: UIButton) {
        let storyboard: UIStoryboard? = UIStoryboard(name: "Main", bundle: nil)
        let rootVC = storyboard?.instantiateViewController(withIdentifier: "MessageVC") as? MessageViewController
//        let rootVC = storyboard?.instantiateViewController(withIdentifier: "FengShuiVC") as? FengShuiViewController
        self.navigationController?.pushViewController(rootVC!, animated: true)
    }
    
    
    
}
