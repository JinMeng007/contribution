//
//  MessageViewController.swift
//  Fengshui
//
//  Created by Liu Jie on 11/4/18.
//  Copyright © 2018 fullstackcoach123. All rights reserved.
//

import UIKit
import Firebase

class MessageViewController: BaseViewController {

    
    @IBOutlet weak var UserName_label: UILabel!
    @IBOutlet weak var UserProfileImage_view: UIImageView!
    @IBOutlet weak var messageTableView: UITableView!
    var messages = [Message] ()
    var messagesDictionary = [String: Message]()
    var timer: Timer?
    
    
    override func viewDidLoad() {
        super.viewDidLoad()

        self.appDelegate.uploadVideoFlag = false
        // Do any additional setup after loading the view.
        self.fetch_LoggedIn_User()
//        self.observeMessages()
        messageTableView.allowsMultipleSelectionDuringEditing = true
    }
    
    override func viewWillAppear(_ animated: Bool) {
        self.appDelegate.uploadVideoFlag = false
    }
    
    func observeUserMessages() {
        guard let uid = Auth.auth().currentUser?.uid else {
            return
        }
        
        
        let ref = Database.database().reference().child("user-messages").child(uid)
        ref.observe(.childAdded, with: {(DataSnapshot) in
            
            let userId = DataSnapshot.key
            Database.database().reference().child("user-messages").child(uid).child(userId).observe(.childAdded , with: {(DataSnapshot) in
//                print(DataSnapshot)
                
                let messageId = DataSnapshot.key
                self.fetchMessageWithMessageId(messageId: messageId)
                
            }, withCancel: nil)
            
        }, withCancel: nil)
        
        ref.observe(.childRemoved, with: {(DataSnapshot) in
            self.messagesDictionary.removeValue(forKey: DataSnapshot.key)
            self.attemptReloadOfTable()
            
        })
    }
    
    private func fetchMessageWithMessageId(messageId: String) {
        
        let messagesReference = Database.database().reference().child("messages").child(messageId)
        
        messagesReference.observeSingleEvent(of: .value, with: {(DataSnapshot) in
            
            if let dictionary = DataSnapshot.value as? NSDictionary {
                
                let message = Message(dictionary)
                
                if let toId = message?.toId {
//                    if toId == Auth.auth().currentUser?.uid {
                        self.messagesDictionary[toId] = message
//                    }
                }
                
                self.attemptReloadOfTable()
            }
        }, withCancel: nil)
    }
    
    private func attemptReloadOfTable() {
        self.timer?.invalidate()
        self.timer = Timer.scheduledTimer(timeInterval: 0.1, target: self, selector: #selector(self.handleReloadTable), userInfo: nil, repeats: false)
    }
    
    
    @objc func handleReloadTable()
    {
        self.messages = Array(self.messagesDictionary.values)
        
        self.messages.sort(by: {(message1, message2) ->
            Bool in
            return message1.timestamp!.intValue > message2.timestamp!.intValue
        })
        DispatchQueue.main.async {
            self.messageTableView.reloadData()
        }
    }
    
    @IBAction func showChatController(_ sender: UIButton) {
//        self.gotoChatLogVC()
    }
    
    func gotoChatLogVC(){
        let storyboard: UIStoryboard? = UIStoryboard(name: "Main", bundle: nil)
        let rootVC = storyboard?.instantiateViewController(withIdentifier: "ChatLogVC") as? ChatLogViewController
        self.navigationController?.pushViewController(rootVC!, animated: true)
    }
    
    
    func fetch_LoggedIn_User() {
        let uid = Auth.auth().currentUser?.uid
        Database.database().reference().child("users").child(uid!).observeSingleEvent(of: .value, with:{ (DataSnapshot) in
            
            if let dictionary = DataSnapshot.value as? NSDictionary {
                
                let user = User(dictionary)
                self.setupNavBarWithUser(user: user!)
            }
        }, withCancel: nil)
    }

    func setupNavBarWithUser(user : User) {
        messages.removeAll()
        messagesDictionary.removeAll()
        messageTableView.reloadData()
        
        self.observeUserMessages()
        
        self.UserName_label.text = user.name
        //
        if let profileImageURL = user.profileImageURL {
            self.UserProfileImage_view.layer.cornerRadius = 20
            self.UserProfileImage_view.clipsToBounds = true
            self.UserProfileImage_view.loadImageUsingCacheWithUrlString(urlString: profileImageURL)
        }
    }
    
    @IBAction func newMessage_clicked(_ sender: UIButton) {
        let storyboard: UIStoryboard? = UIStoryboard(name: "Main", bundle: nil)
        let rootVC = storyboard?.instantiateViewController(withIdentifier: "NewMessageVC") as? NewMessageViewController
        self.navigationController?.pushViewController(rootVC!, animated: true)
    }
    
    
    @IBAction func goBack_clicked(_ sender: UIButton) {
        self.navigationController?.popViewController(animated: true)
    }
}

extension MessageViewController: UITableViewDelegate, UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return messages.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "messageCell") as! MessageCell
        
        
        if let id = messages[indexPath.row].chatPartnerId() {
            let ref = Database.database().reference().child("users").child(id)
            
            /////////////////
            
            
            ref.observeSingleEvent(of: .value, with: {(DataSnapshot) in
                if let dictionary = DataSnapshot.value as? [String: AnyObject]
                {
                    cell.messageName.text = dictionary["name"] as? String
                    if let profileImageURL = dictionary["profileImageURL"] as? String {
                        cell.messageImage.loadImageUsingCacheWithUrlString(urlString: profileImageURL)
                    }
                }
            }, withCancel: nil)
        }
        cell.messageText.text = messages[indexPath.row].text
        
        // TimeStamp
        if let seconds = messages[indexPath.row].timestamp?.doubleValue {
            let timestampDate = Date(timeIntervalSince1970: seconds)
            
            let dateFormatter = DateFormatter()
            dateFormatter.dateFormat = "hh:mm:ss a"
            cell.messageTime.text = dateFormatter.string(from: timestampDate)
        }
        

        cell.messageImage.layer.cornerRadius = 30
        cell.messageImage.clipsToBounds = true
        cell.messageImage.contentMode = .scaleAspectFill
        
        return cell
    }
    
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let message = messages[indexPath.row]
        
        guard let chatPartnerId = message.chatPartnerId() else {
            return
        }
        
        let ref = Database.database().reference().child("users").child(chatPartnerId)
        ref.observeSingleEvent(of: .value, with: {(DataSnapshot) in
//            print(DataSnapshot)
            guard let dictionary = DataSnapshot.value as? NSDictionary else {
                return
            }
            
            let user = User(dictionary)
            
            self.appDelegate.selected_user = user
            self.appDelegate.selected_user?.id = chatPartnerId
            self.gotoChatLogVC()
            // showChatControllerForUser(user)
            
        }, withCancel: nil)
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 80
    }
    
    func tableView(_ tableView: UITableView, canEditRowAt indexPath: IndexPath) -> Bool {
        return true
    }
    
    func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCellEditingStyle, forRowAt indexPath: IndexPath) {
       
        guard let uid = Auth.auth().currentUser?.uid else {
            return
        }
        
        let message = self.messages[indexPath.row]
        
        if let chatPartnerId = message.chatPartnerId() {
            Database.database().reference().child("user-messages").child(uid).child(chatPartnerId).removeValue(completionBlock: { (error, ref) in
            if error != nil {
//                print("Failed to delete message:", error)
                return
            }
            
            self.messagesDictionary.removeValue(forKey: chatPartnerId)
            self.attemptReloadOfTable()
                
////            this is one way of updating the table, but its actually not that safe..
//            self.messages.remove(at: indexPath.row)
//            self.messageTableView.deleteRows(at: [indexPath], with: .automatic)
        })
    }
   }
}

class MessageCell: UITableViewCell {
    @IBOutlet weak var messageImage: UIImageView!
    @IBOutlet weak var messageName: UILabel!
    @IBOutlet weak var messageText: UILabel!
    @IBOutlet weak var messageTime: UILabel!
}
