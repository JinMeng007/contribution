//
//  NewMessageViewController.swift
//  Fengshui
//
//  Created by Liu Jie on 11/11/18.
//  Copyright © 2018 fullstackcoach123. All rights reserved.
//

import UIKit
import Firebase

class NewMessageViewController: BaseViewController {

    
    @IBOutlet weak var activity_indicator: UIActivityIndicatorView!
    @IBOutlet weak var userlist_tableView: UITableView!
    
    
    var users = [User]()
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        self.appDelegate.uploadVideoFlag = false
        fetchUser()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        self.appDelegate.uploadVideoFlag = false
    }
    
    func fetchUser(){
        
        
    Database.database().reference().child("users").observe(.childAdded, with: {(DataSnapshot) in
        
        if let dictionary = DataSnapshot.value as? NSDictionary {
            
            let user = User(dictionary)
            user?.id = DataSnapshot.key
            if user?.id != Auth.auth().currentUser?.uid {
                self.users.append(user!)
                
                DispatchQueue.main.async {
                    self.userlist_tableView.reloadData()
                }
            }
            
        }
       
        }, withCancel: nil)
    }
    @IBAction func cancel_clicked(_ sender: UIButton) {
         self.navigationController?.popViewController(animated: true)
    }
    
    
}

extension NewMessageViewController : UITableViewDelegate, UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return users.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "newMessageCell") as! NewMessageCell
        
        cell.list_top_label.text = self.users[indexPath.row].name
        cell.list_down_label.text = self.users[indexPath.row].email
        cell.image_view.layer.cornerRadius = 30
        cell.image_view.clipsToBounds = true
        cell.image_view.contentMode = .scaleAspectFill
//        cell.list_image?.image = UIImage(named: "fengshui_image")
        
        activity_indicator.startAnimating()
        if let profileImageURL = self.users[indexPath.row].profileImageURL {
            // Reference the Extensions class
        cell.list_image?.loadImageUsingCacheWithUrlString(urlString: profileImageURL)
        
            activity_indicator.stopAnimating()
        }
        
        return cell
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 80
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
        let user = users[indexPath.row]
        appDelegate.selected_user = user
        
        let storyboard: UIStoryboard? = UIStoryboard(name: "Main", bundle: nil)
        let rootVC = storyboard?.instantiateViewController(withIdentifier: "ChatLogVC") as? ChatLogViewController
        self.navigationController?.pushViewController(rootVC!, animated: true)
    }
}

class NewMessageCell : UITableViewCell{
    
    @IBOutlet weak var list_image: UIImageView!
    @IBOutlet weak var list_top_label: UILabel!
    @IBOutlet weak var list_down_label: UILabel!
    @IBOutlet weak var image_view: UIView!
    
    
}
