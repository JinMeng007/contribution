//
//  ViewController.swift
//  Fengshui
//
//  Created by Liu Jie on 11/8/18.
//  Copyright © 2018 fullstackcoach123. All rights reserved.
//

import UIKit
import Firebase

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

//        let ref = Database.database().reference(fromURL: "https://chat-63090.firebaseio.com/")
//        ref.updateChildValues(["someValue": 123123])
        
    }

    

}
