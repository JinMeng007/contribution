//
//  VideoRecorderViewController.swift
//  Fengshui
//
//  Created by FullStack on 11/22/18.
//  Copyright © 2018 fullstackcoach123. All rights reserved.
//

import UIKit
import AVFoundation
import Firebase
import CoreLocation

class VideoRecorderViewController: BaseViewController, AVCaptureFileOutputRecordingDelegate, CLLocationManagerDelegate {
    
    
    @IBOutlet weak var camPreview: UIView!
    
    @IBOutlet weak var compassView: UIView!
    @IBOutlet weak var compassImage: UIImageView!
    @IBOutlet weak var compassArrow: UIImageView!
    @IBOutlet weak var headingLabel: UILabel!
    
    
    @IBOutlet weak var recording_button: UIButton!
    @IBOutlet weak var mute_button: UIButton!
    @IBOutlet weak var showCompass_button: UIButton!
    
    let speechSynthesizer = AVSpeechSynthesizer()
    var locationManager: CLLocationManager!
    var degrees: CGFloat = 0.0
    var radians: CGFloat = 0.0
    
    
    var captureSession = AVCaptureSession()
    var movieOutput = AVCaptureMovieFileOutput()
    var previewLayer: AVCaptureVideoPreviewLayer!
    var activeInput: AVCaptureDeviceInput!
    var outputURL: URL!
    
    var mic_on = true
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        //Location manager initialization
        
        locationManager  = CLLocationManager()
        locationManager.delegate = self
        locationManager.desiredAccuracy = kCLLocationAccuracyBest
        locationManager.requestWhenInUseAuthorization()
        locationManager.startUpdatingHeading()
        
        //Create gesture recognizer and add to compassImage
        let tapGestureRecognizer = UITapGestureRecognizer(target:self, action:#selector(imageTapped(img:)))
        compassImage.isUserInteractionEnabled = true
        compassImage.addGestureRecognizer(tapGestureRecognizer)
        
        if setupSession() {
            setupPreview()
            startSession()
        }
    }
    
    func camera_configuration() {
        captureSession = AVCaptureSession()
        movieOutput = AVCaptureMovieFileOutput()
        activeInput = nil
        outputURL = nil
        if setupSession() {
            setupPreview()
            startSession()
        }
    }
    
    //Speak location depending on heading.
    @objc func imageTapped(img: AnyObject)
    {
        switch self.degrees {
        //North
        case 340.0...360.0, 0.0..<20.0 :
            speak("You are facing north")
            
        //Northeast
        case 20.0..<70.0:
            speak("You are facing northeast")
            
        //East
        case 70.0..<110.0:
            speak("You are facing east")
            
        //Southeast
        case 110.0..<160.0:
            speak("You are facing southeast")
            
        //South
        case 160.0..<200.0:
            speak("You are facing south")
            
        //Southwest
        case 200.0..<250.0:
            speak("You are facing southwest")
            
        //West
        case 250.0..<290.0:
            speak("You are facing west")
            
        //Northwest
        case 290.0..<340.0:
            speak("You are facing northwest")
            
        //Default
        default:
            speak("Error")
        }
    }
    
    //Text to speech
    func speak(_ sender: String) {
        let speechUtterance = AVSpeechUtterance(string: sender)
        speechSynthesizer.speak(speechUtterance)
    }
    
    func getAngel() -> String {
        switch self.degrees {
        //North
        case 340.0...360.0, 0.0..<20.0 :
            return "N"
            
        //Northeast
        case 20.0..<70.0:
            return "NE"
            
        //East
        case 70.0..<110.0:
            return "E"
            
        //Southeast
        case 110.0..<160.0:
            return "SE"
            
        //South
        case 160.0..<200.0:
            return "S"
            
        //Southwest
        case 200.0..<250.0:
            return "SW"
            
        //West
        case 250.0..<290.0:
            return "W"
            
        //Northwest
        case 290.0..<340.0:
            return "NW"
            
        //Default
        default:
            return ""
        }
    }
    
    //Gets heading of device using location and displays to headingLabel
    func locationManager(_ manager: CLLocationManager, didUpdateHeading heading: CLHeading) {
        degrees = CGFloat(heading.magneticHeading)
        
        let roundedDegrees = String(format: "%.2f", degrees)
        
        headingLabel.text = self.getAngel() + roundedDegrees +  "\u{00B0}"
        
        radians = CGFloat(heading.magneticHeading) * CGFloat(M_PI) / 180.0
        
        //Animate compass image
        UIView.animate(withDuration: 0.5, delay: 0.0, options: .allowUserInteraction, animations: {
            self.compassArrow.transform = CGAffineTransform(rotationAngle: self.radians)
        })
    }
    
    @IBAction func gotoBack(_ sender: UIButton) {
        self.navigationController?.popViewController(animated: true)
    }
    
    @IBAction func changeCameraDirection(_ sender: UIButton) {
        //Change camera source
        let session = self.captureSession
            //Indicate that some changes will be made to the session
            session.beginConfiguration()
            
            
            //Remove existing input
            guard let currentCameraInput: AVCaptureInput = session.inputs.first else {
                return
            }
            
            session.removeInput(self.activeInput)
            
            //Get new input
            var newCamera: AVCaptureDevice! = nil
        
         let input = self.activeInput.device.position
                if (input == .back) {
                    newCamera = cameraWithPosition(position: .front)
                } else {
                    newCamera = cameraWithPosition(position: .back)
                }
            
            
            //Add input to session
            var err: NSError?
            var newVideoInput: AVCaptureDeviceInput!
            do {
                newVideoInput = try AVCaptureDeviceInput(device: newCamera)
                self.activeInput = newVideoInput
            } catch let err1 as NSError {
                err = err1
                newVideoInput = nil
            }
            
            if newVideoInput == nil || err != nil {
                print("Error creating capture device input: \(err?.localizedDescription)")
            } else {
                session.addInput(newVideoInput)
            }
            
            //Commit all the configuration changes at once
            
            session.commitConfiguration()
        
    }
    
    // Find a camera with the specified AVCaptureDevicePosition, returning nil if one is not found
    func cameraWithPosition(position: AVCaptureDevice.Position) -> AVCaptureDevice? {
        let discoverySession = AVCaptureDevice.DiscoverySession(deviceTypes: [.builtInWideAngleCamera], mediaType: AVMediaType.video, position: .unspecified)
        for device in discoverySession.devices {
            if device.position == position {
                return device
            }
        }
        
        return nil
    }
    
    
    
    @IBAction func cameraClick(_ sender: UIButton) {
        if recording_button.backgroundColor == UIColor.red {
            self.recording_button.setImage(UIImage(named: "recording_button"), for: .normal)
            self.startCapture()
        } else {
            self.recording_button.setImage(UIImage(named: "fengshui_rec_icon"), for: .normal)
            self.startCapture()
        }
    }
    @IBAction func show_unshow_compass_click(_ sender: UIButton) {
        if !self.compassView.isHidden {
            self.compassView.isHidden = true
            self.showCompass_button.backgroundColor = UIColor.red
        } else {
            self.compassView.isHidden = false
            self.showCompass_button.backgroundColor = UIColor.clear
        }
        
    }
    
    @IBAction func mute_unmute_click(_ sender: UIButton) {
        if !movieOutput.isRecording {
            if self.mute_button.backgroundColor == UIColor.red {
                self.mic_on = true
                self.mute_button.backgroundColor = UIColor.clear
                self.camera_configuration()
            } else {
                self.mic_on = false
                self.mute_button.backgroundColor = UIColor.red
                self.camera_configuration()
            }
        }
    }
    
    
    
    func setupPreview() {
        // Configure previewLayer
        previewLayer = AVCaptureVideoPreviewLayer(session: captureSession)
        previewLayer.addSublayer(self.compassView.layer)
        previewLayer.frame = camPreview.bounds
        previewLayer.videoGravity = AVLayerVideoGravity.resizeAspectFill
        camPreview.layer.addSublayer(previewLayer)
//        camPreview.layer.addSublayer(self.compassView.layer)
        
    }
    
    
    //MARK:- Setup Camera
    
    func setupSession() -> Bool {
        
        captureSession.sessionPreset = AVCaptureSession.Preset.high
        
        // Setup Camera
        let camera: AVCaptureDevice?
            camera = AVCaptureDevice.default(.builtInWideAngleCamera, for: AVMediaType.video, position: .front)
        
    
        do {
            
            let input = try AVCaptureDeviceInput(device: camera!)
            if captureSession.canAddInput(input) {
                captureSession.addInput(input)
                
                activeInput = input
            }
        } catch {
            print("Error setting device video input: \(error)")
            return false
        }
        
        
        if self.mic_on {
            // Setup Microphone
            let microphone = AVCaptureDevice.default(for: AVMediaType.audio)
            
            do {
                let micInput = try AVCaptureDeviceInput(device: microphone!)
                if captureSession.canAddInput(micInput) {
                    captureSession.addInput(micInput)
                }
            } catch {
                print("Error setting device audio input: \(error)")
                return false
            }
        }
        
        
        
        // Movie output
        if captureSession.canAddOutput(movieOutput) {
            captureSession.addOutput(movieOutput)
        }
        
        return true
    }
    
    func setupCaptureMode(_ mode: Int) {
        // Video Mode
    
    }
    
    //MARK:- Camera Session
    func startSession() {
        
        
        if !captureSession.isRunning {
            videoQueue().async {
                self.captureSession.startRunning()
            }
        }
    }
    
    func stopSession() {
        if captureSession.isRunning {
            videoQueue().async {
                self.captureSession.stopRunning()
            }
        }
    }
    
    func videoQueue() -> DispatchQueue {
        return DispatchQueue.main
    }
    
    func currentVideoOrientation() -> AVCaptureVideoOrientation {
        var orientation: AVCaptureVideoOrientation
        
        switch UIDevice.current.orientation {
        case .portrait:
            orientation = AVCaptureVideoOrientation.portrait
        case .landscapeRight:
            orientation = AVCaptureVideoOrientation.landscapeLeft
        case .portraitUpsideDown:
            orientation = AVCaptureVideoOrientation.portraitUpsideDown
        default:
            orientation = AVCaptureVideoOrientation.landscapeRight
        }
        
        return orientation
    }
    
    func startCapture() {
        
        startRecording()
        
    }
    
    //EDIT 1: I FORGOT THIS AT FIRST
    
    func tempURL() -> URL? {
        let directory = NSTemporaryDirectory() as NSString
        
        if directory != "" {
            let path = directory.appendingPathComponent(NSUUID().uuidString + ".mp4")
            return URL(fileURLWithPath: path)
        }
        
        return nil
    }
    
    
    func startRecording() {
        
        if movieOutput.isRecording == false {
            
            let connection = movieOutput.connection(with: AVMediaType.video)
            if (connection?.isVideoOrientationSupported)! {
                connection?.videoOrientation = currentVideoOrientation()
            }
            
            if (connection?.isVideoStabilizationSupported)! {
                connection?.preferredVideoStabilizationMode = AVCaptureVideoStabilizationMode.auto
            }
            
            let device = activeInput.device
            if (device.isSmoothAutoFocusSupported) {
                do {
                    try device.lockForConfiguration()
                    device.isSmoothAutoFocusEnabled = false
                    device.unlockForConfiguration()
                } catch {
                    print("Error setting configuration: \(error)")
                }
                
            }
            
            //EDIT2: And I forgot this
            outputURL = tempURL()
            movieOutput.startRecording(to: outputURL, recordingDelegate: self)
            
        }
        else {
            stopRecording()
        }
        
    }
    
    func stopRecording() {
        
        if movieOutput.isRecording == true {
            movieOutput.stopRecording()
        }
    }

    func fileOutput(_ output: AVCaptureFileOutput, didStartRecordingTo fileURL: URL, from connections: [AVCaptureConnection]) {
        
    }
    
    func fileOutput(_ output: AVCaptureFileOutput, didFinishRecordingTo outputFileURL: URL, from connections: [AVCaptureConnection], error: Error?) {
        
        if (error != nil) {
            print("Error recording movie: \(error!.localizedDescription)")
        } else {
            
            let videoLocalURL = outputURL as URL
            print("VideoLocalURL----", videoLocalURL)
            
            self.appDelegate.videoLocalURL = videoLocalURL
            self.appDelegate.uploadVideoFlag = true
            self.navigationController?.popViewController(animated: true)
//            ChatLogViewController.uploadRecordingVideoWithURL(videoLocalURL)
            
            
        }
        outputURL = nil
    }
}

