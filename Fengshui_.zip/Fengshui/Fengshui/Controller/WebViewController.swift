//
//  WebViewController.swift
//  Fengshui
//
//  Created by Liu Jie on 11/4/18.
//  Copyright © 2018 fullstackcoach123. All rights reserved.
//

import UIKit

class WebViewController: BaseViewController, UIWebViewDelegate {

    
    @IBOutlet weak var activity: UIActivityIndicatorView!
    @IBOutlet weak var webView: UIWebView!
    @IBOutlet weak var webview_title: UILabel!
    
    
    @IBAction func backBtn_clicked(_ sender: UIButton) {
        if(webView.canGoBack){
            webView.goBack()
        } else{
            let storyboard: UIStoryboard? = UIStoryboard(name: "Main", bundle: nil)
            let rootVC = storyboard?.instantiateViewController(withIdentifier: "MainVC") as? MainViewController
            self.navigationController?.pushViewController(rootVC!, animated: true)
        }
    }
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        switch menu_icon_clicked_number {
        case 1:
            shopWebview()
        case 2:
            publicationsWebview()
        case 3:
            eventsWebview()
//        case 4:
//            virtualFengShuiWebview()
        case 5:
            facebookWebview()
        case 6:
            baziCalcWebview()
//        case 7:
//            emailUsWebview()
        case 8:
            pro_baziWebview()
//        case 9:
//            callUsWebview()
        case 10:
            checkoutWebview()
        case 100:
            myCartWebview()
        case 101:
            wishlistWebview()
        case 102:
            aboutUsWebview()
        case 103:
            facebookWebview()
        case 104:
            signinWebview()
        default:
            shopWebview()
        }
    }
    
    func webViewLoad(url: String){
        if let urlStr = URL(string: url) {
            let request = URLRequest(url: urlStr)
            webView.loadRequest(request)
        }
    }
    
    func shopWebview(){
        webview_title.text = "Shop"
        webViewLoad(url: "https://eastchenconsultancy.com/shop")
    }
    func publicationsWebview(){
        webview_title.text = "Publications"
        webViewLoad(url: "https://eastchenconsultancy.com/shop")
    }
    func eventsWebview(){
        webview_title.text = "Events"
        webViewLoad(url: "https://eastchenconsultancy.com/feng-shui-event/")
    }
    func virtualClassroomWebview(){
        webview_title.text = "Virtual Classroom"
        webViewLoad(url: "https://school.eastchenconsultancy.com/")
    }
    func facebookWebview(){
        webview_title.text = "Facebook"
        webViewLoad(url: "https://facebook.com/ecconsultancy")
    }
    func baziCalcWebview(){
        webview_title.text = "Bazi Calc"
        webViewLoad(url: "https://eastchenconsultancy.com/professional-bazi-calculator/")
    }
    
    func pro_baziWebview(){
        webview_title.text = "Pro Bazi Calc"
        webViewLoad(url: "https://eastchenconsultancy.com/professional-bazi-calculator/")
    }
   
    func checkoutWebview(){
        webview_title.text = "Checkout"
        webViewLoad(url: "https://eastchenconsultancy.com/cart-2/")
    }
    
    func myCartWebview(){
        webview_title.text = "MyCart"
        webViewLoad(url: "https://eastchenconsultancy.com/cart-2/")
    }
    
    func wishlistWebview(){
        webview_title.text = "Wishlist"
//        webViewLoad(url: "https://eastchenconsultancy.com/about-east-chen/")
    }
    
    func aboutUsWebview(){
        webview_title.text = "AboutUs"
        webViewLoad(url: "https://eastchenconsultancy.com/about-east-chen/")
    }
    
    func signinWebview(){
        webview_title.text = "Sign in"
        webViewLoad(url: "https://eastchenconsultancy.com/register-3/")
    }
    
    
    
    func webViewDidStartLoad(_ webView: UIWebView) {
        activity.startAnimating()
    }
    
    func webViewDidFinishLoad(_ webView: UIWebView) {
        activity.stopAnimating()
    }
    
    func webView(_ webView: UIWebView, didFailLoadWithError error: Error) {
        activity.stopAnimating()
    }

}
