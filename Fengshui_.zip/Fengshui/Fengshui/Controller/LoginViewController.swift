//
//  LoginViewController.swift
//  Fengshui
//
//  Created by Liu Jie on 11/7/18.
//  Copyright © 2018 fullstackcoach123. All rights reserved.
//

import UIKit
import Firebase

class LoginViewController: BaseViewController, UIImagePickerControllerDelegate, UINavigationControllerDelegate {
    
    @IBOutlet weak var inputsContainerView: UIView!
    @IBOutlet weak var loginRegisterButton: UIButton!
    @IBOutlet weak var nameTextField: UITextField!
    @IBOutlet weak var emailTextField: UITextField!
    @IBOutlet weak var passwordTextField: UITextField!
    @IBOutlet weak var segmentedControl: UISegmentedControl!
    @IBOutlet weak var activity: UIActivityIndicatorView!
    @IBOutlet weak var profileImageView: UIButton!
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        self.initialization()
        
    }
    
    func initialization(){
        self.loginRegisterButton.frame.size.height = 40
        self.segmentedControl.frame.size.height = 30
        self.nameTextField.borderStyle = UITextBorderStyle.roundedRect
        self.emailTextField.borderStyle = UITextBorderStyle.roundedRect
        self.passwordTextField.borderStyle = UITextBorderStyle.roundedRect
        self.nameTextField.layer.borderWidth = 1
        self.emailTextField.layer.borderWidth = 0.5
        self.passwordTextField.layer.borderWidth = 1
        self.profileImageView.layer.cornerRadius = 75
        self.profileImageView.clipsToBounds = true
    }
    
    @IBAction func profileImageView_clicked(_ sender: UIButton) {
        let picker = UIImagePickerController()
        
        picker.delegate = self
        picker.allowsEditing = true
        
        present(picker, animated: true, completion: nil)
    }
    
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [String : Any]) {
        
        var selectedImageFromPicker: UIImage?
        
        if let editedImage = info["UIImagePickerControllerEditedImage"] as? UIImage {
            selectedImageFromPicker = editedImage
        } else if let originalImage = info["UIImagePickerControllerOriginalImage"] as? UIImage {
            selectedImageFromPicker = originalImage
        }
        
        if let selectedImage = selectedImageFromPicker {
            profileImageView.setBackgroundImage(selectedImage, for: .normal)
        }
        
        dismiss(animated: true, completion: nil)
    }
    
    func imagePickerControllerDidCancel(_ picker: UIImagePickerController) {
        dismiss(animated: true, completion: nil)
        print("canceled picker")
    }
    
    
    
    
    @IBAction func handleLoginRegisterChange(_ sender: UISegmentedControl) {
        self.textFieldInit()
        
        let title = segmentedControl.titleForSegment(at: segmentedControl.selectedSegmentIndex)
        self.loginRegisterButton.setTitle(title, for: .normal)
        
        //change the height of inputContainerView
        if segmentedControl.selectedSegmentIndex == 0 {
            nameTextField.isUserInteractionEnabled = false
            nameTextField.backgroundColor = UIColor.lightGray
        } else{
            nameTextField.isUserInteractionEnabled = true
            nameTextField.backgroundColor = UIColor.white
        }
    }
    
    
    
    
    func textFieldInit(){
        self.nameTextField.text?.removeAll()
        self.emailTextField.text?.removeAll()
        self.passwordTextField.text?.removeAll()
        self.nameTextField.layer.borderColor = UIColor.black.cgColor
        self.emailTextField.layer.borderColor = UIColor.black.cgColor
        self.passwordTextField.layer.borderColor = UIColor.black.cgColor
    }
    

    @IBAction func loginRegister_clicked(_ sender: UIButton) {
        activity.startAnimating()
        if self.segmentedControl.selectedSegmentIndex == 0{
            self.handleLogin()
        }
        else{
            self.handleRegister()
        }
    }
    
    func handleLogin(){
        let email = emailTextField.text
        let password = passwordTextField.text
        Auth.auth().signIn(withEmail: email!, password: password!) { (user, error) in
            self.activity.stopAnimating()
            if error != nil {
                let alert = UIAlertController(title: "Alert", message: error?.localizedDescription, preferredStyle: UIAlertControllerStyle.alert)
                alert.addAction(UIAlertAction(title: "Okay", style: UIAlertActionStyle.default, handler: nil))
                self.present(alert, animated: true, completion: nil)
                print("error--------------", error?.localizedDescription)
                self.activity.stopAnimating()
            } else {
                self.appDelegate.makingRoot("gotoMain")
            }
//            self.checkIfUserIsLoggedIn()
            
        }
    }
    
    func checkIfUserIsLoggedIn(){
        let uid = Auth.auth().currentUser?.uid
        Database.database().reference().child("users").child(uid!).observeSingleEvent(of: .value, with:{ (DataSnapshot) in
            
            if let dictionary = DataSnapshot.value as? NSDictionary {
                self.appDelegate.loggedin_user = User(dictionary)
                self.appDelegate.makingRoot("gotoMain")
            }
        }, withCancel: nil)
    }
    
    func handleRegister(){
        let name = nameTextField.text
        let email = emailTextField.text
        let password = passwordTextField.text
        
        
        if name != "" && email != "" && password != "" && (password?.count as! Int >= 6) {
            Auth.auth().createUser(withEmail: email!, password: password!) { (authResult, error) in
                
                if error != nil {
                        let alert = UIAlertController(title: "Alert", message: error?.localizedDescription, preferredStyle: UIAlertControllerStyle.alert)
                        alert.addAction(UIAlertAction(title: "Okay", style: UIAlertActionStyle.default, handler: nil))
                        self.present(alert, animated: true, completion: nil)
                        print("error--------------", error?.localizedDescription)
                        self.activity.stopAnimating()
                } else {
                    guard let user = authResult?.user else {
                        self.activity.stopAnimating()
                        return
                    }
                    
                    guard let uid = authResult?.user.uid else{
                        self.activity.stopAnimating()
                        return
                    }
                    
                    // successfully authenticated user
                    let imageName = NSUUID().uuidString
                    
                    let storageRef = Storage.storage().reference().child("\(imageName).jpg")
                    
                    
                    
                    if let profileImage = self.profileImageView.backgroundImage(for: .normal), let uploadData = UIImageJPEGRepresentation(self.profileImageView.backgroundImage(for: .normal)!, 0.1) {
                        
                        storageRef.putData(uploadData, metadata: nil, completion: {(metadata, error) in
                            
                            if error != nil {
                                print(error)
                                return
                            }
                            
                            storageRef.downloadURL { (url, error) in
                                guard let downloadURL = url else {
                                    // Uh-oh, an error occurred!
                                    return
                                }
                                let URL_String = downloadURL.absoluteString
                                let values = ["name": name, "email": email, "profileImageURL": URL_String] as! [String: AnyObject]
                                self.registerUserIntoDatabaseWithID(uid: uid, values: values)
                            }
                        })
                    }
                }
            }
        } else{
            self.activity.stopAnimating()
            if (name?.isEmpty)!{
                nameTextField.layer.borderColor = UIColor(red: 255/255, green: 0/255, blue: 0/255, alpha: 1).cgColor
            }
            if (email?.isEmpty)!{
                emailTextField.layer.borderColor = UIColor(red: 255/255, green: 0/255, blue: 0/255, alpha: 1).cgColor
            }
            if (password?.isEmpty)!{
                passwordTextField.layer.borderColor = UIColor(red: 255/255, green: 0/255, blue: 0/255, alpha: 1).cgColor
            }
            if !(password?.count as! Int >= 6){
                passwordTextField.layer.borderColor = UIColor(red: 230/255, green: 0/255, blue: 0/255, alpha: 1).cgColor
            }
            
        }
    }
    
    private func registerUserIntoDatabaseWithID(uid: String, values: [String: AnyObject]) {
        let ref = Database.database().reference(fromURL: "https://fengshui-485f5.firebaseio.com/")
        let usersReference = ref.child("users").child(uid)
        
        usersReference.updateChildValues(values, withCompletionBlock: {(err, ref) in
            
            if err != nil{
                print(err)
                return
            }
            self.activity.stopAnimating()
            self.appDelegate.makingRoot("gotoMain")
            print("Saved user successfully into Firebase db")
        })
    }
    
    
}
