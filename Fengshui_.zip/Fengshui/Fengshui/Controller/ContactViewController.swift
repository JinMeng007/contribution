
import UIKit
import MessageUI

class ContactViewController: BaseViewController, MFMailComposeViewControllerDelegate, UIImagePickerControllerDelegate, UIPopoverControllerDelegate, UINavigationControllerDelegate{

    @IBOutlet weak var keyboard_text: UITextField!
    @IBOutlet weak var messageView: UIView!
    
    var picker: UIImagePickerController = UIImagePickerController()
    
    @IBOutlet weak var imageView: UIImageView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        picker.delegate = self
        
        self.messageView.layer.borderWidth = 1
        self.messageView.layer.borderColor = UIColor(red:150/255, green:226/255, blue:126/255, alpha: 1).cgColor
        
//        self.setupMenuBarButton()
//        self.keyboard_text.becomeFirstResponder()
        self.keyboard_text.text?.removeAll()
//         NotificationCenter.default.addObserver(self, selector: #selector(keyboardWillChange(_noti:) ), name: NSNotification.Name.UIKeyboardWillChangeFrame , object: nil)
        // Do any additional setup after loading the view.
    }
    
    override func viewWillAppear(_ animated: Bool) {
//        self.keyboard_text.becomeFirstResponder()
        self.keyboard_text.text?.removeAll()
    }
    
    @IBAction func BackBtn_clicked(_ sender: UIButton) {
      self.navigationController?.popViewController(animated: true)
    }
    
    
    @objc func keyboardWillChange(_noti:NSNotification)
    {
        let keyBoard = _noti.userInfo
        let keyBoardValue = keyBoard![UIKeyboardFrameEndUserInfoKey]
        let fram = keyBoardValue as? CGRect // this is frame
        let keyboard_height = fram?.size.height
//        let keyboard_width = fram?.size.width
        let screen_height = UIScreen.main.bounds.height
        let keyboard_offset_Y = screen_height - keyboard_height!
        messageView.layer.frame.origin.x = 0
        messageView.layer.frame.origin.y = keyboard_offset_Y - 10
    }
    
    @IBAction func sendMessage(_ sender: UIButton) {
        
        
        if MFMailComposeViewController.canSendMail() {
            let mail = MFMailComposeViewController()
            mail.mailComposeDelegate = self
//            mail.setToRecipients(["sales@eastchenconsultancy.com"])
            var emailArr: [String] = []
            emailArr.append("sales@eastchenconsultancy.com")
            mail.setToRecipients(emailArr)
            let text = self.keyboard_text.text
            mail.setMessageBody(text!, isHTML: true)
            
            
            if imageView.image != nil{
                /////
                if let myImage = imageView.image,
                    let myImageData = UIImagePNGRepresentation(myImage){
                    mail.addAttachmentData(myImageData, mimeType: "image/png", fileName: "")
                }
            }

            present(mail, animated: true)
        } else {
            // show failure alert
            let alert = UIAlertController(title: "", message: "Please add your account on your phone. Mail->Google->Confirm. And try again!", preferredStyle: UIAlertControllerStyle.alert)
            alert.addAction(UIAlertAction(title: "OK", style: UIAlertActionStyle.default, handler: nil))
            self.present(alert, animated: true, completion: nil)
        }
    }
    
    func mailComposeController(_ controller: MFMailComposeViewController, didFinishWith result: MFMailComposeResult, error: Error?) {
        controller.dismiss(animated: true)
    }
    @IBAction func camera_contact(_ sender: UIButton) {
        openGallery()
//        openCamera()
    }
    
    func imagePickerControllerDidCancel(_ picker: UIImagePickerController) {
        dismiss(animated: true, completion: nil)
    }
    
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [String : Any]) {
        var chosenImage = info[UIImagePickerControllerOriginalImage] as! UIImage
//        imageView.contentMode = .scaleAspectFit
        imageView.image = chosenImage
        dismiss(animated: true, completion: nil)
    }
    
    func openGallery(){
        picker.allowsEditing = false
        picker.sourceType = UIImagePickerControllerSourceType.photoLibrary
        present(picker, animated: true, completion: nil)
    }
    
    func openCamera()
    {
        if(UIImagePickerController .isSourceTypeAvailable(UIImagePickerControllerSourceType.camera)){
            picker.allowsEditing = false
            picker.sourceType = UIImagePickerControllerSourceType.camera
            picker.cameraCaptureMode = .photo
            present(picker, animated: true, completion: nil)
        }else{
            let alert = UIAlertController(title: "Camera Not Found", message: "This device has no Camera", preferredStyle: .alert)
            let ok = UIAlertAction(title: "OK", style:.default, handler: nil)
            alert.addAction(ok)
            present(alert, animated: true, completion: nil)
        }
    }
    
    
    
    
    
}
