//
//  Variables.swift
//  Fengshui
//
//  Created by Liu Jie on 11/4/18.
//  Copyright © 2018 fullstackcoach123. All rights reserved.
//

import Foundation

var menu_icon_clicked_number = 0
