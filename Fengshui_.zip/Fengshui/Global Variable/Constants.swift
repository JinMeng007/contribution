//
//  Constants.swift
//  Fengshui
//
//  Created by Liu Jie on 11/5/18.
//  Copyright © 2018 fullstackcoach123. All rights reserved.
//

import Foundation
import Firebase

struct Constants{
    struct refs
    {
        static let databaseRoot = Database.database().reference()
        static let databaseChats = databaseRoot.child("chats")
    }
}
