//
//  User.swift
//  Fengshui
//
//  Created by Liu Jie on 11/11/18.
//  Copyright © 2018 fullstackcoach123. All rights reserved.
//

import UIKit

class User {
    
    var id: String?
    var name: String?
    var email: String?
    var profileImageURL: String?
    init?(_ dic: NSDictionary) {
        self.name = dic["name"] as? String
        self.email = dic["email"] as? String
        self.profileImageURL = dic["profileImageURL"] as? String
    }
}
