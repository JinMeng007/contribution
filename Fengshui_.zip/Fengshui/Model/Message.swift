//
//  Message.swift
//  Fengshui
//
//  Created by Liu Jie on 11/12/18.
//  Copyright © 2018 fullstackcoach123. All rights reserved.
//

import UIKit
import Firebase

class Message {
    
    var fromId: String?
    var text: String?
    var timestamp: NSNumber?
    var toId: String?
    
    var imageUrl: String?
    
    var imageHeight: NSNumber?
    var imageWidth: NSNumber?
    
    var videoUrl: String?
    
    init?(_ dic: NSDictionary) {
        self.fromId = dic["fromId"] as? String
        self.text = dic["text"] as? String
        self.timestamp = dic["timestamp"] as? NSNumber
        self.toId = dic["toId"] as? String
        
        self.imageUrl = dic["imageUrl"] as? String
        
        self.videoUrl = dic["videoUrl"] as? String
        self.imageHeight = dic["imageHeight"] as? NSNumber
        self.imageWidth = dic["imageWidth"] as? NSNumber
    }
    
    func chatPartnerId() -> String? {
        
        return fromId == Auth.auth().currentUser?.uid ? toId : fromId
        
    }
}
