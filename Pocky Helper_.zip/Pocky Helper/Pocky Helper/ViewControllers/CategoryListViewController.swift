//
//  CategoryListViewController.swift
//  Pocky Helper
//
//  Created by Ashish on 09/04/19.
//  Copyright © 2019 Ashish. All rights reserved.
//

import UIKit
import RealmSwift

class CategoryListViewController: BasicViewController {

    @IBOutlet weak var tblView: UITableView!
    
    @IBOutlet weak var segment: UISegmentedControl!
    
    let realm = try! Realm()
    var arrIncomeCateList = [CategoryModel]()
    var arrExpenceCateList = [ExpenceCategoryModel]()
    var selectedSegmentIndex = 0
    
    override func viewDidLoad() {
        super.viewDidLoad()
        setUI()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        setNavigation()
    }

    // MARK: - Custom Methods
    
    func setUI()
    {
        arrIncomeCateList = Array(realm.objects(CategoryModel.self))
        arrExpenceCateList = Array(realm.objects(ExpenceCategoryModel.self))
        
        tblView.register(UINib(nibName: "CategoryTableViewCell", bundle: nil), forCellReuseIdentifier: "CategoryTableViewCell")
        tblView.tableFooterView = UIView()
        tblView.reloadData()
    }
    
    func setNavigation()
    {
        navigationController?.setNavigationBarHidden(false, animated: false)
        setNavigationTitle(str: "Category")
        setBackButtonNavigation()
        setAddTaskButtonNavigation()
        pressButtonOnNavigaion { (flag) in
            if(!flag){
                self.navigationController?.popViewController(animated: true)
            }
            else
            {
                let alertController = UIAlertController(title: "Add new Cateogry", message: nil, preferredStyle: .alert)
                let confirmAction = UIAlertAction(title: "Add", style: .default) { (_) in
                    if let txtField = alertController.textFields?.first, let text = txtField.text {
                        try? self.realm.write {
                            if(self.selectedSegmentIndex == 0)
                            {
                                let model = CategoryModel()
                                model.setData([
                                    "id" : "\(UUID().uuidString)" as AnyObject,
                                    "categoryName" : text as AnyObject
                                    ])
                                self.realm.add(model)
                                self.arrIncomeCateList.append(model)
                            }
                            else
                            {
                                let model = ExpenceCategoryModel()
                                model.setData([
                                    "id" : "\(UUID().uuidString)" as AnyObject,
                                    "categoryName" : text as AnyObject
                                    ])
                                self.realm.add(model)
                                self.arrExpenceCateList.append(model)
                            }
                        }
                        self.tblView.reloadData()
                    }
                }
                let cancelAction = UIAlertAction(title: "Cancel", style: .cancel) { (_) in }
                alertController.addTextField { (textField) in
                    textField.placeholder = "Category Name"
                }
                alertController.addAction(confirmAction)
                alertController.addAction(cancelAction)
                self.present(alertController, animated: true, completion: nil)
            }
        }
    }
    
    @IBAction func segmentValueChanged(_ sender: UISegmentedControl) {
        selectedSegmentIndex = sender.selectedSegmentIndex
        if(sender.selectedSegmentIndex == 0)
        {
            arrIncomeCateList = Array(realm.objects(CategoryModel.self))
        }
        else
        {
            arrExpenceCateList = Array(realm.objects(ExpenceCategoryModel.self))
        }
        self.tblView.reloadData()
    }

}

extension CategoryListViewController : UITableViewDelegate, UITableViewDataSource
{
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return selectedSegmentIndex == 0 ? arrIncomeCateList.count : arrExpenceCateList.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "CategoryTableViewCell", for: indexPath) as! CategoryTableViewCell
        
        if(selectedSegmentIndex == 0)
        {
            let model = self.arrIncomeCateList[indexPath.row]
            cell.lblName.text = model.categoryName
        }
        else
        {
            let model = self.arrExpenceCateList[indexPath.row]
            cell.lblName.text = model.categoryName
        }
        
        return cell
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 44
    }
    
    func tableView(_ tableView: UITableView, canEditRowAt indexPath: IndexPath) -> Bool {
        return true
    }
    
    func tableView(_ tableView: UITableView, editActionsForRowAt indexPath: IndexPath) -> [UITableViewRowAction]? {
        
        let model = self.selectedSegmentIndex == 0 ? self.arrIncomeCateList[indexPath.row] : self.arrExpenceCateList[indexPath.row]
        
        let btn1 = UITableViewRowAction(style: .normal, title: "Delete") { (rowAction, indexPath) in
            let alert = UIAlertController(title: "Pocky Helper", message: "Are you sure you want to delete this Category?", preferredStyle: .alert)
            alert.addAction(UIAlertAction(title: "Cancel", style: .cancel, handler: nil))
            
            alert.addAction(UIAlertAction(title: "Ok", style: .default, handler: { action in
                try? self.realm.write {
                    self.realm.delete(model)
                }
                if(self.selectedSegmentIndex == 0)
                {
                    self.arrIncomeCateList = Array(self.realm.objects(CategoryModel.self))
                }
                else
                {
                    self.arrExpenceCateList = Array(self.realm.objects(ExpenceCategoryModel.self))
                }
                self.tblView.reloadData()
            }))
            
            self.present(alert, animated: true)
        }
        btn1.backgroundColor = UIColor.red
        
        return [btn1]
    }
    
}
