//
//  ChartViewController.swift
//  Pocky Helper
//
//  Created by Ashish on 09/04/19.
//  Copyright © 2019 Ashish. All rights reserved.
//

import UIKit
import CSPieChart
import RealmSwift

class ChartViewController: BasicViewController {
    
    @IBOutlet weak var pieChart: CSPieChart!
    @IBOutlet weak var segment: UISegmentedControl!
    
    @IBOutlet weak var lblNoDataFound: UILabel!
    
    let realm = try! Realm()
    var arrIncomeList = [IncomeModel]()
    var arrExpenceList = [ExpenceModel]()
    var selectedSegmentIndex = 0
    
    var dataList = [CSPieChartData]()
    
    var colorList: [UIColor] = [
        .red,
        .orange,
        .yellow,
        .green,
        .blue,
        .magenta
    ]
    
    override func viewDidLoad() {
        super.viewDidLoad()
        setUI()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        setNavigation()
    }

    // MARK: - Custom Methods
    
    func setUI()
    {
        arrIncomeList = Array(realm.objects(IncomeModel.self))
        arrExpenceList = Array(realm.objects(ExpenceModel.self))
        setChart()
    }
    
    func setNavigation()
    {
        navigationController?.setNavigationBarHidden(false, animated: false)
        setNavigationTitle(str: "Chart")
        setBackButtonNavigation()
        pressButtonOnNavigaion { (flag) in
            if(!flag){
                self.navigationController?.popViewController(animated: true)
            }
        }
    }
    
    func setChart()
    {
        dataList.removeAll()
        if(self.selectedSegmentIndex == 0)
        {
            for i in 0 ..< self.arrIncomeList.count
            {
                self.dataList.append(CSPieChartData(key: self.arrIncomeList[i].incomeName!, value: Double(self.arrIncomeList[i].incomeAmount!)!))
            }
        }
        else
        {
            for i in 0 ..< self.arrExpenceList.count
            {
                self.dataList.append(CSPieChartData(key: self.arrExpenceList[i].expenceName!, value: Double(self.arrExpenceList[i].expenceAmount!)!))
            }
        }
        
        pieChart?.dataSource = self
        pieChart?.delegate = self
        
        pieChart?.pieChartRadiusRate = 0.5
        pieChart?.pieChartLineLength = 12
        pieChart?.seletingAnimationType = .touch
        
        pieChart?.show(animated: true)
        pieChart.reloadPieChart()
        
        self.lblNoDataFound.isHidden = self.dataList.count == 0 ? false : true
    }
    
    @IBAction func segmentValueChanged(_ sender: UISegmentedControl) {
        selectedSegmentIndex = sender.selectedSegmentIndex
        setChart()
    }

}

extension ChartViewController: CSPieChartDataSource, CSPieChartDelegate {
    
    func numberOfComponentData() -> Int {
        return dataList.count
    }
    
    func pieChart(_ pieChart: CSPieChart, dataForComponentAt index: Int) -> CSPieChartData {
        return dataList[index]
    }
    
    func numberOfComponentColors() -> Int {
        return colorList.count
    }
    
    func pieChart(_ pieChart: CSPieChart, colorForComponentAt index: Int) -> UIColor {
        return colorList[index]
    }
    
    func numberOfLineColors() -> Int {
        return colorList.count
    }
    
    func pieChart(_ pieChart: CSPieChart, lineColorForComponentAt index: Int) -> UIColor {
        return colorList[index]
    }
    
    func numberOfComponentSubViews() -> Int {
        return dataList.count
    }
    
    func pieChart(_ pieChart: CSPieChart, viewForComponentAt index: Int) -> UIView {
        let view = UILabel(frame: CGRect(x: 0, y: 0, width: 85, height: 50))
        view.numberOfLines = 0
        view.font = UIFont.systemFont(ofSize: 10)
        view.text = self.dataList[index].key
        return view
    }
    
    func pieChart(_ pieChart: CSPieChart, didSelectComponentAt index: Int) {
        let data = dataList[index]
        print(data.key)
    }
}
