//
//  IncomeListViewController.swift
//  Pocky Helper
//
//  Created by Ashish on 09/04/19.
//  Copyright © 2019 Ashish. All rights reserved.
//

import UIKit
import RealmSwift

class IncomeListViewController: BasicViewController {

    @IBOutlet weak var tblView: UITableView!
    @IBOutlet weak var lblNoDataFound: UILabel!
    
    let appDelegate = UIApplication.shared.delegate as! AppDelegate
    let realm = try! Realm()
    var arrIncomeList = [IncomeModel]()
    var arrExpenceList = [ExpenceModel]()
    
    var typeIndex : Int! = 0
    
    override func viewDidLoad() {
        super.viewDidLoad()
        setUI()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        setNavigation()
        arrIncomeList = Array(realm.objects(IncomeModel.self))
        arrExpenceList = Array(realm.objects(ExpenceModel.self))
        
        arrIncomeList = arrIncomeList.sorted { (lhsData, rhsData) -> Bool in
            return lhsData.insertDate! > rhsData.insertDate!
        }
        arrExpenceList = arrExpenceList.sorted { (lhsData, rhsData) -> Bool in
                return lhsData.insertDate! > rhsData.insertDate!
        }
        
        tblView.reloadData()
    }

    // MARK: - Custom Methods
    
    func setUI()
    {
        tblView.register(UINib(nibName: "IncomeListTableViewCell", bundle: nil), forCellReuseIdentifier: "IncomeListTableViewCell")
        tblView.tableFooterView = UIView()
    }
    
    func setNavigation()
    {
        navigationController?.setNavigationBarHidden(false, animated: false)
        setNavigationTitle(str: typeIndex == 0 ? "Income List" : "Expence List")
        setBackButtonNavigation()
        setAddTaskButtonNavigation()
        pressButtonOnNavigaion { (flag) in
            if(!flag){
                self.navigationController?.popViewController(animated: true)
            }
            else
            {
                let vc = AddIncomeViewController()
                vc.typeIndex = self.typeIndex
                self.navigationController?.pushViewController(vc, animated: true)
            }
        }
    }

}

extension IncomeListViewController : UITableViewDelegate, UITableViewDataSource
{
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if(self.typeIndex == 0)
        {
            self.lblNoDataFound.isHidden = self.arrIncomeList.count == 0 ? false : true
            self.tblView.isHidden = !self.lblNoDataFound.isHidden
        }
        else
        {
            self.lblNoDataFound.isHidden = self.arrExpenceList.count == 0 ? false : true
            self.tblView.isHidden = !self.lblNoDataFound.isHidden
        }
        return self.typeIndex == 0 ? arrIncomeList.count : arrExpenceList.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "IncomeListTableViewCell", for: indexPath) as! IncomeListTableViewCell
        
        if(self.typeIndex == 0)
        {
            let model = self.arrIncomeList[indexPath.row]
            
            cell.lblCateName.text = model.categoryName
            cell.lblIncome.text = model.incomeName
            cell.lblAmt.text = model.incomeAmount! + "$"
            cell.lblDesc.text = model.desc
            cell.lblDate.text = appDelegate.getCurrentStringDateFromUTCDate(date: model.insertDate, format: "dd MMMM, yyyy 'at' h:mm a")
        }
        else
        {
            let model = self.arrExpenceList[indexPath.row]
            
            cell.lblCateName.text = model.categoryName
            cell.lblIncome.text = model.expenceName
            cell.lblAmt.text = model.expenceAmount! + "$"
            cell.lblDesc.text = model.desc
            cell.lblDate.text = appDelegate.getCurrentStringDateFromUTCDate(date: model.insertDate, format: "dd MMMM, yyyy 'at' h:mm a")
        }
        
        cell.selectionStyle = .none
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let vc = AddIncomeViewController()
        vc.isEditMode = true
        vc.typeIndex = self.typeIndex
        if(self.typeIndex == 0)
        {
            vc.currentIncomeModel = self.arrIncomeList[indexPath.row]
        }
        else
        {
            vc.currentExpenceModel = self.arrExpenceList[indexPath.row]
        }
        self.navigationController?.pushViewController(vc, animated: true)
    }
    
    func tableView(_ tableView: UITableView, estimatedHeightForRowAt indexPath: IndexPath) -> CGFloat {
        return 120
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return UITableView.automaticDimension
    }
    
    func tableView(_ tableView: UITableView, canEditRowAt indexPath: IndexPath) -> Bool {
        return true
    }
    
    func tableView(_ tableView: UITableView, editActionsForRowAt indexPath: IndexPath) -> [UITableViewRowAction]? {
        
        let model = self.typeIndex == 0 ? self.arrIncomeList[indexPath.row] : self.arrExpenceList[indexPath.row]
        
        let btn1 = UITableViewRowAction(style: .normal, title: "Delete") { (rowAction, indexPath) in
            
            let alert = UIAlertController(title: "Pocky Helper", message: "Are you sure you want to delete this \(self.typeIndex == 0 ? "Income" : "Expence")?", preferredStyle: .alert)
            alert.addAction(UIAlertAction(title: "Cancel", style: .cancel, handler: nil))
            
            alert.addAction(UIAlertAction(title: "Ok", style: .default, handler: { action in
                try? self.realm.write {
                    self.realm.delete(model)
                }
                if(self.typeIndex == 0)
                {
                    self.arrIncomeList = Array(self.realm.objects(IncomeModel.self))
                }
                else
                {
                    self.arrExpenceList = Array(self.realm.objects(ExpenceModel.self))
                }
                self.tblView.reloadData()
            }))
            
            self.present(alert, animated: true)
        }
        btn1.backgroundColor = UIColor.red
        
        return [btn1]
    }
    
}
