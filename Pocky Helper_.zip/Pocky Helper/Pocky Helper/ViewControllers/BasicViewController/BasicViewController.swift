//
//  BasicViewController.swift
//  Pocky Helper
//
//  Created by Ashish on 09/04/19.
//  Copyright © 2019 Ashish. All rights reserved.
//

import UIKit

class BasicViewController: UIViewController {
    
    typealias completionBlock = (_ isCartButton:Bool)->()
    typealias completionMenuBlock = ()->()
    var btnClickBlock : completionBlock!
    var strNextTital : String!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        navigationController?.setNavigationBarHidden(false, animated: false)
    }
    
    func setBackButtonNavigation() {
        self.navigationController?.navigationBar.isHidden = false
        let btn = UIButton(type: .custom)
        btn.setImage(UIImage(named: "ic_back"), for: .normal)
        btn.frame = CGRect(x: -10, y: 0, width: 40, height: 40)
        btn.showsTouchWhenHighlighted = true
        btn.addTarget(self, action: #selector(self.btnLeft_Click), for: .touchUpInside)
        let leftBarButtonItems = UIView(frame: CGRect(x: 0, y: 0, width: 50, height: 40))
        leftBarButtonItems.addSubview(btn)
        navigationItem.leftBarButtonItem = UIBarButtonItem(customView: leftBarButtonItems)
    }
    
    func setAddTaskButtonNavigation() {
        self.navigationController?.navigationBar.isHidden = false
        let btn = UIButton(type: .custom)
        btn.setImage(UIImage(named: "ic_plus"), for: .normal)
        btn.frame = CGRect(x: 14, y: 0, width: 40, height: 40)
        btn.showsTouchWhenHighlighted = true
        btn.addTarget(self, action: #selector(self.btnRight_Click), for: .touchUpInside)
        let leftBarButtonItems = UIView(frame: CGRect(x: 0, y: 0, width: 50, height: 40))
        leftBarButtonItems.addSubview(btn)
        navigationItem.rightBarButtonItem = UIBarButtonItem(customView: leftBarButtonItems)
    }
    
    func setClearAllButtonNavigation() {
        self.navigationController?.navigationBar.isHidden = false
        let btn = UIButton(type: .custom)
        btn.setImage(UIImage(named: "ic_clear"), for: .normal)
        btn.frame = CGRect(x: 14, y: 0, width: 40, height: 40)
        btn.showsTouchWhenHighlighted = true
        btn.addTarget(self, action: #selector(self.btnRight_Click), for: .touchUpInside)
        let leftBarButtonItems = UIView(frame: CGRect(x: 0, y: 0, width: 50, height: 40))
        leftBarButtonItems.addSubview(btn)
        navigationItem.rightBarButtonItem = UIBarButtonItem(customView: leftBarButtonItems)
    }
    
    @IBAction func btnLeft_Click(_ sender: Any) {
        self.btnClickBlock(false)
    }
    
    @IBAction func btnRight_Click(_ sender: Any) {
        self.btnClickBlock(true)
    }
    
    func setNavigationTitle(str:String) {
        self.title = str
    }
    
    func pressButtonOnNavigaion(completion : @escaping completionBlock) {
        btnClickBlock = completion
    }
    
}

