//
//  AddIncomeViewController.swift
//  Pocky Helper
//
//  Created by Ashish on 10/04/19.
//  Copyright © 2019 Ashish. All rights reserved.
//

import UIKit
import RealmSwift

class AddIncomeViewController: BasicViewController {

    @IBOutlet weak var btnCategory: UIButton!
    @IBOutlet weak var txtTitle: UITextField!
    @IBOutlet weak var txtAmount: UITextField!
    @IBOutlet weak var txtView: UITextView!
    
    @IBOutlet weak var tblView: UITableView!
    @IBOutlet weak var tblViewHeight: NSLayoutConstraint!
    
    @IBOutlet weak var btnAdd: UIButton!
    
    @IBOutlet var viewCollection: [UIView]!
    
    let realm = try! Realm()
    var arrIncomeCateList = [CategoryModel]()
    var arrExpCateList = [ExpenceCategoryModel]()
    
    var isEditMode : Bool! = false
    var currentIncomeModel : IncomeModel!
    var currentExpenceModel : ExpenceModel!
    var selectedCategoryModel = CategoryModel()
    var selectedExpCategoryModel = ExpenceCategoryModel()
    
    var typeIndex : Int! = 0
    
    override func viewDidLoad() {
        super.viewDidLoad()
        setUI()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        setNavigation()
    }
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        self.tblViewHeight.constant = self.arrIncomeCateList.count < 4 ? self.tblView.contentSize.height : 160
    }
    
    // MARK: - Custom Methods
    
    func setUI()
    {
        btnAdd.layer.cornerRadius = 20
        
        for view in viewCollection
        {
            view.layer.cornerRadius = 5.0
        }
        
        arrIncomeCateList = Array(realm.objects(CategoryModel.self))
        arrExpCateList = Array(realm.objects(ExpenceCategoryModel.self))
        
        tblView.register(UINib(nibName: "CategoryTableViewCell", bundle: nil), forCellReuseIdentifier: "CategoryTableViewCell")
        tblView.tableFooterView = UIView()
        tblView.reloadData()
        tblView.layer.cornerRadius = 5.0
        tblView.layer.borderWidth = 1.0
        tblView.layer.borderColor = UIColor.lightGray.cgColor
        tblView.clipsToBounds = true
        
        if(isEditMode)
        {
            if(self.typeIndex == 0)
            {
                txtTitle.text = currentIncomeModel.incomeName
                txtAmount.text = currentIncomeModel.incomeAmount
                txtView.text = currentIncomeModel.desc
                
                selectedCategoryModel.id = currentIncomeModel.id
                selectedCategoryModel.categoryName = currentIncomeModel.categoryName
                btnCategory.setTitle(currentIncomeModel.categoryName, for: .normal)
            }
            else
            {
                txtTitle.text = currentExpenceModel.expenceName
                txtAmount.text = currentExpenceModel.expenceAmount
                txtView.text = currentExpenceModel.desc
                
                selectedExpCategoryModel.id = currentExpenceModel.id
                selectedExpCategoryModel.categoryName = currentExpenceModel.categoryName
                btnCategory.setTitle(selectedExpCategoryModel.categoryName, for: .normal)
            }
            
            btnAdd.setTitle("Update", for: .normal)
        }
    }
    
    func setNavigation()
    {
        navigationController?.setNavigationBarHidden(false, animated: false)
        setNavigationTitle(str: self.typeIndex == 0 ? "Add Income" : "Add Expence")
        setBackButtonNavigation()
        pressButtonOnNavigaion { (flag) in
            if(!flag){
                self.navigationController?.popViewController(animated: true)
            }
        }
    }
    

    // MARK: - Buttton Action
    
    @IBAction func btnActionCategory(_ sender: UIButton) {
        self.tblView.isHidden = false
    }
    
    @IBAction func btnActionAdd(_ sender: UIButton) {
        if(textFieldValidation() == "")
        {
            if(self.typeIndex == 0)
            {
                try? realm.write {
                    if(!isEditMode)
                    {
                        let model = IncomeModel()
                        model.setData([
                            "id" : "\(UUID().uuidString)" as AnyObject,
                            "incomeName" : self.txtTitle.text! as AnyObject,
                            "incomeAmount" : self.txtAmount.text! as AnyObject,
                            "categoryId" : selectedCategoryModel.id as AnyObject,
                            "categoryName" : self.btnCategory.title(for: .normal) as AnyObject,
                            "desc" : self.txtView.text as AnyObject,
                            "insertDate" : Date() as AnyObject,
                            ])
                        realm.add(model)
                    }
                    else
                    {
                        currentIncomeModel.incomeName = self.txtTitle.text!
                        currentIncomeModel.incomeAmount = self.txtAmount.text!
                        currentIncomeModel.categoryId = selectedCategoryModel.id
                        currentIncomeModel.categoryName = self.btnCategory.title(for: .normal)
                        currentIncomeModel.desc = self.txtView.text!
                        realm.add(currentIncomeModel, update: true)
                    }
                }
            }
            else
            {
                try? realm.write {
                    if(!isEditMode)
                    {
                        let model = ExpenceModel()
                        model.setData([
                            "id" : "\(UUID().uuidString)" as AnyObject,
                            "expenceName" : self.txtTitle.text! as AnyObject,
                            "expenceAmount" : self.txtAmount.text! as AnyObject,
                            "categoryId" : selectedCategoryModel.id as AnyObject,
                            "categoryName" : self.btnCategory.title(for: .normal) as AnyObject,
                            "desc" : self.txtView.text as AnyObject,
                            "insertDate" : Date() as AnyObject,
                            ])
                        realm.add(model)
                    }
                    else
                    {
                        currentExpenceModel.expenceName = self.txtTitle.text!
                        currentExpenceModel.expenceAmount = self.txtAmount.text!
                        currentExpenceModel.categoryId = selectedCategoryModel.id
                        currentExpenceModel.categoryName = self.btnCategory.title(for: .normal)
                        currentExpenceModel.desc = self.txtView.text!
                        realm.add(currentExpenceModel, update: true)
                    }
                }
            }
        }
        else
        {
            showAlert(textFieldValidation())
        }
        self.navigationController?.popViewController(animated: true)
    }
    
    //MARK: - Validation
    
    func textFieldValidation() -> String!
    {
        var strMsg = ""
        
        if(btnCategory.title(for: .normal) == "Select Category")
        {
            strMsg = "Please Select the Category."
        }
        else if(txtTitle.text! == "")
        {
            strMsg = "Please enter the Title."
        }
        else if(txtView.text! == "")
        {
            strMsg = "Please enter the Description."
        }
        return strMsg
    }
    
    func showAlert(_ message : String!)
    {
        let alert = UIAlertController(title: "Pocky Helper", message: message, preferredStyle: .alert)
//        alert.addAction(UIAlertAction(title: "Cancel", style: .cancel, handler: nil))
        
        alert.addAction(UIAlertAction(title: "Ok", style: .default, handler: { action in
        }))
        
        self.present(alert, animated: true)
    }

}

extension AddIncomeViewController : UITableViewDelegate, UITableViewDataSource
{
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return self.typeIndex == 0 ? arrIncomeCateList.count : arrExpCateList.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "CategoryTableViewCell", for: indexPath) as! CategoryTableViewCell
        
        if(self.typeIndex == 0 )
        {
            let model = self.arrIncomeCateList[indexPath.row]
            cell.lblName.text = model.categoryName
        }
        else
        {
            let model = self.arrExpCateList[indexPath.row]
            cell.lblName.text = model.categoryName
        }
        
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        if(self.typeIndex == 0 )
        {
            selectedCategoryModel = self.arrIncomeCateList[indexPath.row]
            self.btnCategory.setTitle(self.arrIncomeCateList[indexPath.row].categoryName, for: .normal)
        }
        else
        {
            selectedExpCategoryModel = self.arrExpCateList[indexPath.row]
            self.btnCategory.setTitle(self.arrExpCateList[indexPath.row].categoryName, for: .normal)
        }
        self.tblView.isHidden = true
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 40
    }
    
}
