//
//  ViewController.swift
//  Pocky Helper
//
//  Created by Ashish on 09/04/19.
//  Copyright © 2019 Ashish. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var homeCollectionView: UICollectionView!
    
    var arrHomeList : [[String : AnyObject]] = [
        [
            "title" : "My Income List" as AnyObject,
            "image" : UIImage(named: "ic_incomeList") as AnyObject
        ],
        [
            "title" : "My Expence List" as AnyObject,
            "image" : UIImage(named: "ic_expencelist") as AnyObject
        ],
        [
            "title" : "Add Income" as AnyObject,
            "image" : UIImage(named: "lc_add_income") as AnyObject
        ],
        [
            "title" : "Add Expence" as AnyObject,
            "image" : UIImage(named: "ic_add_expence") as AnyObject
        ],
        [
            "title" : "Add Category" as AnyObject,
            "image" : UIImage(named: "ic_category") as AnyObject
        ],
        [
            "title" : "Track My Budget" as AnyObject,
            "image" : UIImage(named: "ic_track") as AnyObject
        ]
    ]
    
    override func viewDidLoad() {
        super.viewDidLoad()
        setUI()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(true)
        navigationController?.setNavigationBarHidden(true, animated: false)
    }

    func setUI()
    {
        homeCollectionView.register(UINib(nibName: "HomeCollectionViewCell", bundle: nil), forCellWithReuseIdentifier: "HomeCollectionViewCell")
        homeCollectionView.reloadData()
    }

}

extension ViewController : UICollectionViewDelegate, UICollectionViewDataSource, UICollectionViewDelegateFlowLayout
{
    func numberOfSections(in collectionView: UICollectionView) -> Int {
        return 1
    }
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return 6
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "HomeCollectionViewCell", for: indexPath) as! HomeCollectionViewCell
        
        let model = self.arrHomeList[indexPath.row]
        
        cell.lblTitle.text = model["title"]!.description
        cell.imgImage.image = model["image"] as? UIImage
        
        return cell
    }
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        switch indexPath.row {
        case 0:
            let vc = IncomeListViewController()
            self.navigationController?.pushViewController(vc, animated: true)
            break
        case 1:
            let vc = IncomeListViewController()
            vc.typeIndex = 1
            self.navigationController?.pushViewController(vc, animated: true)
            break
        case 2:
            let vc = AddIncomeViewController()
            self.navigationController?.pushViewController(vc, animated: true)
            break
        case 3:
            let vc = AddIncomeViewController()
            vc.typeIndex = 1
            self.navigationController?.pushViewController(vc, animated: true)
            break
        case 4:
            let vc = CategoryListViewController()
            self.navigationController?.pushViewController(vc, animated: true)
            break
        default:
            let vc = ChartViewController()
            self.navigationController?.pushViewController(vc, animated: true)
            break
        }
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        if(UIScreen.main.bounds.size.height <= 568)
        {
            return CGSize(width: collectionView.frame.size.width / 2 - 30, height: 140)
        }
        else
        {
            return CGSize(width: collectionView.frame.size.width / 2 - 30, height: 160)
        }
    }
    
}

