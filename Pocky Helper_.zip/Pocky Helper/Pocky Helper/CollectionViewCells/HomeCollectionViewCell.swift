//
//  HomeCollectionViewCell.swift
//  Pocky Helper
//
//  Created by Ashish on 09/04/19.
//  Copyright © 2019 Ashish. All rights reserved.
//

import UIKit

class HomeCollectionViewCell: UICollectionViewCell {

    @IBOutlet weak var imgImage: UIImageView!
    @IBOutlet weak var lblTitle: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

}
