//
//  HistoryModel.swift
//  Pocky Helper
//
//  Created by Ashish on 09/04/19.
//  Copyright © 2019 Ashish. All rights reserved.
//

import Foundation
import RealmSwift

class CategoryModel: Object {
    @objc dynamic var id: String? = ""
    @objc dynamic var categoryName: String? = ""
    
    override static func primaryKey() -> String? {
        return "id"
    }
    
    func setData(_ dic : [String : AnyObject])
    {
        id = dic["id"]?.description
        categoryName = dic["categoryName"]?.description
    }
    
}

