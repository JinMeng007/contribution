//
//  HistoryModel.swift
//  Pocky Helper
//
//  Created by Ashish on 09/04/19.
//  Copyright © 2019 Ashish. All rights reserved.
//

import Foundation
import RealmSwift

class ExpenceModel: Object {
    @objc dynamic var id: String? = ""
    @objc dynamic var expenceName: String? = ""
    @objc dynamic var expenceAmount: String? = ""
    @objc dynamic var categoryId: String? = ""
    @objc dynamic var categoryName: String? = ""
    @objc dynamic var desc: String? = ""
    @objc dynamic var insertDate: Date?
    
    override static func primaryKey() -> String? {
        return "id"
    }
    
    func setData(_ dic : [String : AnyObject])
    {
        id = dic["id"]?.description
        expenceName = dic["expenceName"]?.description
        expenceAmount = dic["expenceAmount"]?.description
        categoryId = dic["categoryId"]?.description
        categoryName = dic["categoryName"]?.description
        desc = dic["desc"]?.description
        insertDate = dic["insertDate"] as? Date
    }
    
}

