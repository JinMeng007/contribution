//
//  CategoryTableViewCell.swift
//  Pocky Helper
//
//  Created by Ashish on 09/04/19.
//  Copyright © 2019 Ashish. All rights reserved.
//

import UIKit

class IncomeListTableViewCell: UITableViewCell {

    @IBOutlet weak var lblCateName: UILabel!
    @IBOutlet weak var lblIncome: UILabel!
    @IBOutlet weak var lblAmt: UILabel!
    @IBOutlet weak var lblDesc: UILabel!
    @IBOutlet weak var lblDate: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
}
