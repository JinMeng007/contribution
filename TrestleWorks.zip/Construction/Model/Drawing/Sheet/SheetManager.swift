//
//  SheetManager.swift
//  Construction
//
//  Created by Macmini on 11/5/17.
//  Copyright © 2017 LekshmySankar. All rights reserved.
//

import UIKit

class SheetManager {
    static let shared = SheetManager()
    var sheets: [Sheet] = [Sheet]()
}
