//
//  Comment.swift
//  Construction
//
//  Created by Macmini on 3/13/18.
//  Copyright © 2018 LekshmySankar. All rights reserved.
//

import UIKit

class Comment: Object {
    @objc dynamic var userID: String?
    @objc dynamic var userName: String?
    @objc dynamic var comment: String?
}
