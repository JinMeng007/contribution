//
//  Message.swift
//  Construction
//
//  Created by Macmini on 3/14/18.
//  Copyright © 2018 LekshmySankar. All rights reserved.
//

import UIKit

class Message: Object {
    @objc dynamic var userID: String?
    @objc dynamic var userName: String?
    @objc dynamic var text: String?
}
