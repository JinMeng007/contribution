//
//  Room.swift
//  Construction
//
//  Created by Macmini on 3/14/18.
//  Copyright © 2018 LekshmySankar. All rights reserved.
//

import UIKit

class Room: Object {
    @objc dynamic var name: String?
    @objc dynamic var messages: Set<String> = []
}
