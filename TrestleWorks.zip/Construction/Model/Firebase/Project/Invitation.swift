//
//  Invitation.swift
//  Construction
//
//  Created by Macmini on 3/12/18.
//  Copyright © 2018 LekshmySankar. All rights reserved.
//

import UIKit

class Invitation: Relation<Project> {
    override class var _name: String {
        return "invitation"
    }
}
