//
//  FindUser.swift
//  Siphon
//
//  Created by Developer ST on 25/09/18.
//  Copyright © 2018 XYZ. All rights reserved.
//

import Foundation

class FindUser {
    
    let name, email, ID, avatarURLStr: String
    
    init(dataDict: [String: Any]){
        
        self.ID = "\(dataDict["user_id"] ?? "")"
        self.email = "\(dataDict["email"] ?? "")"
        self.name = "\(dataDict["firstname"] ?? "")"
        self.avatarURLStr = "\(dataDict["avatar_url"] ?? "")"
    }
}
