//
//  CurrentSiphon.swift
//  Siphon
//
//  Created by STUser on 29/09/18.
//  Copyright © 2018 XYZ. All rights reserved.
//

import UIKit

class CurrentSiphon: NSObject {

    var isBorrowedMoney = true
    let fromName, fromID, duration, amount, ID, toName, toID: String
    
    init(dataDict: [String: Any]) {
        self.amount = "\(dataDict["amount"] ?? "")"
        self.toID = "\(dataDict["to_userid"] ?? "")"
        self.toName = "\(dataDict["to_name"] ?? "")"
        self.fromName = "\(dataDict["from_name"] ?? "")"
        self.fromID = "\(dataDict["from_userid"] ?? "")"
        self.ID = "\(dataDict["borrow_request_id"] ?? "")"
        self.duration = "\(dataDict["how_many_days"] ?? "")"

        if let appUserID = UserDefaults.standard.object(forKey: "userID") {
            if "\(appUserID)" == self.toID {
                self.isBorrowedMoney = false
            }
        }
    }
}
