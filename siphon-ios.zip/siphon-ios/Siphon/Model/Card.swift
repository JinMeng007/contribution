//
//  Card.swift
//  Siphon
//
//  Created by STUser on 05/10/18.
//  Copyright © 2018 XYZ. All rights reserved.
//

import UIKit

class Card: NSObject {
    
    let brand, last4Digits, ID, customerID: String
    
    init(dataDict: [String: Any]) {
        self.ID = "\(dataDict["id"] ?? "")"
        self.brand = "\(dataDict["brand"] ?? "")"
        self.last4Digits = "\(dataDict["last4"] ?? "")"
        self.customerID = "\(dataDict["customer"] ?? "")"
    }
}
