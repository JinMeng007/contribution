//
//  SiphonRequest.swift
//  Siphon
//
//  Created by STUser on 28/09/18.
//  Copyright © 2018 XYZ. All rights reserved.
//

import UIKit

class SiphonRequest: NSObject {

    let borrowerName, borrowerID, duration, amount, ID, borrowerEmail: String
    
    init(dataDict: [String: Any]) {
        self.amount = "\(dataDict["amount"] ?? "")"
        self.borrowerEmail = "\(dataDict["email"] ?? "")"
        self.ID = "\(dataDict["borrow_request_id"] ?? "")"
        self.borrowerName = "\(dataDict["firstname"] ?? "")"
        self.borrowerID = "\(dataDict["from_userid"] ?? "")"
        self.duration = "\(dataDict["how_many_days"] ?? "")"
    }
}
