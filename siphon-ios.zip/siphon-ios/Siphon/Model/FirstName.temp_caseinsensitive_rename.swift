//
//  firstName.swift
//  Siphon
//
//  Created by Developer ST on 25/09/18.
//  Copyright © 2018 XYZ. All rights reserved.
//

import UIKit

class FirstName {

    let name: String?
    
    init (dataDict:[String:Any]) {
        
        self.name = "\(dataDict["firstname"] ?? "")"
    }
}
