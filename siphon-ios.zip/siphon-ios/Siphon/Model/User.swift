//
//  User.swift
//  Siphon
//
//  Created by STUser on 21/09/18.
//  Copyright © 2018 XYZ. All rights reserved.
//

import UIKit

class User: NSObject {

    let name, email, phoneNumber, avatarURLStr: String
    
    init(dataDict: [String: Any]) {
    
        self.email = "\(dataDict["email"] ?? "")"
        self.name = "\(dataDict["firstname"] ?? "")"
        self.phoneNumber = "\(dataDict["phonenumber"] ?? "")"
        self.avatarURLStr = "\(dataDict["avatar_url"] ?? "")"
    }
}
