//
//  NetworkHelper.swift
//  Siphon
//
//  Created by Developer ST on 20/09/18.
//  Copyright © 2018 XYZ. All rights reserved.
//

import UIKit
import NVActivityIndicatorView

class NetworkHelper: NSObject {
    
    // MARK:- Instances
    static var isLoginAPI = false
    static let appBaseURL = "http://ec2-18-219-6-149.us-east-2.compute.amazonaws.com/siphon-web/app/api/v1"
    
    // Loader setup...
    let spinner = NVActivityIndicatorView(frame: CGRect(x: UIScreen.main.bounds.size.width/2.0-25, y: UIScreen.main.bounds.size.height/2.0-25, width: 50, height: 50), type: .lineScale, color: UIColor(red: 247.0/255.0, green: 107.0/255.0, blue: 28.0/255.0, alpha: 1), padding: 0)
    
    
    
    // MARK:- API function
    func postAPIRequest(withParameters: Dictionary<String, Any>, withURLStr: String, withViewController: UIViewController?, withSuccess: @escaping (_ success: [String : Any]) -> Void, withFailure: @escaping ( _ failure: [String : Any]) -> Void)  {
        
        //  Show Loader on API run...
        withViewController?.view.isUserInteractionEnabled = false
        withViewController?.view.addSubview(spinner)
        spinner.startAnimating()
        
        
        var headers = ["Accept": "application/json", "Content-Type": "application/json"]
        
        // After login, the token will be used as authorization...
        if let token = UserDefaults.standard.value(forKey: "token"){
            
            headers["auth-token"] = "\(token)"
        }
        
        
        
        if let postData = (try? JSONSerialization.data(withJSONObject: withParameters, options: [])) {
            
            let request = NSMutableURLRequest(url: URL(string: "\(NetworkHelper.appBaseURL)\(withURLStr)")!, cachePolicy: .useProtocolCachePolicy, timeoutInterval: 20.0)
            
            print("\(request)")
            
            request.httpMethod = "POST"
            request.httpBody = postData
            request.allHTTPHeaderFields = headers
            
            let task = URLSession.shared.dataTask(with: request as URLRequest) {
                
                (data, response, error) -> Void in
               
                DispatchQueue.main.async {
                    
                    print("\(NetworkHelper.appBaseURL)\(withURLStr)")
                    if (error != nil) {
                        
                        withFailure(["": ""])
                    }
                    else {
                        
                        DispatchQueue.main.async(execute: {
                            
                            // After getting response, remove the Loader from View...
                            self.spinner.stopAnimating()
                            self.spinner.removeFromSuperview()
                            withViewController?.view.isUserInteractionEnabled = true
                            
                            if let json = (try? JSONSerialization.jsonObject(with: data!, options: [])) as? NSDictionary {
                                
                                print(String(data: data!, encoding: .utf8) ?? "Error")
                                print("\(withParameters) \n \(NetworkHelper.appBaseURL)\(withURLStr)  \n  \(String(data: data!, encoding: .utf8) ?? "Error")")
                                
                                let statusCode = json["code"] as? Int
                                
                                // Success with status code 200...
                                if (statusCode == 200) {
                                    
                                    print(json)
                                    withSuccess(json as! [String : AnyObject])
                                }
                                else {
                                    
                                    // Handle the server error and show the message sent by the server...
                                    if statusCode == 500 {
                                        
                                        if let message = json["message"] as? String {
                                            
                                            let alert = UIAlertController(title: "Server Error", message: "\(message)", preferredStyle: UIAlertControllerStyle.alert)
                                            alert.addAction(UIAlertAction(title: "OK", style: UIAlertActionStyle.default, handler: nil))
                                            withViewController?.present(alert, animated: true, completion: nil)
                                        }
                                    }
                                    else if statusCode == 401 {
                                        if NetworkHelper.isLoginAPI {
                                            if let message = json["message"] as? String {
                                                let alert = UIAlertController(title: "Alert", message: "\(message)", preferredStyle: UIAlertControllerStyle.alert)
                                                alert.addAction(UIAlertAction(title: "OK", style: UIAlertActionStyle.default, handler: nil))
                                                withViewController?.present(alert, animated: true, completion: nil)
                                            }
                                            return
                                        }
                                        
                                        if AppDelegate.signInVC != nil {
                                            AppDelegate.baseTabBC?.dismiss(animated: true, completion: nil)
                                            if AppDelegate.signUpVC != nil {
                                                AppDelegate.signUpVC!.dismiss(animated: true, completion: nil)
                                            }
                                        }
                                        else {
                                            
                                            let signInVC = UIStoryboard(name: "Signup", bundle: nil).instantiateViewController(withIdentifier: "SignInVC") as? SignInViewController
                                            
                                            if let message = json["message"] as? String {
                                                
                                                let alert = UIAlertController(title: "Alert", message: "\(message)", preferredStyle: UIAlertControllerStyle.alert)
                                                alert.addAction(UIAlertAction(title: "OK", style: UIAlertActionStyle.default, handler: nil))
                                                withViewController?.present(signInVC!, animated: true, completion: nil)
                                                signInVC!.present(alert, animated: true, completion: nil)
                                            }
                                            else {
                                                withViewController?.present(signInVC!, animated: true, completion: nil)
                                            }
                                        }
                                    }
                                    else {
                                        
                                        // Other status codes will be handle by specific controller call...
                                        withFailure(json as! [String : AnyObject])
                                    }
                                }
                            }
                        })
                    }
                }
            }
            
            task.resume()
        }
    }
}
