//
//  UpdateProfileViewController.swift
//  Siphon
//
//  Created by Developer ST on 24/09/18.
//  Copyright © 2018 XYZ. All rights reserved.
//

import UIKit

class UpdateProfileViewController: UIViewController {
    
    // MARK:- IBOutlets
    @IBOutlet weak var tfEmail: UITextField!
    @IBOutlet weak var tfPhoneNo: UITextField!
    @IBOutlet weak var tfFirstName: UITextField!
    
    
    
    // MARK:- Instances
    var userDataToShow: User?
    
    
    // MARK:- View LifeCycle
    override func viewDidLoad() {
        
        super.viewDidLoad()
        setInitials()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
    }
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        
        super.viewWillDisappear(animated)
       
    }
    
    override func viewDidDisappear(_ animated: Bool) {
        super.viewDidDisappear(animated)
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
    
    // MARK:- Private function
    private func setInitials() {
        
        tfEmail.text = self.userDataToShow?.email ?? ""
        tfFirstName.text = self.userDataToShow?.name ?? ""
        tfPhoneNo.text = self.userDataToShow?.phoneNumber ?? ""
    }
    
    private func setupView() {
    }
    
    // MARK:- IBAction
    
    @IBAction func updateTap(_ sender: UIButton) {
        updateAPI()
        self.view.endEditing(true)
    }
    
    @IBAction func backTap(_ sender: UIButton) {
        self.dismiss(animated: true, completion: nil)
    }
    
    
    
    //MARK:- API Function
    
    func updateAPI ()
    {
        // Manage whitespace start and end point on textfield...
        let emailStr = tfEmail.text?.trimmingCharacters(in: NSCharacterSet.whitespacesAndNewlines)
        let firstnameStr = tfFirstName.text?.trimmingCharacters(in: NSCharacterSet.whitespacesAndNewlines)
        let phoneNumber = tfPhoneNo.text?.trimmingCharacters(in: NSCharacterSet.whitespacesAndNewlines)
        
        if isDataValid() != true {
            
            return
        }
        
        NetworkHelper().postAPIRequest(withParameters: [ "firstname": firstnameStr ?? "", "email": emailStr ?? "", "phonenumber": phoneNumber ?? ""], withURLStr: "/user/infoSet", withViewController: self, withSuccess: { (resultDict) in
            print("......", resultDict)
            
            let alert = UIAlertController(title: "Alert", message: "Profile Updated", preferredStyle: UIAlertControllerStyle.alert)
            alert.addAction(UIAlertAction(title: "OK", style: UIAlertActionStyle.default, handler: { (success) in
                self.dismiss(animated: true, completion: nil)

           }))
          self.present(alert, animated: true, completion: nil)
        }) { (resultDict) in
            print("failure")
        }
    }
    
   // MARK:- Validation function
    
    func isDataValid () -> Bool {
        
        var isValid = true
        
        // Manage whitespace start and end point on textfield...
        let emailStr = tfEmail.text?.trimmingCharacters(in: NSCharacterSet.whitespacesAndNewlines)
        let firstnameStr = tfFirstName.text?.trimmingCharacters(in: NSCharacterSet.whitespacesAndNewlines)
        let phoneNumber = tfPhoneNo.text?.trimmingCharacters(in: NSCharacterSet.whitespacesAndNewlines)
        
        if emailStr?.count == 0 || firstnameStr?.count == 0  || phoneNumber?.count == 0 {
            
            let alert = UIAlertController(title: "Invalid Input", message: "All fields are mandatory.", preferredStyle: UIAlertControllerStyle.alert)
            alert.addAction(UIAlertAction(title: "OK", style: UIAlertActionStyle.default, handler: nil))
            self.present(alert, animated: true, completion: nil)
            
            isValid = false
        }
        
        if tfEmail.text?.isValidEmail != true {
            
            let alert = UIAlertController(title: "Invalid Input", message: "Please provide a valid email", preferredStyle: UIAlertControllerStyle.alert)
            alert.addAction(UIAlertAction(title: "OK", style: UIAlertActionStyle.default, handler: nil))
            self.present(alert, animated: true, completion: nil)
            
            isValid = false
        }

        return isValid
    }
}



