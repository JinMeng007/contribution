//
//  MyAccountViewController.swift
//  Siphon
//
//  Created by Developer ST on 19/09/18.
//  Copyright © 2018 XYZ. All rights reserved.
//

import UIKit
import ImageLoader
import AssetsLibrary
import NVActivityIndicatorView
import Alamofire

class MyAccountViewController: UIViewController {
    
    // MARK:- IBOutlets
    @IBOutlet weak var imgProfile: UIImageView!
    @IBOutlet weak var lblName, lblMoney, lblEmail, lblPhoneNo: UILabel!
    
    
    // MARk:- Instances
    var appUser: User?
    var popcontroller: PopupViewController?
    var imagePicker = UIImagePickerController ()
    
    // Loader setup...
    let spinner = NVActivityIndicatorView(frame: CGRect(x: UIScreen.main.bounds.size.width/2.0-25, y: UIScreen.main.bounds.size.height/2.0-25, width: 50, height: 50), type: .lineScale, color: UIColor(red: 247.0/255.0, green: 107.0/255.0, blue: 28.0/255.0, alpha: 1), padding: 0)
    
    
    // MARK:- View LifeCycle
    override func viewDidLoad() {
        
        super.viewDidLoad()
        getUserInfo()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        self.navigationController?.isNavigationBarHidden = true
        
    }
    
    override func viewDidAppear(_ animated: Bool) {
        
        super.viewDidAppear(animated)
        setupView()
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
    }
    
    override func viewDidDisappear(_ animated: Bool) {
        super.viewDidDisappear(animated)
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
    
    
    
    // MARK:- Private function
    private func setInitials() {
        
    }
    
    private func setupView() {
        // Rounding userProfile imageview...
        imgProfile.layer.cornerRadius = (0.13 * UIScreen.main.bounds.size.height)/2.0
        imgProfile.clipsToBounds = true
    }
    
    private func showUserInfoOnScreen(user: User) {
        
        self.lblName.text = user.name
        self.lblEmail.text = user.email
        self.lblPhoneNo.text = user.phoneNumber
        
        UserDefaults.standard.set("\(user.name)", forKey: "userName")
        
        if user.avatarURLStr.contains("http") {
            
            UserDefaults.standard.set("\(user.avatarURLStr)", forKey: "userAvatar")

            self.imgProfile.load.request(with: URL(string: user.avatarURLStr)!, placeholder: UIImage(named: "DefaultUser"), onCompletion: { (image, error, operation) in
            })
        }
        UserDefaults.standard.synchronize()
    }
   
    
    // MARK:- IBAction
    @IBAction func bankAndCardTap(_ sender: UIButton) {
        let addCardVC = UIStoryboard.init(name: "MoneyTransfer", bundle: nil).instantiateViewController(withIdentifier: "AddCardVC") as! AddCardViewController
        addCardVC.isFromMyAccount = true
        navigationController?.pushViewController(addCardVC, animated: true)
    }
    
    @IBAction func transferBankTap(_ sender: UIButton) {
        let transferBankVC = UIStoryboard.init(name: "MoneyTransfer", bundle: nil).instantiateViewController(withIdentifier: "TransferToBankVC") as! TransferToBankViewController
        transferBankVC.isFromMyAccount = true
        navigationController?.pushViewController(transferBankVC, animated: true)
    }
    
    @IBAction func contactTap(_ sender: UIButton) {
    }
    
    @IBAction func logoutTap(_ sender: UIButton) {
       logoutAPI()
    }

    @IBAction func backTap(_ sender: UIButton) {
    }
    
    @IBAction func editProfileTap(_ sender: UIButton) {
        let avc = self.storyboard?.instantiateViewController(withIdentifier: "UpdateVC") as! UpdateProfileViewController
        avc.userDataToShow = self.appUser
        self.present(avc, animated: true, completion: nil)
    }
    
    @IBAction func profileTap(_ sender: UIButton) {
        let alertController = UIAlertController(title: "Upload Profile Image", message: nil, preferredStyle: .actionSheet)
        let cameraAction = UIAlertAction(title: "Camera", style: .default) { (action) in
        }
        let photoLibrarayAction = UIAlertAction(title: "Photo Library", style: .default) { (action) in
            DispatchQueue.main.async {
               
            if UIImagePickerController.isSourceTypeAvailable(.photoLibrary){
                self.imagePicker.delegate = self
                self.imagePicker.sourceType = .photoLibrary
                self.imagePicker.allowsEditing = false
                self.present(self.imagePicker, animated: true, completion: nil)
                }
            }
        }
        let cancelAction = UIAlertAction(title: "Cancel", style: .cancel) { (action) in
        }
       
        alertController.addAction(cameraAction)
        alertController.addAction(photoLibrarayAction)
        alertController.addAction(cancelAction)
        
        self.present(alertController, animated: true, completion: nil)
    }

    
    // MARK:- API function
    func getUserInfo ()
    {
        NetworkHelper().postAPIRequest(withParameters: ["":""], withURLStr: "/user/infoGet", withViewController: self, withSuccess: { (resultDict) in
            
            DispatchQueue.main.async {
                
                if let userData = resultDict["user"] as? [String: Any] {
                    let user = User(dataDict: userData)
                    self.showUserInfoOnScreen(user: user)
                    self.appUser = user
                }
                
                self.getBalance()
            }
        }) { (resultDict) in
        }
    }
    
    func logoutAPI ()
    {
        NetworkHelper().postAPIRequest(withParameters: ["":""], withURLStr: "/user/logout", withViewController: self, withSuccess: { (resultDict) in
            DispatchQueue.main.async {
                
                UserDefaults.standard.set(nil, forKey: "token")
                UserDefaults.standard.synchronize()
                
                if AppDelegate.signInVC != nil {
                    AppDelegate.baseTabBC?.dismiss(animated: true, completion: nil)
                    if AppDelegate.signUpVC != nil {
                        AppDelegate.signUpVC!.dismiss(animated: true, completion: nil)
                    }
                }
                else {
                   
                    let signInVC = UIStoryboard(name: "Signup", bundle: nil).instantiateViewController(withIdentifier: "SignInVC") as? SignInViewController
                    self.present(signInVC!, animated: true, completion: nil)
                }
            }
        }) { (resultDict) in
        }
    }
    
    func getBalance()
    {
        NetworkHelper().postAPIRequest(withParameters: ["":""], withURLStr: "/siphon/accountBalance", withViewController: self, withSuccess: { (resultDict) in
            DispatchQueue.main.async {
                
                if let accntData = resultDict["account"] as? [String: Any] {
                    if let balArr = accntData["available"] as? [[String: Any]] {
                        let balAvailableDict = balArr[0]
                        if let balAvailable = balAvailableDict["amount"] as? Int {
                            self.lblMoney.text =  String(format: "$%.2f", Float(balAvailable)/100.00)
                        }
                    }
                }
            }
        }) { (resultDict) in
        }
    }
    
    func uploadProfile (image: UIImage) {
        
        let imgData = UIImageJPEGRepresentation(image, 0.2)!

        let url = "\(NetworkHelper.appBaseURL)/user/imageUpload" /* your API url */
        
        
        //  Show Loader on API run...
        view.isUserInteractionEnabled = false
        view.addSubview(spinner)
        spinner.startAnimating()

        
        var headers: HTTPHeaders = [
            "Content-type": "multipart/form-data"
        ]
        
        if let token = UserDefaults.standard.value(forKey: "token"){
            
            headers["auth-token"] = "\(token)"
        }
        
        Alamofire.upload(multipartFormData: { (multipartFormData) in
            for (key, value) in ["":""] {
                multipartFormData.append("\(value)".data(using: String.Encoding.utf8)!, withName: key as String)
            }
            
            multipartFormData.append(imgData, withName: "image", fileName: "image.png", mimeType: "image/png")
            
        }, usingThreshold: UInt64.init(), to: url, method: .post, headers: headers) { (result) in
            switch result{
            case .success(let upload, _, _):
                upload.responseJSON { response in
                    
                    //  Hide Loader on API run...
                    self.spinner.stopAnimating()
                    self.spinner.removeFromSuperview()
                    self.view.isUserInteractionEnabled = true

                    if let result = response.result.value {
                        let JSON = result as! NSDictionary
                        if let urlStr = JSON["avatar_url"] as? String {
                            
                            self.imgProfile.load.request(with: URL(string: urlStr)!, placeholder: UIImage(named: "DefaultUser"), onCompletion: { (image, error, operation) in
                            })
                        }
                    }
                    if response.error != nil{
                        return
                    }
                }
            case .failure(let error):
                print("Error in upload: \(error.localizedDescription)")
                
                //  Hide Loader on API run...
                self.spinner.stopAnimating()
                self.spinner.removeFromSuperview()
                self.view.isUserInteractionEnabled = true
            }
            
            
        }
    }
}


// MARK:- Extension: UIImageViewDelegate
extension MyAccountViewController: UIImagePickerControllerDelegate, UINavigationControllerDelegate {

    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [String : Any]) {
        
        if let image = info[UIImagePickerControllerOriginalImage] as? UIImage {
            
            uploadProfile (image: image)
        }
        
      //  imgProfile.image = info[UIImagePickerControllerOriginalImage] as? UIImage
        self.dismiss(animated: true, completion: nil)
            }
        }



