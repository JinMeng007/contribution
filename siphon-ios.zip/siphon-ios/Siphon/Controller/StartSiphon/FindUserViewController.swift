//
//  FindUserViewController.swift
//  Siphon
//
//  Created by Developer ST on 19/09/18.
//  Copyright © 2018 XYZ. All rights reserved.
//

import UIKit

class FindUserViewController: UIViewController,UITextFieldDelegate {

    // MARK:- IBOutlets
    @IBOutlet weak var tbUser: UITableView!
    @IBOutlet weak var btnHideTable: UIButton!
    @IBOutlet weak var tfFindUser, tfAmount, tfNumberOfPayments, tfDuration: UITextField!
    
    
    // MARK:- Instances
    var baseURLForAvatar = ""
    var filterdUserArr = [FindUser]()
    var selectedFilteredUser: FindUser?

    
    // MARK:- View LifeCycle
    override func viewDidLoad() {
        super.viewDidLoad()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
    }
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
    }
    
    override func viewDidDisappear(_ animated: Bool) {
        super.viewDidDisappear(animated)
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
    
    // MARK:- Private function
    private func setInitials() {
    }
    
    private func setupView() {
    }
    
    private func isDataValid() -> Bool {
        
        let amount = tfAmount.text?.trimmingCharacters(in: CharacterSet.whitespacesAndNewlines) ?? ""
        let duration = tfDuration.text?.trimmingCharacters(in: CharacterSet.whitespacesAndNewlines) ?? ""
        let userName = tfFindUser.text?.trimmingCharacters(in: CharacterSet.whitespacesAndNewlines) ?? ""
        let paymentsFreq = tfNumberOfPayments.text?.trimmingCharacters(in: CharacterSet.whitespacesAndNewlines) ?? ""
        
        if amount.count == 0 || duration.count == 0 || userName.count == 0 || paymentsFreq.count == 0 {
            let alertController = UIAlertController.init(title: "Alert!", message: "All fields are required.", preferredStyle: .alert)
            let cancelAction = UIAlertAction(title: "OK", style: .cancel, handler: nil)
            alertController.addAction(cancelAction)
            self.present(alertController, animated: true, completion: nil)
            return false
        }
        
        if selectedFilteredUser == nil {
            let alertController = UIAlertController.init(title: "Alert!", message: "Please select a valid user from drop-down option only.", preferredStyle: .alert)
            let cancelAction = UIAlertAction(title: "OK", style: .cancel, handler: nil)
            alertController.addAction(cancelAction)
            self.present(alertController, animated: true, completion: nil)
            return false
        }
        
        return true
    }
    
    
    // MARK:- IBAction
    @IBAction func backTap(_ sender: UIButton) {
        self.navigationController?.popViewController(animated: true)
    }
    
    @IBAction func sendTap(_ sender: UIButton) {
        self.view.endEditing(true)
        sendSiphonRequestAPI()
    }
    
    @IBAction func hideTableTap(_ sender: UIButton) {
        tbUser.alpha = 0
        btnHideTable.alpha = 0
    }
    
    
    // MARK:- Textfield delegate function
    func textField(_ textField: UITextField, shouldChangeCharactersIn range: NSRange, replacementString string: String) -> Bool {
        selectedFilteredUser = nil
        NSObject.cancelPreviousPerformRequests(withTarget: self, selector: #selector(FindUserViewController.finduserAPI), object: nil)
        self.perform(#selector(FindUserViewController.finduserAPI), with: nil, afterDelay: 0.8)
        return true
    }
    
    
    // MARK:- API function
    @objc func finduserAPI ()
    {
        NetworkHelper().postAPIRequest(withParameters: ["name": tfFindUser.text ??  ""], withURLStr: "/user/find", withViewController: self, withSuccess: { (resultDict) in

            DispatchQueue.main.async {
                
                if let userArr = resultDict["user"] as? [[String: Any]], let baseURLStr = resultDict["avatar_base_url"] as? String{
                    
                    self.baseURLForAvatar = baseURLStr
                    
                    if userArr.count > 0 {
                        self.filterdUserArr = [FindUser]()
                        for(_, obj) in userArr.enumerated() {
                            let filterUser = FindUser(dataDict: obj)
                            self.filterdUserArr.append(filterUser)
                        }
                        self.tbUser.alpha = 1
                        self.btnHideTable.alpha = 1
                    }
                    else {
                        self.tbUser.alpha = 0
                        self.btnHideTable.alpha = 0
                        self.filterdUserArr = [FindUser]()
                    }
                }
                else {
                    self.tbUser.alpha = 0
                    self.btnHideTable.alpha = 0
                    self.filterdUserArr = [FindUser]()
                }
                self.tbUser.reloadData()
            }
        }) { (resultDict) in
        }
    }
    
    func sendSiphonRequestAPI() {
        
        if isDataValid() == false {
            return
        }
        
        let amount = tfAmount.text?.trimmingCharacters(in: CharacterSet.whitespacesAndNewlines) ?? ""
        let duration = tfDuration.text?.trimmingCharacters(in: CharacterSet.whitespacesAndNewlines) ?? ""
        let paymentsFreq = tfNumberOfPayments.text?.trimmingCharacters(in: CharacterSet.whitespacesAndNewlines) ?? ""
        
        let paramDict = ["to_userid": selectedFilteredUser?.ID ?? "", "how_many_payments": paymentsFreq, "amount": amount, "how_many_days": duration]
        NetworkHelper().postAPIRequest(withParameters: paramDict, withURLStr: "/siphon/sendRequest", withViewController: self, withSuccess: { (resultDict) in
            DispatchQueue.main.async {
                self.tfAmount.text = ""
                self.tfFindUser.text = ""
                self.tfDuration.text = ""
                self.tfNumberOfPayments.text = ""
                if let msg = resultDict["message"] {
                    let alertController = UIAlertController.init(title: "Success!", message: "\(msg)", preferredStyle: .alert)
                    let cancelAction = UIAlertAction(title: "OK", style: .cancel, handler: nil)
                    alertController.addAction(cancelAction)
                    self.present(alertController, animated: true, completion: nil)
                }
            }
        }) { (resultDict) in
        }
    }
}
 
//MARK: - UITableViewDataSource
extension FindUserViewController: UITableViewDataSource, UITableViewDelegate {
    
    func scrollViewDidScroll(_ scrollView: UIScrollView) {
        self.view.endEditing(true)
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return filterdUserArr.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell = tableView.dequeueReusableCell(withIdentifier: "finduserCell") as! FindUserCell
        
        if filterdUserArr.count > 0 {
            let filterUser = filterdUserArr[indexPath.row]
            
            cell.lblFirstName.text = filterUser.name
            let avatarURLStr = "\(self.baseURLForAvatar)\(filterUser.avatarURLStr)"
            if avatarURLStr.contains("http") {
                cell.imgUser.load.request(with: URL(string: avatarURLStr)!, placeholder: UIImage(named: "DefaultUser"), onCompletion: { (image, error, operation) in
                })
            }
        }
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
        self.selectedFilteredUser = filterdUserArr[indexPath.row]
        tfFindUser.text = selectedFilteredUser?.name ?? ""
        tfAmount.becomeFirstResponder()
        tbUser.alpha = 0
        btnHideTable.alpha = 0
    }
}
