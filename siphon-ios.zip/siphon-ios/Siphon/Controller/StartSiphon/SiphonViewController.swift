//
//  SiphonViewController.swift
//  Siphon
//
//  Created by Developer ST on 19/09/18.
//  Copyright © 2018 XYZ. All rights reserved.
//

import UIKit

class SiphonViewController: UIViewController {
    
    // MARK:- IBOutlets
    @IBOutlet weak var imgProfile: UIImageView!
    @IBOutlet weak var lblName, lblMoney: UILabel!
    
    // MARK:- View LifeCycle
    override func viewDidLoad() {
        super.viewDidLoad()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        setupView()
    }
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
    }
    
    override func viewDidDisappear(_ animated: Bool) {
        super.viewDidDisappear(animated)
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
    
    // MARK:- Private function
    private func setInitials() {
        
        
        
        
    }
    
    private func setupView() {
        if let displayName = UserDefaults.standard.object(forKey: "userName") {
            lblName.text = "\(displayName)"
        }
        
        if let avatarURLStr = UserDefaults.standard.object(forKey: "userAvatar") as? String {
            if avatarURLStr.contains("http") {
                self.imgProfile.load.request(with: URL(string: avatarURLStr)!, placeholder: UIImage(named: "DefaultUser"), onCompletion: { (image, error, operation) in
                })
            }
        }
    }

    // MARK:- IBAction
    @IBAction func startSiphonTap(_ sender: UIButton) {
        
    }
}
