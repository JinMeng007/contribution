//
//  CurrentSiphons.swift
//  Siphon
//
//  Created by Developer ST on 19/09/18.
//  Copyright © 2018 XYZ. All rights reserved.
//

import UIKit

class CurrentSiphons: UIViewController {
    
    // MARK:- IBOutlets
    @IBOutlet weak var tbCurrentSiphon: UITableView!
    
    
    // MARK:- Instances
    var currentSiphonsArr = [CurrentSiphon]()
    
    
    // MARK:- View LifeCycle
    override func viewDidLoad() {
        
        super.viewDidLoad()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        getCurrentSiphons()
    }
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
    }
    
    override func viewDidDisappear(_ animated: Bool) {
        super.viewDidDisappear(animated)
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
    
    
    // MARK:- Private function
    private func setInitials() {
    }
    
    private func setupView() {
    }
    
    
    // MARK:- API functions
    func getCurrentSiphons() {
        
        NetworkHelper().postAPIRequest(withParameters: ["": ""], withURLStr: "/siphon/listGet", withViewController: self, withSuccess: { (resultDict) in
            DispatchQueue.main.async {
                self.currentSiphonsArr = [CurrentSiphon]()
                if let siphonArr = resultDict["siphon_list"] as? [[String: Any]] {
                    for (_, obj) in siphonArr.enumerated() {
                        let currentSiphon = CurrentSiphon(dataDict: obj)
                        self.currentSiphonsArr.append(currentSiphon)
                    }
                }
                self.tbCurrentSiphon.reloadData()
            }
        }) { (resultDict) in
        }
    }
}

//MARK: - UITableViewDataSource
extension CurrentSiphons: UITableViewDataSource, UITableViewDelegate {
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {   
        return currentSiphonsArr.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell = tableView.dequeueReusableCell(withIdentifier: "CurrentSiphonsCell") as! CurrentSiphonsCell

        if currentSiphonsArr.count > 0 {
            let siphon = currentSiphonsArr[indexPath.row]
            
            if siphon.isBorrowedMoney == true {
                cell.moneyTypeImage.image = #imageLiteral(resourceName: "MoneyGreenIcon")
                cell.lblMoneyDescription.text = "$\(siphon.amount) from \(siphon.toName)"
            }
            else {
                cell.moneyTypeImage.image = #imageLiteral(resourceName: "moneyRedIcon")
                cell.lblMoneyDescription.text = "$\(siphon.amount) to \(siphon.fromName)"
            }
            cell.lblDays.text = "\(siphon.duration)d"
        }
        
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
    }
}

