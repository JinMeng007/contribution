//
//  SiphonRequestsViewController.swift
//  Siphon
//
//  Created by Developer ST on 28/09/18.
//  Copyright © 2018 XYZ. All rights reserved.
//

import UIKit
import Stripe


class SiphonRequestsViewController: UIViewController {
    
    // MARK:- IBOutlets
    @IBOutlet weak var tbRequest: UITableView!
    
    
    // MARk:- Instances
    var stripeToken = ""
    var requestsArr: [SiphonRequest]?
    var respondedRequest: SiphonRequest?
    
    
    // MARK:- View LifeCycle
    override func viewDidLoad() {
        super.viewDidLoad()
        tbRequest.estimatedRowHeight = 100.0
        tbRequest.rowHeight = UITableViewAutomaticDimension
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        self.navigationController?.isNavigationBarHidden = true
        getAllSiphonsRequests()
    }
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
    }
    
    override func viewDidDisappear(_ animated: Bool) {
        super.viewDidDisappear(animated)
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
    
    
    // MARK:- Private function
    private func setInitials() {
        
    }
    
    private func setupView() {
    }


    // MARK:- API functions
    func getAllSiphonsRequests() {
       
        NetworkHelper().postAPIRequest(withParameters: ["": ""], withURLStr: "/siphon/requestListGet", withViewController: self, withSuccess: { (resultDict) in
            DispatchQueue.main.async {
                self.requestsArr = [SiphonRequest]()
                if let rqstArr = resultDict["siphon_requests_list"] as? [[String: Any]] {
                    for (_, obj) in rqstArr.enumerated() {
                        let rqst = SiphonRequest(dataDict: obj)
                        self.requestsArr?.append(rqst)
                    }
                }
                self.tbRequest.reloadData()
            }
        }) { (resultDict) in
        }
    }
    
    func acceptDeclineRequestApi(status: String, token: String, requestID: String) {
        
        let paramDict = ["request_id": requestID, "status": status, "source_token": token]
        NetworkHelper().postAPIRequest(withParameters: paramDict, withURLStr: "/siphon/requestAcceptDecline", withViewController: self, withSuccess: { (resultDict) in
            DispatchQueue.main.async {
                if let message = resultDict["message"] {
                    let alertController = UIAlertController.init(title: "Success!", message: "\(message)", preferredStyle: .alert)
                    let cancelAction = UIAlertAction(title: "OK", style: .cancel, handler: nil)
                    alertController.addAction(cancelAction)
                    self.present(alertController, animated: true, completion: nil)
                    
                    self.getAllSiphonsRequests()
                }
            }
        }) { (resultDict) in
        }
    }

}

//MARK: - UITableViewDataSource
extension SiphonRequestsViewController: UITableViewDataSource, UITableViewDelegate {

    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
     return requestsArr?.count ?? 0
    }

    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
       let cell = tableView.dequeueReusableCell(withIdentifier: "SiphonRequestCell", for: indexPath) as? SiphonRequestCell
        
        if requestsArr?.count ?? 0 > 0 {
            let request = requestsArr![indexPath.row]

            cell?.btnAccept.tag = indexPath.row
            cell?.btnDecline.tag = indexPath.row
            cell?.btnAccept.addTarget(self, action: #selector(SiphonRequestsViewController.acceptTap(sender:)), for: .touchUpInside)
            cell?.btnDecline.addTarget(self, action: #selector(SiphonRequestsViewController.declineTap(sender:)), for: .touchUpInside)
            cell?.lblRequest.text = "\(request.borrowerName) wants to borrow $\(request.amount) from you for \(request.duration) days"
        }
        
        return cell!
    }

    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
     
    }
    
    // MARK:- Table Helper functions
    @objc func declineTap(sender: UIButton) {
        
        self.respondedRequest = requestsArr?[sender.tag]
        if let respondedRqst = self.respondedRequest {
            self.acceptDeclineRequestApi(status: "Accepted", token: "", requestID: respondedRqst.ID)
        }
    }
    
    @objc func acceptTap(sender: UIButton) {
        
        stripeToken = ""
        self.respondedRequest = requestsArr?[sender.tag]
        let addCardViewController = STPAddCardViewController()
        addCardViewController.delegate = self
        navigationController?.isNavigationBarHidden = false
        navigationController?.pushViewController(addCardViewController, animated: true)
    }
}


// MARK:- Extension: Stripe
extension SiphonRequestsViewController: STPAddCardViewControllerDelegate {
    
    func addCardViewControllerDidCancel(_ addCardViewController: STPAddCardViewController) {

        navigationController?.popViewController(animated: true)

        let alertController = UIAlertController.init(title: "Alert!", message: "Money transfer canceled by you.", preferredStyle: .alert)
        let cancelAction = UIAlertAction(title: "OK", style: .cancel, handler: nil)
        alertController.addAction(cancelAction)
        self.present(alertController, animated: true, completion: nil)
    }
    
    func addCardViewController(_ addCardViewController: STPAddCardViewController, didCreateToken token: STPToken, completion: @escaping STPErrorBlock) {
      
        stripeToken = "\(token)"
        if stripeToken.contains(" ") {
            stripeToken = stripeToken.components(separatedBy: " ").first ?? ""
        }
        
        navigationController?.popViewController(animated: true)
        if let respondedRqst = self.respondedRequest {
            self.acceptDeclineRequestApi(status: "Accepted", token: stripeToken, requestID: respondedRqst.ID)
        }
    }
}









