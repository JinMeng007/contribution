//
//  AddCardViewController.swift
//  Siphon
//
//  Created by Developer ST on 19/09/18.
//  Copyright © 2018 XYZ. All rights reserved.
//

import UIKit
import Stripe

class AddCardViewController: UIViewController {
    
    // MARK:- IBOutlets
    @IBOutlet weak var btnBack: UIButton!
    @IBOutlet weak var imgBack: UIImageView!
    @IBOutlet weak var tbDebidCard, tbBankAccount: UITableView!
    
    
    // MARK:- Instances
    var stripeToken = ""
    var cards = [Card]()
    var isFromMyAccount: Bool?
    
    
    // MARK:- View LifeCycle
    override func viewDidLoad() {
        super.viewDidLoad()
        imgBack.isHidden = true
        btnBack.isHidden = true
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        setupView()
    }
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
    }
    
    override func viewDidDisappear(_ animated: Bool) {
        super.viewDidDisappear(animated)
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
    
    // MARK:- Private function
    private func setInitials() {
    }
    
    private func setupView() {
        getCardList()
        navigationController?.isNavigationBarHidden = true
        if isFromMyAccount ?? false {
            btnBack.isHidden = false
            imgBack.isHidden = false
        }
    }

    //MARK:- IBAction
    @IBAction func addDebitCardTap(_ sender: UIButton) {
        let addCardViewController = STPAddCardViewController()
        addCardViewController.delegate = self
        navigationController?.isNavigationBarHidden = false
        navigationController?.pushViewController(addCardViewController, animated: true)
     }
    
    @IBAction func addBankAccountTap(_ sender: UIButton) {
    }
    
    @IBAction func backTap(_ sender: UIButton) {
        self.navigationController?.popViewController(animated: true)
    }
    
    
    // MARK:- API functions
    func addCard(withToken: String) {
        NetworkHelper().postAPIRequest(withParameters: ["token_debit_card": withToken, "card_for": "Payout"], withURLStr: "/siphon/cardAdd", withViewController: self, withSuccess: { (resultDict) in
            DispatchQueue.main.async {
                if let message = resultDict["message"] {
                    let alertController = UIAlertController.init(title: "Success!", message: "\(message)", preferredStyle: .alert)
                    let cancelAction = UIAlertAction(title: "OK", style: .cancel, handler: nil)
                    alertController.addAction(cancelAction)
                    self.present(alertController, animated: true, completion: nil)
                    
                    self.getCardList()
                }
            }
        }) { (resultDict) in
        }
    }
    
    func getCardList() {
        NetworkHelper().postAPIRequest(withParameters: ["card_for": "Payout"], withURLStr: "/siphon/cardList", withViewController: self, withSuccess: { (resultDict) in
            DispatchQueue.main.async {
                if let cardData = resultDict["card"] as? [String: Any] {
                    if let listOfCards = cardData["data"] as? [[String: Any]] {
                        for (_, obj) in listOfCards.enumerated() {
                            let card = Card(dataDict: obj)
                            self.cards.append(card)
                        }
                    }
                }
                self.tbDebidCard.reloadData()
            }
        }) { (resultDict) in
        }
    }
}

//MARK: - Extension: UITableViewDelegates
extension AddCardViewController: UITableViewDataSource, UITableViewDelegate {
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if tableView == tbDebidCard {
            return cards.count
        }
        return 0
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell { 
        if tableView == tbDebidCard {
            let cell = tableView.dequeueReusableCell(withIdentifier: "debitCardCell", for: indexPath) as! AddCardCell
            if cards.count > 0 {
                let card = cards[indexPath.row]
                cell.lblVisa.text = "\(card.brand)"
                cell.lblNumber.text = "...\(card.last4Digits)"
            }
            return cell
        }
        
        let cell = tableView.dequeueReusableCell(withIdentifier: "bankAccountCell", for: indexPath) as! AddBankAccountCell
        return cell
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 60
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
    }
}




// MARK:- Extension: Stripe
extension AddCardViewController: STPAddCardViewControllerDelegate {
    
    func addCardViewControllerDidCancel(_ addCardViewController: STPAddCardViewController) {
        
        navigationController?.popViewController(animated: true)
        
        let alertController = UIAlertController.init(title: "Alert!", message: "Card is not added yet.", preferredStyle: .alert)
        let cancelAction = UIAlertAction(title: "OK", style: .cancel, handler: nil)
        alertController.addAction(cancelAction)
        self.present(alertController, animated: true, completion: nil)
    }
    
    func addCardViewController(_ addCardViewController: STPAddCardViewController, didCreateToken token: STPToken, completion: @escaping STPErrorBlock) {
        DispatchQueue.main.async {
            self.stripeToken = "\(token)"
            if self.stripeToken.contains(" ") {
                self.stripeToken = self.stripeToken.components(separatedBy: " ").first ?? ""
            }
            self.navigationController?.popViewController(animated: true)
            self.addCard(withToken: self.stripeToken)
        }
    }
}
