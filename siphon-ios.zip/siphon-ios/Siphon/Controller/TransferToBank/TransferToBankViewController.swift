//
//  TransferToBankViewController.swift
//  Siphon
//
//  Created by Developer ST on 19/09/18.
//  Copyright © 2018 XYZ. All rights reserved.
//

import UIKit
import Stripe


class TransferToBankViewController: UIViewController {
    
    // MARK:- IBOutlets
    @IBOutlet weak var btnNext: UIButton!
    @IBOutlet weak var lblMoney: UILabel!
    @IBOutlet weak var btnBack: UIButton!
    

    // MARk:- Instances
    var stripeToken = ""
    var isFromMyAccount: Bool?

    
    // MARK:- View LifeCycle
    override func viewDidLoad() {
        super.viewDidLoad()
        setInitials()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        setupView()
        self.navigationController?.isNavigationBarHidden = true
    }
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
    }
    
    override func viewDidDisappear(_ animated: Bool) {
        super.viewDidDisappear(animated)
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
    
    
    
    // MARK:- Private function
    private func setInitials() {
        if let isFromMyAccnt = self.isFromMyAccount, isFromMyAccnt == true {
            btnBack.isHidden = false
        }
        else {
            btnBack.isHidden = true
        }
    }
    
    private func setupView() {
        getBalance()
     }
    
    
    
    // MARK:- IBActions
    @IBAction func backTap(_ sender: UIButton) {
        self.navigationController?.popViewController(animated: true)
    }
    
    @IBAction func selectCardTap(_ sender: UIButton) {
        
        if lblMoney.text != "$0.00" {
            let addCardViewController = STPAddCardViewController()
            addCardViewController.managedAccountCurrency = "USD"
            addCardViewController.delegate = self
            navigationController?.isNavigationBarHidden = false
            navigationController?.pushViewController(addCardViewController, animated: true)
        }
        else {
            let alertController = UIAlertController.init(title: "Alert!", message: "Insufficient balance to transfer.", preferredStyle: .alert)
            let cancelAction = UIAlertAction(title: "OK", style: .cancel, handler: nil)
            alertController.addAction(cancelAction)
            self.present(alertController, animated: true, completion: nil)
        }
    }
    
    @IBAction func selectBankTap(_ sender: UIButton) {
    }
    
    @IBAction func nextTap(_ sender: UIButton) {
    }
    
    
    
    // MARK:- API functions
    func getBalance()
    {
        NetworkHelper().postAPIRequest(withParameters: ["":""], withURLStr: "/siphon/accountBalance", withViewController: self, withSuccess: { (resultDict) in
            DispatchQueue.main.async {
                if let accntData = resultDict["account"] as? [String: Any] {
                    if let balArr = accntData["available"] as? [[String: Any]] {
                        let balAvailableDict = balArr[0]
                        if let balAvailable = balAvailableDict["amount"] as? Int {
                            self.lblMoney.text =  String(format: "$%.2f", Float(balAvailable)/100.00)
                        }
                    }
                }
            }
        }) { (resultDict) in
        }
    }

    func setPayoutAccount(withToken: String) {
        NetworkHelper().postAPIRequest(withParameters: ["token_debit_card": withToken], withURLStr: "/siphon/payoutRequest", withViewController: self, withSuccess: { (resultDict) in
            DispatchQueue.main.async {
                self.navigationController?.popViewController(animated: true)
                
                if let msg = resultDict["message"] {
                    self.getBalance()
                    let alertController = UIAlertController.init(title: nil, message: "\(msg)", preferredStyle: .alert)
                    let cancelAction = UIAlertAction(title: "OK", style: .cancel, handler: nil)
                    alertController.addAction(cancelAction)
                    self.present(alertController, animated: true, completion: nil)
                }
            }
        }) { (resultDict) in
        }
    }
}




// MARK:- Extension: Stripe
extension TransferToBankViewController: STPAddCardViewControllerDelegate {
    
    func addCardViewControllerDidCancel(_ addCardViewController: STPAddCardViewController) {
        
        navigationController?.popViewController(animated: true)
        
        let alertController = UIAlertController.init(title: "Alert!", message: "Money transfer canceled by you.", preferredStyle: .alert)
        let cancelAction = UIAlertAction(title: "OK", style: .cancel, handler: nil)
        alertController.addAction(cancelAction)
        self.present(alertController, animated: true, completion: nil)
    }
    
    func addCardViewController(_ addCardViewController: STPAddCardViewController, didCreateToken token: STPToken, completion: @escaping STPErrorBlock) {
        
        DispatchQueue.main.async {
            self.stripeToken = "\(token)"
            if self.stripeToken.contains(" ") {
                self.stripeToken = self.stripeToken.components(separatedBy: " ").first ?? ""
            }
            
            guard let fundingType = token.card?.funding else {
                let alertController = UIAlertController.init(title: "Alert!", message: "Please provide valid debit card details.", preferredStyle: .alert)
                let cancelAction = UIAlertAction(title: "OK", style: .cancel, handler: nil)
                alertController.addAction(cancelAction)
                self.present(alertController, animated: true, completion: nil)
                self.navigationController?.popViewController(animated: true)
                return
            }
            
            if fundingType == .debit {
                self.setPayoutAccount(withToken: self.stripeToken)
            }
            else {
                self.navigationController?.popViewController(animated: true)
                let alertController = UIAlertController.init(title: "Alert!", message: "Please provide valid debit card details.", preferredStyle: .alert)
                let cancelAction = UIAlertAction(title: "OK", style: .cancel, handler: nil)
                alertController.addAction(cancelAction)
                self.present(alertController, animated: true, completion: nil)
            }
        }
    }
}
