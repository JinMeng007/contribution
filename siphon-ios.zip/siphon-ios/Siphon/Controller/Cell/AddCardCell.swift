//
//  AddCardCell.swift
//  Siphon
//
//  Created by Developer ST on 19/09/18.
//  Copyright © 2018 XYZ. All rights reserved.
//

import UIKit

class AddCardCell: UITableViewCell {
    
    // MARK:- IBOutlets
    @IBOutlet weak var lblVisa, lblNumber: UILabel!
}
