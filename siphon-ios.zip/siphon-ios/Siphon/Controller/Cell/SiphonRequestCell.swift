//
//  SiphonRequestCell.swift
//  Siphon
//
//  Created by Developer ST on 28/09/18.
//  Copyright © 2018 XYZ. All rights reserved.
//

import UIKit

class SiphonRequestCell: UITableViewCell {

    // MARK:- IBOutlets
    @IBOutlet weak var lblRequest: UILabel!
        @IBOutlet weak var btnDecline, btnAccept: UIButton!
  }
