//
//  CurrentSiphonsCell.swift
//  Siphon
//
//  Created by Kamaljeet Punia on 19/09/18.
//  Copyright © 2018 XYZ. All rights reserved.
//

import UIKit

class CurrentSiphonsCell: UITableViewCell {
    
    // MARK:- IBOutlets
    @IBOutlet weak var moneyTypeImage: UIImageView!
    @IBOutlet weak var lblDays, lblMoneyDescription: UILabel!   
}
