//
//  LoginViewController.swift
//  Siphon
//
//  Created by STUser on 18/09/18.
//  Copyright © 2018 XYZ. All rights reserved.
//

import UIKit

class SignInViewController: UIViewController {
    
    // MARK:- IBOutlets
    @IBOutlet weak var tfUsername, tfPassword: UITextField!

    // MARK:- View LifeCycle
    override func viewDidLoad() {
        
        super.viewDidLoad()
        setInitials()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
    }
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        
        super.viewWillDisappear(animated)
        resetTextfields()
    }
    
    override func viewDidDisappear(_ animated: Bool) {
        super.viewDidDisappear(animated)
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
    
    
    
    // MARK:- Private function
    private func setInitials() {
        
        AppDelegate.signInVC = self
    }
    
    private func setupView() {
    }
    
    private func resetTextfields() {
        
        tfUsername.text = ""
        tfPassword.text = ""
    }

    
    
    // MARK:- IBAction
    @IBAction func loginTap(_ sender: UIButton) {
    
        self.loginAPI ()
        self.view.endEditing(true)
    }
    
    @IBAction func signUpTap(_ sender: UIButton) {
    }
    
    @IBAction func forgotPasswordTap(_ sender: UIButton) {
        
    }
    
    // MARK:- API functions
    func loginAPI () {
        
        // Check the validity of the input data...
        if isDataValid() != true {
            
            return
        }
        
        // Manage whitespace start and end point on textfield...
        let usernameStr = tfUsername.text?.trimmingCharacters(in: NSCharacterSet.whitespacesAndNewlines)
        let passwordStr = tfPassword.text?.trimmingCharacters(in: NSCharacterSet.whitespacesAndNewlines)
        
        NetworkHelper.isLoginAPI = true
        NetworkHelper().postAPIRequest(withParameters: ["username": usernameStr ?? "", "password": passwordStr ?? ""], withURLStr: "/user/login", withViewController: self, withSuccess: { (resultDict) in
            DispatchQueue.main.async {
                
                if let userData = resultDict["user"] as? [String: Any]
                {
                    if let userToken = userData["access_token"], let userID = userData["id"]
                    {
                        UserDefaults.standard.set("\(userID)", forKey: "userID")
                        UserDefaults.standard.set("\(userToken)", forKey: "token")
                        UserDefaults.standard.synchronize()
                        
                        let nextVC = UIStoryboard(name: "MoneyTransfer", bundle: nil).instantiateViewController(withIdentifier: "BaseTabBC") as? BaseTabBarController
                        self.present(nextVC!, animated: true, completion: nil)
                    }
                    else
                    {
                        let alert = UIAlertController(title: "SignIn Failure", message: "Some server error occured. Please try again later.", preferredStyle: UIAlertControllerStyle.alert)
                        alert.addAction(UIAlertAction(title: "OK", style: UIAlertActionStyle.default, handler: nil))
                        self.present(alert, animated: true, completion: nil)
                    }
                }
                else
                {
                    let alert = UIAlertController(title: "SignIn Failure", message: "Some server error occured. Please try again later.", preferredStyle: UIAlertControllerStyle.alert)
                    alert.addAction(UIAlertAction(title: "OK", style: UIAlertActionStyle.default, handler: nil))
                    self.present(alert, animated: true, completion: nil)
                }
            }
        }, withFailure: { (resultDict) in
            DispatchQueue.main.async {
                
                if let statusCode = resultDict["code"] as? Int, let message = resultDict["message"] as? String
                {
                    if statusCode == 401 {
                        
                        let alert = UIAlertController(title: "SignIn Failure", message: "\(message)", preferredStyle: UIAlertControllerStyle.alert)
                        alert.addAction(UIAlertAction(title: "OK", style: UIAlertActionStyle.default, handler: nil))
                        self.present(alert, animated: true, completion: nil)
                    }
                }
            }
        })
    }
    
    // MARK:- Validation function
    func isDataValid () -> Bool {
        
        var isValid = true
        
        if tfUsername.text?.count == 0 {
            
            let alert = UIAlertController(title: "Invalid Input", message: "Please provide a valid username", preferredStyle: UIAlertControllerStyle.alert)
            alert.addAction(UIAlertAction(title: "OK", style: UIAlertActionStyle.default, handler: nil))
            self.present(alert, animated: true, completion: nil)
            
            isValid = false
        }
        
        if tfPassword.text?.count == 0 {
            
            let alert = UIAlertController(title: "Invalid Input", message: "Please provide a valid password", preferredStyle: UIAlertControllerStyle.alert)
            alert.addAction(UIAlertAction(title: "OK", style: UIAlertActionStyle.default, handler: nil))
            self.present(alert, animated: true, completion: nil)
            
            isValid = false
        }
        
        return isValid
    }
}


