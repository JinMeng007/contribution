//
//  SignupViewController.swift
//  Siphon
//
//  Created by STUser on 18/09/18.
//  Copyright © 2018 XYZ. All rights reserved.
//

import UIKit

class SignUpViewController: UIViewController {
    
    // MARK:- IBOutlets
    @IBOutlet weak var tfEmail, tfUsername, tfPassword, tfDisplayName, tfPhoneNumber: UITextField!

    
    
    // MARK:- View LifeCycle
    override func viewDidLoad() {
        super.viewDidLoad()
        setInitials()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
    }
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        
        // Clear textField
        tfEmail.text = ""
        tfUsername.text = ""
        tfPassword.text = ""
        tfDisplayName.text = ""
        tfPhoneNumber.text = ""
        
    }
    
    override func viewDidDisappear(_ animated: Bool) {
        super.viewDidDisappear(animated)
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
    
    
    
    // MARK:- Private function
    private func setInitials() {
        
        AppDelegate.signUpVC = self
    }
    
    private func setupView() {
    }
    
    
    
    // MARK:- IBActions
    @IBAction func sighUpTap(_ sender: UIButton) {
        
        signupAPI()
        self.view.endEditing(true)
    }
    
    @IBAction func signInTap(_ sender: UIButton) {
        
        self.dismiss(animated: true, completion: nil)
    }
    
    @IBAction func forgotPasswordTap(_ sender: UIButton) {
    }
    
    
    
    // MARK:- API function
    func signupAPI () {
        
        // Manage whitespace start and end point on textfield...
        let emailStr = tfEmail.text?.trimmingCharacters(in: NSCharacterSet.whitespacesAndNewlines)
        let usernameStr = tfUsername.text?.trimmingCharacters(in: NSCharacterSet.whitespacesAndNewlines)
        let passwordStr = tfPassword.text?.trimmingCharacters(in: NSCharacterSet.whitespacesAndNewlines)
        let displayName = tfDisplayName.text?.trimmingCharacters(in: NSCharacterSet.whitespacesAndNewlines)
        let phoneNumber = tfPhoneNumber.text?.trimmingCharacters(in: NSCharacterSet.whitespacesAndNewlines)

        if isDataValid() != true {
            
            return
        }
        
        
        NetworkHelper().postAPIRequest(withParameters:  ["username": usernameStr ?? "", "password": passwordStr ?? "", "email": emailStr ?? "", "phonenumber": phoneNumber ?? "", "firstname": displayName ?? ""], withURLStr: "/user/signup", withViewController: self, withSuccess: { (resultDict) in
            DispatchQueue.main.async {
                
                if let userData = resultDict["user"] as? [String: Any] {
                    
                    if let userToken = userData["access_token"], let userID = userData["id"] {
                        
                        UserDefaults.standard.set("\(userID)", forKey: "userID")
                        UserDefaults.standard.set("\(userToken)", forKey: "token")
                        UserDefaults.standard.synchronize()
                        
                        
                        let baseTabBC = UIStoryboard.init(name: "MoneyTransfer", bundle: nil).instantiateViewController(withIdentifier: "BaseTabBC") as! BaseTabBarController
                        self.present(baseTabBC, animated: true, completion: {
                            
                        })
                    }
                    else {
                        
                        let alert = UIAlertController(title: "Signup Failure", message: "Some server error occured. Please try again later.", preferredStyle: UIAlertControllerStyle.alert)
                        alert.addAction(UIAlertAction(title: "OK", style: UIAlertActionStyle.default, handler: nil))
                        self.present(alert, animated: true, completion: nil)
                    }
                }
                else {
                    
                    let alert = UIAlertController(title: "Signup Failure", message: "Some server error occured. Please try again later.", preferredStyle: UIAlertControllerStyle.alert)
                    alert.addAction(UIAlertAction(title: "OK", style: UIAlertActionStyle.default, handler: nil))
                    self.present(alert, animated: true, completion: nil)
                }
            }
        }, withFailure: { (resultDict) in
            
            DispatchQueue.main.async {
                
                if let statusCode = resultDict["code"] as? Int, let message = resultDict["message"] as? String {
                    
                    if statusCode == 400 {
                        
                        let alert = UIAlertController(title: "Signup Failure", message: "\(message)", preferredStyle: UIAlertControllerStyle.alert)
                        alert.addAction(UIAlertAction(title: "OK", style: UIAlertActionStyle.default, handler: nil))
                        self.present(alert, animated: true, completion: nil)
                    }
                }
            }
        })
    }
    
    
    
    // MARK:- Validation Function
    func isDataValid () -> Bool {
        
        var isValid = true
        
        // Manage whitespace start and end point on textfield...
        let emailStr = tfEmail.text?.trimmingCharacters(in: NSCharacterSet.whitespacesAndNewlines)
        let usernameStr = tfUsername.text?.trimmingCharacters(in: NSCharacterSet.whitespacesAndNewlines)
        let passwordStr = tfPassword.text?.trimmingCharacters(in: NSCharacterSet.whitespacesAndNewlines)
        let displayName = tfDisplayName.text?.trimmingCharacters(in: NSCharacterSet.whitespacesAndNewlines)
        let phoneNumber = tfPhoneNumber.text?.trimmingCharacters(in: NSCharacterSet.whitespacesAndNewlines)
        
        if emailStr?.count == 0 || usernameStr?.count == 0 || passwordStr?.count == 0 || displayName?.count == 0 || phoneNumber?.count == 0 {
           
            let alert = UIAlertController(title: "Invalid Input", message: "All fields are mandatory.", preferredStyle: UIAlertControllerStyle.alert)
            alert.addAction(UIAlertAction(title: "OK", style: UIAlertActionStyle.default, handler: nil))
            self.present(alert, animated: true, completion: nil)
            
            isValid = false
        }
        
        if tfEmail.text?.isValidEmail != true {
            
            let alert = UIAlertController(title: "Invalid Input", message: "Please provide a valid email", preferredStyle: UIAlertControllerStyle.alert)
            alert.addAction(UIAlertAction(title: "OK", style: UIAlertActionStyle.default, handler: nil))
            self.present(alert, animated: true, completion: nil)
            
            isValid = false
        }
        
        
        
        return isValid
    }
}

// MARK:- Extension: String
extension String {
    
    var isValidEmail: Bool {
        
        let emailRegEx = "[A-Z0-9a-z._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,20}"
        let emailTest  = NSPredicate(format:"SELF MATCHES %@", emailRegEx)
        return emailTest.evaluate(with: self)
    }
    
}
