//
//  PopupViewController.swift
//  Siphon
//
//  Created by STUser on 18/09/18.
//  Copyright © 2018 XYZ. All rights reserved.
//

import UIKit

class PopupViewController: UIViewController {
    
    // MARK:- IBOutlets
    @IBOutlet weak var imgViewBG, imgRequestingUser: UIImageView!
    @IBOutlet weak var viewRequestPopup, viewConfirmationPopup: UIView!
    @IBOutlet weak var lblDescriptionRequestPopup, lblDescriptionConfirmationPopup: UILabel!
    @IBOutlet weak var constRequestPopupViewTop, constConfirmationPopupViewTop: NSLayoutConstraint!
    
    
    // MARK:- View LifeCycle
    override func viewDidLoad() {
        
        super.viewDidLoad()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        
        super.viewWillAppear(animated)
    }
    
    override func viewDidAppear(_ animated: Bool) {
        
        super.viewDidAppear(animated)
        setupView()
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        
        super.viewWillDisappear(animated)
    }
    
    override func viewDidDisappear(_ animated: Bool) {
        
        super.viewDidDisappear(animated)
    }
    
    override func didReceiveMemoryWarning() {
        
        super.didReceiveMemoryWarning()
    }
    
    // MARK:- Private function
    private func setInitials() {
    }
    
    private func setupView() {
        
        imgViewBG.alpha = 0.7
        showRequestPopup()
    }
    
    // MARK:- IBActions
    @IBAction func confirmTap(_ sender: UIButton) {
        
    }
    
    @IBAction func cancelTap(_ sender: UIButton) {
        
        UIView.animate(withDuration: 0.3, animations: {
            
            self.constConfirmationPopupViewTop.constant = UIScreen.main.bounds.height + 200
            self.view.layoutIfNeeded()
        }) { (true) in
            
            self.removeFromParentViewController()
            self.view.removeFromSuperview()
        }
    }
    
    @IBAction func acceptTap(_ sender: UIButton) {
        
    }
    
    @IBAction func declineTap(_ sender: UIButton) {
        
        UIView.animate(withDuration: 0.3, animations: {
            
            self.constRequestPopupViewTop.constant = UIScreen.main.bounds.height + 200
            self.view.layoutIfNeeded()
        }) { (true) in
            
            self.removeFromParentViewController()
            self.view.removeFromSuperview()
        }
    }
    
    
    // MARK:- Animation functions
    func showRequestPopup()
    {
        UIView.animate(withDuration: 0.5, delay: 0.3, usingSpringWithDamping: 0.8, initialSpringVelocity: 0, options: [],  animations: {
            
            self.constRequestPopupViewTop.constant = (UIScreen.main.bounds.size.height/2.0) - (self.viewRequestPopup.frame.size.height/1.5)
            self.view.layoutIfNeeded()
        })
    }
    
    func showConfirmationPopup()
    {
        UIView.animate(withDuration: 0.5, delay: 0.3, usingSpringWithDamping: 0.8, initialSpringVelocity: 0, options: [],  animations: {
            
            self.constConfirmationPopupViewTop.constant = (UIScreen.main.bounds.size.height/2.0) - (self.viewConfirmationPopup.frame.size.height/1.5)
            self.view.layoutIfNeeded()
        })
    }
    
}
