//
//  BaseTabBarController.swift
//  Siphon
//
//  Created by STUser on 18/09/18.
//  Copyright © 2018 XYZ. All rights reserved.
//

import UIKit

class BaseTabBarController: UITabBarController {

    // MARK:- View LifeCycle
    override func viewDidLoad() {
        
        super.viewDidLoad()
        setInitials()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
    }
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
    }
    
    override func viewDidDisappear(_ animated: Bool) {
        super.viewDidDisappear(animated)
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
    
    
    
    // MARK:- Private function
    private func setInitials() {  
        AppDelegate.baseTabBC = self
    }
    
    private func setupView() {
    }

}
