//
//  AppDelegate.swift
//  Siphon
//
//  Created by STUser on 18/09/18.
//  Copyright © 2018 XYZ. All rights reserved.
//

import UIKit
import Stripe
import IQKeyboardManagerSwift


@UIApplicationMain
class AppDelegate: UIResponder, UIApplicationDelegate {

    // MARK:- Application Level Instances
    var window: UIWindow?
    static let StripePKey = "pk_test_aLLtusb9dFIaveQgbPqTRm23"
    static var signInVC: SignInViewController?
    static var signUpVC: SignUpViewController?
    static var baseTabBC: BaseTabBarController?

    
    
    // MARK:- Application LifeCycle
    func application(_ application: UIApplication, didFinishLaunchingWithOptions launchOptions: [UIApplicationLaunchOptionsKey: Any]?) -> Bool {
        
        // Check whether user already logged-in...
        sessionCheck()
       
        // Configuring Stripe...
        STPPaymentConfiguration.shared().publishableKey = AppDelegate.StripePKey
       
        // To handle the keyboard w.r.t. Textfields...
        IQKeyboardManager.shared.enable = true
       
        return true
    }

    func applicationWillResignActive(_ application: UIApplication) {
    }

    func applicationDidEnterBackground(_ application: UIApplication) {
    }

    func applicationWillEnterForeground(_ application: UIApplication) {
    }

    func applicationDidBecomeActive(_ application: UIApplication) {
    }

    func applicationWillTerminate(_ application: UIApplication) {
    }
    
    
    // MARK:- Private functions
    private func sessionCheck() {

        if UserDefaults.standard.object(forKey: "token") != nil {

            let baseTabBC = UIStoryboard.init(name: "MoneyTransfer", bundle: nil).instantiateViewController(withIdentifier: "BaseTabBC") as! BaseTabBarController
            self.window?.rootViewController = baseTabBC
        }
   }
}







