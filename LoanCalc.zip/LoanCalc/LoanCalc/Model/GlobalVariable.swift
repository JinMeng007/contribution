//
//  GlobalVariable.swift
//  LoanCalc
//
//  Created by MaskX on 4/22/19.
//  Copyright © 2019 LoanCalc. All rights reserved.
//

class GlobalVariable {
    class var sharedInstance: GlobalVariable {
        struct Static {
            static let instance: GlobalVariable = GlobalVariable()
        }
        return Static.instance
    }
    
    var runNumber = 0
    
}
