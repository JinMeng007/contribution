//
//  Constant.swift
//  LoanCalc
//
//  Created by MaskX on 4/22/19.
//  Copyright © 2019 LoanCalc. All rights reserved.
//

class Constant {
    class var sharedInstance: Constant {
        struct Static {
            static let instance: Constant = Constant()
        }
        return Static.instance
    }
    
    let GOOGLE_URL_STR = "https://google.com/"
    let STRIPE_URL_STR = "https://stripe.com/"
    
}

