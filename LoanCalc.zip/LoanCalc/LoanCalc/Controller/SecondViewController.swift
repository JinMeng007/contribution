//
//  SecondViewController.swift
//  LoanCalc
//
//  Created by MaskX on 4/22/19.
//  Copyright © 2019 LoanCalc. All rights reserved.
//

import UIKit

class SecondViewController: UIViewController, UIWebViewDelegate {

    
    @IBOutlet weak var activity: UIActivityIndicatorView!
    @IBOutlet weak var webView: UIWebView!
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        initialization()
        configurationUI()
    }
    
    func initialization() {
        let loadStr = Constant.sharedInstance.STRIPE_URL_STR
        self.webViewLoad(url: loadStr)
    }
    
    func configurationUI() {
        
    }
    
    func webViewLoad(url: String){
        if let urlStr = URL(string: url) {
            let request = URLRequest(url: urlStr)
            self.webView.loadRequest(request)
            
        }
    }
    
    
    func webViewDidStartLoad(_ webView: UIWebView) {
        activity.startAnimating()
    }
    
    func webViewDidFinishLoad(_ webView: UIWebView) {
        activity.stopAnimating()
    }
    
    func webView(_ webView: UIWebView, didFailLoadWithError error: Error) {
        activity.stopAnimating()
    }
    


}

