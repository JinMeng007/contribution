//
//  FirstViewController.swift
//  LoanCalc
//
//  Created by MaskX on 4/22/19.
//  Copyright © 2019 LoanCalc. All rights reserved.
//

import UIKit
import UIView_Shake
import EggRating

class FirstViewController: UIViewController, EggRatingDelegate {
    
    

    //
    @IBOutlet weak var loanAmountTextField: UITextField!
    @IBOutlet weak var yearTextField: UITextField!
    @IBOutlet weak var monthTextField: UITextField!
    @IBOutlet weak var percentTextField: UITextField!
    //
    @IBOutlet weak var loanView: UIView!
    @IBOutlet weak var yearView: UIView!
    @IBOutlet weak var monthView: UIView!
    @IBOutlet weak var percentView: UIView!
    //
    //
    let primaryColor = #colorLiteral(red: 0.6271930337, green: 0.3653797209, blue: 0.8019730449, alpha: 1)
    let primaryColorDark = #colorLiteral(red: 0.5373370051, green: 0.2116269171, blue: 0.7118118405, alpha: 1)
    
    //
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        /*
        let randomInt = Int.random(in: 1...4)
        if GlobalVariable.sharedInstance.runNumber % randomInt == 0 {
            self.appRating()
        }
         */
        self.initialization()
    }
    
    func appRating() {
        EggRating.delegate = self
        //EggRating.promptRateUsIfNeeded(in: self)
        EggRating.promptRateUs(in: self)
    }
    
    func initialization() {
        self.loanAmountTextField.text?.removeAll()
        self.yearTextField.text?.removeAll()
        self.monthTextField.text?.removeAll()
        self.percentTextField.text?.removeAll()
    }
    
    @IBAction func loanAmountValueChanged(_ sender: UITextField) {
        if let loanAmount = self.loanAmountTextField.text?.currencyInputFormatting() {
            self.loanAmountTextField.text = loanAmount
        }
    }
    
    @IBAction func yearTextFieldValueChanged(_ sender: UITextField) {
        let months = (Float(self.yearTextField?.text ?? "0") ?? 0) * 12
        self.monthTextField.text = "\(months)"
        
        if self.yearTextField.text?.isEmpty ?? false {
            self.monthTextField.text?.removeAll()
        }
    }
    
    @IBAction func monthTextFieldValueChanged(_ sender: UITextField) {
        let years = (Float(self.monthTextField?.text ?? "0") ?? 0) / 12
        self.yearTextField.text = "\(years)"
        
        if self.monthTextField.text?.isEmpty ?? false {
            self.yearTextField.text?.removeAll()
        }
    }
    
    @IBAction func percentTextFieldValueChanged(_ sender: UITextField) {
        if Int(self.percentTextField?.text ?? "0") ?? 0 > 99 {
            self.percentTextField.text?.removeLast()
        }
    }
    
    @IBAction func calculateAction(_ sender: UIButton) {
        var amountStr = self.loanAmountTextField.text
        amountStr = amountStr?.replacingOccurrences(of: ",", with: "")
        let amountValue = Float(amountStr ?? "0.00") ?? 0.00
        
        let yearStr = self.yearTextField.text
        let yearValue = Float(yearStr ?? "0.00") ?? 0.00
        
        let monthStr = self.monthTextField.text
        let monthValue = Float(monthStr ?? "0.00") ?? 0.00
        
        let percentStr = self.percentTextField.text
        let percentValue = Float(percentStr ?? "0.00") ?? 0.00
        
        
        if amountStr?.isEmpty ?? false {
            self.loanView.shake()
        } else if yearStr?.isEmpty ?? false {
            self.yearView.shake()
        } else if monthStr?.isEmpty ?? false {
            self.monthView.shake()
        } else if percentStr?.isEmpty ?? false {
            self.percentView.shake()
        } else { // Calculate the 'Payment Amount per Period'
            let r = percentValue / 1200
            let n = monthValue
            let P = amountValue
            
            
            let upValue = r * powf(1 + r , n)
            let downValue = pow(1 + r, n) - 1
            
            let A = P * (upValue / downValue)
            print(A)
            
            self.confirmationDialog(monthlyPayments: "$ \(A)")
        }
        
    }
    
    func confirmationDialog(monthlyPayments: String) {
        let dialogController = AZDialogViewController(title: "Monthly Payments",
                                                      message: monthlyPayments)
        
        dialogController.showSeparator = true
        
        dialogController.dismissDirection = .bottom
        
        dialogController.imageHandler = { (imageView) in
            imageView.image = UIImage(named: "confirmation")
            //imageView.frame.size = CGSize(width: 30, height: 30)
            imageView.contentMode = .scaleAspectFill
            return true
        }
        
        dialogController.addAction(AZDialogAction(title: "Okay", handler: { (dialog) -> (Void) in
            print("sendAction")
            dialogController.dismiss()
        }))
        
        dialogController.buttonStyle = { (button,height,position) in
            button.setBackgroundImage(UIImage.imageWithColor(self.primaryColor) , for: .normal)
            button.setBackgroundImage(UIImage.imageWithColor(self.primaryColorDark), for: .highlighted)
            button.setTitleColor(UIColor.white, for: [])
            button.layer.masksToBounds = true
            button.layer.borderColor = self.primaryColor.cgColor
            button.tintColor = .white
        }
        
        dialogController.blurBackground = true
        dialogController.blurEffectStyle = .dark
        
        dialogController.rightToolStyle = { (button) in
            //button.setImage(#imageLiteral(resourceName: "share"), for: [])
            button.setTitle("X", for: .normal)
            button.tintColor = .lightGray
            return true
        }
        
        dialogController.rightToolAction = { (button) in
            print("dismiss function")
            dialogController.dismiss()
        }
        
        dialogController.dismissWithOutsideTouch = true
        dialogController.show(in: self)
    }
   
    func didRate(rating rate: Double) {
        print("didRate: \(rate)")
    }
    
    func didIgnoreToRate() {
        print("didIgnoreToRate")
    }
    
    func didRateOnAppStore() {
        print("didRateOnAppStore")
    }
    
    func didIgnoreToRateOnAppStore() {
        print("didIgnoreToRateOnAppStore")
    }
    
    func didDissmissThankYouDialog() {
        print("didDissmissThankYouDialog")
    }
    
}

