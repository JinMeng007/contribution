//
//  UPCarouselFlowLayout.h
//  UPCarouselFlowLayout
//
//  Created by Alex K. on 18/11/16.
//  Copyright © 2016 Paul Ulric. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for UPCarouselFlowLayout.
FOUNDATION_EXPORT double UPCarouselFlowLayoutVersionNumber;

//! Project version string for UPCarouselFlowLayout.
FOUNDATION_EXPORT const unsigned char UPCarouselFlowLayoutVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <UPCarouselFlowLayout/PublicHeader.h>


