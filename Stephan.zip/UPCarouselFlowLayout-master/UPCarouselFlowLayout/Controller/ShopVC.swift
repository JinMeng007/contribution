//
//  ViewController.swift
//  UPCarouselFlowLayoutDemo
//
//  Created by Paul Ulric on 23/06/2016.
//  Copyright © 2016 Paul Ulric. All rights reserved.
//

import UIKit
import SwiftMessages

class ShopVC: UIViewController, UICollectionViewDelegate, UICollectionViewDataSource {
    
    @IBOutlet weak var scrollView: UIScrollView!
    // parent item
    @IBOutlet weak var infoLabel: UILabel!
    @IBOutlet weak var detailLabel: UILabel!
    @IBOutlet weak var collectionView: UICollectionView!
    
    // sub item
    @IBOutlet weak var subCollectionView: UICollectionView!
    @IBOutlet weak var subInfoLabel: UILabel!
    @IBOutlet weak var subDetailLabel: UILabel!
    //
    let primaryColor = #colorLiteral(red: 0.6271930337, green: 0.3653797209, blue: 0.8019730449, alpha: 1)
    let primaryColorDark = #colorLiteral(red: 0.5373370051, green: 0.2116269171, blue: 0.7118118405, alpha: 1)
    //
    fileprivate var items = [Character]()
    fileprivate var subItems = [Character]()
    
    fileprivate var currentPage: Int = 0 {
        didSet {
            let character = self.items[self.currentPage]
            self.infoLabel.text = character.name
            self.detailLabel.text = character.movie
            self.subInfoLabel.text = character.name
        }
    }
    
    fileprivate var currentSubPage: Int = 0 {
        didSet {
            let subCharacter = self.subItems[self.currentSubPage]
            self.subDetailLabel.text = subCharacter.movie
        }
    }
    
    fileprivate var pageSize: CGSize {
        let layout = self.collectionView.collectionViewLayout as! UPCarouselFlowLayout
        var pageSize = layout.itemSize
        if layout.scrollDirection == .horizontal {
            pageSize.width += layout.minimumLineSpacing
        } else {
            pageSize.height += layout.minimumLineSpacing
        }
        return pageSize
    }
    
    fileprivate var orientation: UIDeviceOrientation {
        return UIDevice.current.orientation
    }
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.setupLayout()
        
        // scrollview configuration
        scrollView.contentSize = CGSize(width: self.scrollView.frame.width, height: 1000)
        
        self.items = self.createItems()
        self.subItems = self.createSubItem1()
        
        self.currentPage = 0
        
        NotificationCenter.default.addObserver(self, selector: #selector(ShopVC.rotationDidChange), name: UIDevice.orientationDidChangeNotification, object: nil)
    }
    
    fileprivate func setupLayout() {
        let layout = self.collectionView.collectionViewLayout as! UPCarouselFlowLayout
        layout.spacingMode = UPCarouselFlowLayoutSpacingMode.overlap(visibleOffset: 30)
        let subLayout = self.subCollectionView.collectionViewLayout as! UPCarouselFlowLayout
        subLayout.spacingMode = UPCarouselFlowLayoutSpacingMode.overlap(visibleOffset: 30)
    }
    
    fileprivate func createItems() -> [Character] {
        let characters = [
            Character(imageName: "cosmetic", name: "Cosmetic", movie: "SuperMarket"),
            Character(imageName: "boost", name: "Boost", movie: "Shop Inc."),
            Character(imageName: "currencyGif", name: "Currency", movie: "ExchangeInfo LLC."),
            Character(imageName: "onepiece", name: "Onepiece", movie: "Beautiful Com."),
            Character(imageName: "upgrade", name: "Upgrade", movie: "Upgradable Cop."),
        ]
        return characters
    }
    
    fileprivate func createSubItem1() -> [Character] {
        let characters = [
            Character(imageName: "100", name: "100", movie: "100"),
            Character(imageName: "200", name: "200", movie: "200"),
            Character(imageName: "300", name: "300", movie: "300"),
            Character(imageName: "400", name: "400", movie: "400"),
            Character(imageName: "500", name: "500", movie: "400"),
            ]
        return characters
    }
    
    
    @objc fileprivate func rotationDidChange() {
        guard !orientation.isFlat else { return }
        let layout = self.collectionView.collectionViewLayout as! UPCarouselFlowLayout
        let subLayout = self.subCollectionView.collectionViewLayout as! UPCarouselFlowLayout
        let direction: UICollectionView.ScrollDirection = orientation.isPortrait ? .horizontal : .vertical
        layout.scrollDirection = direction
        subLayout.scrollDirection = direction
        if currentPage > 0 {
            let indexPath = IndexPath(item: currentPage, section: 0)
            let scrollPosition: UICollectionView.ScrollPosition = orientation.isPortrait ? .centeredHorizontally : .centeredVertically
            self.collectionView.scrollToItem(at: indexPath, at: scrollPosition, animated: false)
            self.subCollectionView.scrollToItem(at: indexPath, at: scrollPosition, animated: false)
        }
    }
    
    // MARK: - Card Collection Delegate & DataSource
    
    func numberOfSections(in collectionView: UICollectionView) -> Int {
        return 1
    }
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        if collectionView == self.subCollectionView {
            return items.count
        } else {
            return subItems.count
        }
        
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        if collectionView == self.collectionView {
            let cell = collectionView.dequeueReusableCell(withReuseIdentifier: CarouselCollectionViewCell.identifier, for: indexPath) as! CarouselCollectionViewCell
            let character = items[(indexPath as NSIndexPath).row]
            cell.image.loadGif(asset: character.imageName)
            cell.image.image = UIImage(named: character.imageName)
            return cell
        } else {
            let cell = self.subCollectionView.dequeueReusableCell(withReuseIdentifier: CarouselCollectionViewCell.identifier, for: indexPath) as! CarouselCollectionViewCell
            let character = subItems[(indexPath as NSIndexPath).row]
            cell.image.loadGif(asset: character.imageName)
            cell.image.image = UIImage(named: character.imageName)
            return cell
        }
        
    }
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        if collectionView == self.collectionView {
            let character = items[(indexPath as NSIndexPath).row]
            let alert = UIAlertController(title: character.name, message: nil, preferredStyle: .alert)
            alert.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
            present(alert, animated: true, completion: nil)
        } else {
            let character = subItems[(indexPath as NSIndexPath).row]
            let alert = UIAlertController(title: character.name, message: nil, preferredStyle: .alert)
            alert.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
            present(alert, animated: true, completion: nil)
        }
        
    }
    
    
    // MARK: - UIScrollViewDelegate
    func scrollViewDidEndDecelerating(_ scrollView: UIScrollView) {
        if scrollView == self.collectionView {
            let layout = self.collectionView.collectionViewLayout as! UPCarouselFlowLayout
            let pageSide = (layout.scrollDirection == .horizontal) ? self.pageSize.width : self.pageSize.height
            let offset = (layout.scrollDirection == .horizontal) ? scrollView.contentOffset.x : scrollView.contentOffset.y
            currentPage = Int(floor((offset - pageSide / 2) / pageSide) + 1)
        } else {
            // sub current page
            let subLayout = self.subCollectionView.collectionViewLayout as! UPCarouselFlowLayout
            let subpageSide = (subLayout.scrollDirection == .horizontal) ? self.pageSize.width : self.pageSize.height
            let suboffset = (subLayout.scrollDirection == .horizontal) ? scrollView.contentOffset.x : scrollView.contentOffset.y
            currentSubPage = Int(floor((suboffset - subpageSide / 2) / subpageSide) + 1)
        }
    }
    
    @IBAction func purchaseAction(_ sender: UIButton) {
        print("purchaseClickAction")
        self.confirmationDialog()
    }
    
    func confirmationDialog() {
        
        let shopItemMsg = "ITEM: " + self.infoLabel.text! + ", \n"
        let contactCompanyMsg = "CONTACT : " + self.detailLabel.text! + ", \n"
        let priceMsg = "PRICE $: " + self.subDetailLabel.text!
        
        let msg = shopItemMsg + contactCompanyMsg + priceMsg
        let dialogController = AZDialogViewController(title: "Confirm",
                                                      message: msg)
        
        dialogController.showSeparator = true
        
        dialogController.dismissDirection = .bottom
        
        dialogController.imageHandler = { (imageView) in
            imageView.image = UIImage(named: "confirmation")
            //imageView.frame.size = CGSize(width: 30, height: 30)
            imageView.contentMode = .scaleAspectFill
            
            return true
        }
        
        dialogController.addAction(AZDialogAction(title: "Okay", handler: { (dialog) -> (Void) in
            print("okay")
            dialogController.dismiss()
            // ok action
            //
            let success = MessageView.viewFromNib(layout: .cardView)
            success.configureTheme(.success)
            success.configureDropShadow()
            success.configureContent(title: "Purchased!", body: "Please contact me! - stephan@gmail.com")
            success.button?.isHidden = true
            var successConfig = SwiftMessages.defaultConfig
            successConfig.presentationStyle = .center
            successConfig.presentationContext = .window(windowLevel: UIWindow.Level.normal)
            SwiftMessages.show(config: successConfig, view: success)
            
        }))
        
        dialogController.buttonStyle = { (button,height,position) in
            button.setBackgroundImage(UIImage.imageWithColor(self.primaryColor) , for: .normal)
            button.setBackgroundImage(UIImage.imageWithColor(self.primaryColorDark), for: .highlighted)
            button.setTitleColor(UIColor.white, for: [])
            button.layer.masksToBounds = true
            button.layer.borderColor = self.primaryColor.cgColor
            button.tintColor = .white
            /*
             if position == 0 {
             let image = #imageLiteral(resourceName: "ic_bookmark").withRenderingMode(.alwaysTemplate)
             button.setImage(image, for: [])
             button.imageView?.contentMode = .scaleAspectFit
             }
             */
        }
        
        dialogController.blurBackground = true
        dialogController.blurEffectStyle = .dark
        
        dialogController.rightToolStyle = { (button) in
            //button.setImage(#imageLiteral(resourceName: "share"), for: [])
            button.setTitle("X", for: .normal)
            button.tintColor = .lightGray
            return true
        }
        
        dialogController.rightToolAction = { (button) in
            print("dismiss function")
            dialogController.dismiss()
        }
        
        dialogController.dismissWithOutsideTouch = true
        dialogController.show(in: self)
    }
    
    
    
    @IBAction func goBackAction(_ sender: UIButton) {
        self.navigationController?.popViewController(animated: true)
    }
    
    
}

