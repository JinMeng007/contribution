//
//  DashboardVC.swift
//  UPCarouselFlowLayoutDemo
//
//  Created by MaskX on 3/23/19.
//  Copyright © 2019 Paul Ulric. All rights reserved.
//

import UIKit

class DashboardVC: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    
    @IBAction func avatarAction(_ sender: UIButton) {
        self.gotoAvatarScreen()
    }
    
    
    @IBAction func shopAction(_ sender: UIButton) {
        self.gotoShopScreen()
    }
    
    
    func gotoAvatarScreen() {
        let storyboard: UIStoryboard? = UIStoryboard(name: "Main", bundle: nil)
        let rootVC = storyboard?.instantiateViewController(withIdentifier: "VC") as? ViewController
        self.navigationController?.pushViewController(rootVC!, animated: true)
        
    }
    
    func gotoShopScreen() {
        let storyboard: UIStoryboard? = UIStoryboard(name: "Main", bundle: nil)
        let rootVC = storyboard?.instantiateViewController(withIdentifier: "shopVC") as? ShopVC
        self.navigationController?.pushViewController(rootVC!, animated: true)
        
    }

}
