//
//  CreateProfileViewController.swift
//  Background Animation
//
//  Created by MaskX on 1/10/19.
//  Copyright © 2019 Chandan. All rights reserved.
//

import UIKit

class CreateProfileViewController: BaseViewController, UIImagePickerControllerDelegate, UIPopoverControllerDelegate, UINavigationControllerDelegate {

    
    @IBOutlet weak var profile_imageView: UIImageView!
    @IBOutlet weak var image_choose_button: UIButton!
    // picker view
    var picker: UIImagePickerController = UIImagePickerController()
    
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        // picker delegate
        picker.delegate = self
        self.profile_imageView.layer.cornerRadius = 114
        self.profile_imageView.clipsToBounds = true
    }

    @IBAction func goBackAction(_ sender: UIButton) {
        self.navigationController?.popViewController(animated: true)
    }
    
    @IBAction func nextAction(_ sender: UIButton) {
        let alert = UIAlertController(title: "Info", message: "Under the development!", preferredStyle: .alert)
        let ok = UIAlertAction(title: "OK", style:.default, handler: nil)
        alert.addAction(ok)
        present(alert, animated: true, completion: nil)
    }
    
    @IBAction func chooseAction(_ sender: UIButton) {
        //Choose image
        let actionSheet = UIAlertController(title: "MIC", message: "Choose image from" , preferredStyle: .actionSheet)
        actionSheet.addAction(UIAlertAction(title: "Camera", style: .default, handler: {(action: UIAlertAction) -> Void in
            self.openCamera()
        }
        ))
        actionSheet.addAction(UIAlertAction(title: "Gallery", style: .default, handler: {(action: UIAlertAction) -> Void in
            self.openGallery()
        }
        ))
        actionSheet.addAction(UIAlertAction(title: "Cancel", style: .cancel , handler: {
            (action: UIAlertAction) -> Void in
            actionSheet.dismiss(animated: true, completion: nil)
        }))
        present( actionSheet , animated: true , completion: nil)
    }
    
    ///////////
    func openGallery(){
        picker.allowsEditing = false
        picker.sourceType = UIImagePickerController.SourceType.photoLibrary
        present(picker, animated: true, completion: nil)
    }
    
    func openCamera()
    {
        if(UIImagePickerController .isSourceTypeAvailable(UIImagePickerController.SourceType.camera)){
            picker.allowsEditing = false
            picker.sourceType = UIImagePickerController.SourceType.camera
            picker.cameraCaptureMode = .photo
            present(picker, animated: true, completion: nil)
            
        }else{
            let alert = UIAlertController(title: "Camera Not Found", message: "This device has no Camera", preferredStyle: .alert)
            let ok = UIAlertAction(title: "OK", style:.default, handler: nil)
            alert.addAction(ok)
            present(alert, animated: true, completion: nil)
        }
    }
    ///////////
    func imagePickerControllerDidCancel(_ picker: UIImagePickerController) {
        dismiss(animated: true, completion: nil)
    }
    
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey : Any]) {
        let chosenImage = info[UIImagePickerController.InfoKey.originalImage] as! UIImage
        self.profile_imageView.layer.cornerRadius = 114
        self.profile_imageView.clipsToBounds = true
        self.profile_imageView.contentMode = .scaleAspectFill
        
        self.profile_imageView.image = chosenImage
        dismiss(animated: true, completion: nil)
    }
    
}
