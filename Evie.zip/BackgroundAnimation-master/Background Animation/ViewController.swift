//
//  ViewController.swift
//  Background Animation
//
//  Created by Chandan on 23/10/18.
//  Copyright © 2018 Chandan. All rights reserved.
//

import UIKit
import SkyFloatingLabelTextField
import TransitionButton

class ViewController: UIViewController, UITextFieldDelegate, UIViewControllerTransitioningDelegate {
    
    // UIView configuration
    @IBOutlet weak var nameView: UIView!
    @IBOutlet weak var emailView: UIView!
    @IBOutlet weak var passwordView: UIView!
    //
    @IBOutlet weak var signUpButton: TransitionButton!
    
    
    // TextField Configuration
    var nameTextField: SkyFloatingLabelTextFieldWithIcon!
    var emailTextField: SkyFloatingLabelTextFieldWithIcon!
    var passwordTextField: SkyFloatingLabelTextFieldWithIcon!

    //
    let gray = UIColor(hex: "DEDDDD")
    let onePixelPoint = 1.0 / UIScreen.main.scale
    
    var animCont: UIView!
    var animContHalf: UIView!

    override func viewDidLoad() {
        super.viewDidLoad()
        // ui configuration
        self.UIConfiguration()
        startAnims()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        init_func()
        startAnims()
        self.signUpButton.cornerRadius = 30
    }
    
    func UIConfiguration() {
        // sign in button configuration
        self.signUpButton.spinnerColor = .white
        self.signUpButton.cornerRadius = 30
        // Get the screen size
        let screenRect = UIScreen.main.bounds
        let screenWidth = screenRect.size.width
        
        // TextField UI Animation Configuration
        
        let textFieldFrame = CGRect(x: 0, y: 0, width: screenWidth - 80, height: 45)
        // nameTextField configuration
        
        nameTextField = SkyFloatingLabelTextFieldWithIcon(frame: textFieldFrame, iconType: .font)
        nameTextField.iconType = .font
        nameTextField.iconColor = UIColor.white
        nameTextField.iconFont = UIFont(name: "FontAwesome", size: 15)
        nameTextField.iconText = "\u{f007}"
        
        nameTextField.placeholder = "Name"
        nameTextField.title = "Name"
        nameTextField.keyboardAppearance = .dark
        
        self.nameView.addSubview(nameTextField)
        
        // emailTextField configuration
        emailTextField = SkyFloatingLabelTextFieldWithIcon(frame: textFieldFrame, iconType: .font)
        emailTextField.iconType = .font
        emailTextField.iconColor = UIColor.white
        emailTextField.iconFont = UIFont(name: "FontAwesome", size: 15)
        emailTextField.iconText = "\u{f0e0}"
        
        emailTextField.placeholder = "Email"
        emailTextField.title = "Email"
        emailTextField.keyboardType = .emailAddress
        emailTextField.keyboardAppearance = .dark
        
        self.emailView.addSubview(emailTextField)
        
        // passwordTextField configuration
        passwordTextField = SkyFloatingLabelTextFieldWithIcon(frame: textFieldFrame, iconType: .font)
        passwordTextField.iconType = .font
        passwordTextField.iconColor = UIColor.white
        
        passwordTextField.iconFont = UIFont(name: "FontAwesome", size: 15)
        passwordTextField.iconText = "\u{f084}"
        passwordTextField.placeholder = "Password"
        passwordTextField.title = "Password"
        passwordTextField.isSecureTextEntry = true
        passwordTextField.keyboardAppearance = .dark
        
        self.passwordView.addSubview(passwordTextField)
        
        // emailTextField color configuration
        nameTextField.lineColor = UIColor.white
        nameTextField.selectedLineColor = UIColor.orange
        nameTextField.textColor = UIColor.white
        nameTextField.tintColor = UIColor.lightGray
        nameTextField.selectedTitleColor = UIColor.orange
        nameTextField.selectedIconColor = UIColor.orange
        
        // emailTextField color configuration
        emailTextField.lineColor = UIColor.white
        emailTextField.selectedLineColor = UIColor.orange
        emailTextField.textColor = UIColor.white
        emailTextField.tintColor = UIColor.lightGray
        emailTextField.selectedTitleColor = UIColor.orange
        emailTextField.selectedIconColor = UIColor.orange
        
        // passwordTextField color configuration
        passwordTextField.lineColor = UIColor.white
        passwordTextField.selectedLineColor = UIColor.orange
        passwordTextField.textColor = UIColor.white
        passwordTextField.tintColor = UIColor.lightGray
        passwordTextField.selectedTitleColor = UIColor.orange
        passwordTextField.selectedIconColor = UIColor.orange
    }
    
    func init_func() {
        nameTextField.text?.removeAll()
        emailTextField.text?.removeAll()
        passwordTextField.text?.removeAll()
    }
    
    @IBAction func signupAction(_ sender: UIButton) {
        self.signUpButton.startAnimation()
        let storyboard: UIStoryboard? = UIStoryboard(name: "Main", bundle: nil)
        let rootVC = storyboard?.instantiateViewController(withIdentifier: "createProfileVC") as? CreateProfileViewController
        self.navigationController?.pushViewController(rootVC!, animated: true)
        self.signUpButton.stopAnimation()
    }
    
    @IBAction func gotoLoginVC(_ sender: UIButton) {
        let storyboard: UIStoryboard? = UIStoryboard(name: "Main", bundle: nil)
        let rootVC = storyboard?.instantiateViewController(withIdentifier: "signInVC") as? SignInViewController
        self.navigationController?.pushViewController(rootVC!, animated: true)
    }
    

    func startAnims() {
        stopAnims()
        animContHalf = UIView(frame: CGRect(x: 0, y: 0, width: view.bounds.width, height: view.bounds.height / 2))
        animContHalf.clipsToBounds = true
        view.addSubview(animContHalf)
        animCont = UIView(frame: view.bounds)
        view.addSubview(animCont)
        
        view.sendSubviewToBack(animCont)
        view.sendSubviewToBack(animContHalf)
        
        let rect = CGRect(x: 0, y: 0, width: animCont.frame.width, height: animCont.frame.width)
        Shapes.createDotedShape(view: animContHalf, rect: rect, duration: 60 * 3, dash: [1, 5], scale: 1.1, color: gray)
        Shapes.createDotedShape(view: animContHalf, rect: rect, duration: 60 * 1, dash: [1, 10], scale: 1.2, color: UIColor.darkGray)
        Shapes.createDotedShape(view: animContHalf, rect: rect, duration: 60 * 1, dash: [60, 60], scale: 1.55, lineWidth: onePixelPoint, color: UIColor.darkGray)
        let bounds = CGRect(x: 0, y: 0, width: view.frame.width, height: view.frame.height)
        for _ in 1...4 {
            Shapes.createRandTriangleAndAnim(view: animCont, bounds: bounds)
            Shapes.createRandCircleAndAnim(view: animCont, bounds: bounds)
            Shapes.createRandRectAndAnim(view: animCont, bounds: bounds)
        }
    }
    
    func stopAnims() {
        animContHalf?.removeFromSuperview()
        animCont?.removeFromSuperview()
    }
}

