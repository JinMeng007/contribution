//
//  SignUpViewController.swift
//  Background Animation
//
//  Created by MaskX on 1/10/19.
//  Copyright © 2019 Chandan. All rights reserved.
//

import UIKit
import SkyFloatingLabelTextField
import TransitionButton

class SignInViewController: BaseViewController, UIViewControllerTransitioningDelegate, UITextViewDelegate {

    // UIView configuration
    @IBOutlet weak var emailView: UIView!
    @IBOutlet weak var passwordView: UIView!
    //
    @IBOutlet weak var signInButton: TransitionButton!
    
    
    // TextField Configuration
    var emailTextField: SkyFloatingLabelTextFieldWithIcon!
    var passwordTextField: SkyFloatingLabelTextFieldWithIcon!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()

        self.UIConfiguration()
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        self.signInButton.cornerRadius = 30
    }
    
    func UIConfiguration() {
        // sign in button configuration
        self.signInButton.spinnerColor = .white
        self.signInButton.cornerRadius = 30
        // Get the screen size
        let screenRect = UIScreen.main.bounds
        let screenWidth = screenRect.size.width
        
        // TextField UI Animation Configuration
        
        let textFieldFrame = CGRect(x: 0, y: 0, width: screenWidth - 70, height: 45)
      
        
        // emailTextField configuration
        emailTextField = SkyFloatingLabelTextFieldWithIcon(frame: textFieldFrame, iconType: .font)
        emailTextField.iconType = .font
        emailTextField.iconColor = UIColor.white
        emailTextField.iconFont = UIFont(name: "FontAwesome", size: 15)
        emailTextField.iconText = "\u{f0e0}"
        
        emailTextField.placeholder = "Email"
        emailTextField.title = "Email"
        emailTextField.keyboardType = .emailAddress
        emailTextField.keyboardAppearance = .dark
        
        self.emailView.addSubview(emailTextField)
        
        // passwordTextField configuration
        passwordTextField = SkyFloatingLabelTextFieldWithIcon(frame: textFieldFrame, iconType: .font)
        passwordTextField.iconType = .font
        passwordTextField.iconColor = UIColor.white
        
        passwordTextField.iconFont = UIFont(name: "FontAwesome", size: 15)
        passwordTextField.iconText = "\u{f084}"
        passwordTextField.placeholder = "Password"
        passwordTextField.title = "Password"
        passwordTextField.isSecureTextEntry = true
        passwordTextField.keyboardAppearance = .dark
        
        self.passwordView.addSubview(passwordTextField)
        
        
        // emailTextField color configuration
        emailTextField.lineColor = UIColor.white
        emailTextField.selectedLineColor = UIColor.orange
        emailTextField.textColor = UIColor.white
        emailTextField.tintColor = UIColor.lightGray
        emailTextField.selectedTitleColor = UIColor.orange
        emailTextField.selectedIconColor = UIColor.orange
        
        // passwordTextField color configuration
        passwordTextField.lineColor = UIColor.white
        passwordTextField.selectedLineColor = UIColor.orange
        passwordTextField.textColor = UIColor.white
        passwordTextField.tintColor = UIColor.lightGray
        passwordTextField.selectedTitleColor = UIColor.orange
        passwordTextField.selectedIconColor = UIColor.orange
    }
    
    override func viewWillAppear(_ animated: Bool) {
        init_func()
    }
    
    func init_func() {
        emailTextField.text?.removeAll()
        passwordTextField.text?.removeAll()
    }
    
    func gotoProfileVC() {
        let storyboard: UIStoryboard? = UIStoryboard(name: "Main", bundle: nil)
        let rootVC = storyboard?.instantiateViewController(withIdentifier: "createProfileVC") as? CreateProfileViewController
        self.navigationController?.pushViewController(rootVC!, animated: true)
        
    }
    @IBAction func gotoBack(_ sender: UIButton) {
        self.navigationController?.popViewController(animated: true)
    }
    
    
    // do signup
    @IBAction func signIn_Action(_ sender: UIButton) {
        self.handleLogin()
    }
    
    // handle register
    func handleLogin() {
        self.gotoProfileVC()
    }
    

}
