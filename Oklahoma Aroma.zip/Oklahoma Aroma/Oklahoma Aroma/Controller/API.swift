//
//  API.swift
//  Aroma
//
//  Created by MaskX on 3/18/19.
//  Copyright © 2019 Lamarr. All rights reserved.
//

import UIKit

class API {
    class var sharedInstance: API {
        struct Static {
            static let instance: API = API()
        }
        return Static.instance
    }
    
    let BANNER_URL = "https://theoklahomaaroma.com/"
    let LOCALNEWS_URL = "https://theoklahomaaroma.com/local-news"
    let WORLDNEWS_URL = "https://theoklahomaaroma.com/world-wide-news"
    let EVENTS_URL = "https://theoklahomaaroma.com/calendar"
    let BUDFLIX_URL = "https://theoklahomaaroma.com/budflix"
    let COUPONS_URL = "https://theoklahomaaroma.com/coupons"
    let MAPLOCATOR_URL = "https://theoklahomaaroma.com/map-locator"
    
    
}
