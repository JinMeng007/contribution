//
//  WebViewController.swift
//  Oklahoma Aroma
//
//  Created by MaskX on 3/28/19.
//  Copyright © 2019 Aroma. All rights reserved.
//

import UIKit

fileprivate func < <T : Comparable>(lhs: T?, rhs: T?) -> Bool {
    switch (lhs, rhs) {
    case let (l?, r?):
        return l < r
    case (nil, _?):
        return true
    default:
        return false
    }
}

fileprivate func > <T : Comparable>(lhs: T?, rhs: T?) -> Bool {
    switch (lhs, rhs) {
    case let (l?, r?):
        return l > r
    default:
        return rhs < lhs
    }
}

class WebViewController: BaseViewController, UIWebViewDelegate {

    @IBOutlet weak var webView: UIWebView!
    @IBOutlet weak var activity: UIActivityIndicatorView!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        self.addGesture()
        self.configurationUI()
    }
    
    func configurationUI() {
        switch self.appDelegate.buttonIndex {
        case 100:
            self.bannerWebView()
        case 101:
            self.localNewsWebView()
        case 102:
            self.worldNewsWebView()
        case 103:
            self.eventsWebView()
        case 104:
            self.budflixWebView()
        case 105:
            self.saleWebView()
        case 106:
            self.mapLocatorWebView()
        default: break
        }
    }
    
    func goBack() {
        if(webView.canGoBack){
            webView.goBack()
        } else{
            self.navigationController?.popViewController(animated: true)
        }
    }
    
    func webViewLoad(url: String){
        if let urlStr = URL(string: url) {
            let request = URLRequest(url: urlStr)
            webView.loadRequest(request)
        }
    }
    
    func bannerWebView(){
        webViewLoad(url: API.sharedInstance.BANNER_URL)
    }
    
    func localNewsWebView(){
        webViewLoad(url: API.sharedInstance.LOCALNEWS_URL)
    }
    
    func worldNewsWebView(){
        webViewLoad(url: API.sharedInstance.WORLDNEWS_URL)
    }
    
    func eventsWebView(){
        webViewLoad(url: API.sharedInstance.EVENTS_URL)
    }
    
    func budflixWebView(){
        webViewLoad(url: API.sharedInstance.BUDFLIX_URL)
    }
    
    func saleWebView(){
        webViewLoad(url: API.sharedInstance.COUPONS_URL)
    }
    
    func mapLocatorWebView(){
        webViewLoad(url: API.sharedInstance.MAPLOCATOR_URL)
    }
    
    
    
    
    //
    func addGesture() {
        
        guard navigationController?.viewControllers.count > 1 else {
            return
        }
        
        panGestureRecognizer = UIPanGestureRecognizer(target: self, action: #selector(WebViewController.handlePanGesture(_:)))
        self.view.addGestureRecognizer(panGestureRecognizer)
    }
    
    @objc func handlePanGesture(_ panGesture: UIPanGestureRecognizer) {
        
        let percent = max(panGesture.translation(in: view).x, 0) / view.frame.width
        
        switch panGesture.state {
            
        case .began:
            self.goBack()
            
        case .changed:
            print("")
        case .ended:
            print("")
            
            
        case .cancelled, .failed:
            print("")
        default:
            break
        }
    }
    
    func webViewDidStartLoad(_ webView: UIWebView) {
        activity.startAnimating()
    }
    
    func webViewDidFinishLoad(_ webView: UIWebView) {
        activity.stopAnimating()
    }
    
    func webView(_ webView: UIWebView, didFailLoadWithError error: Error) {
        activity.stopAnimating()
    }

}
