
import UIKit
//import LGSideMenuController

class BaseViewController: UIViewController {
    
    let appDelegate: AppDelegate = UIApplication.shared.delegate as! AppDelegate
    var percentDrivenInteractiveTransition: UIPercentDrivenInteractiveTransition!
    var panGestureRecognizer: UIPanGestureRecognizer!

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        self.navigationController?.setNavigationBarHidden(true, animated: false)
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    //MARK: Gloabl Alert View Controller
    func alertViewController(title: String, message: String){
        let alert = UIAlertController(title: title.capitalized, message: message , preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "OK", style:.default, handler: nil))
        present(alert, animated: true, completion: nil)
    }
    
    func showHUD(){
//        EZLoadingActivity.Settings.ShadowEnabled = false
//        EZLoadingActivity.show("", disableUI: true)
    }
    
    func hideHUD(){
//        EZLoadingActivity.hide()
    }
    
    //MARK: Side menu Controller
   

}

extension BaseViewController: UINavigationControllerDelegate {
    
    
    func navigationController(_ navigationController: UINavigationController, animationControllerFor operation: UINavigationController.Operation, from fromVC: UIViewController, to toVC: UIViewController) -> UIViewControllerAnimatedTransitioning? {
        
        return SlideAnimatedTransitioning()
    }
    
    func navigationController(_ navigationController: UINavigationController, interactionControllerFor animationController: UIViewControllerAnimatedTransitioning) -> UIViewControllerInteractiveTransitioning? {
        
        if panGestureRecognizer != nil {
            navigationController.delegate = nil
            
            if panGestureRecognizer.state == .began {
                percentDrivenInteractiveTransition = UIPercentDrivenInteractiveTransition()
                percentDrivenInteractiveTransition.completionCurve = .easeOut
            } else {
                percentDrivenInteractiveTransition = nil
            }
            
            return percentDrivenInteractiveTransition
        }else {
            return nil
        }
        
    }
}

