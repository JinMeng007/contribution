//
//  ViewController.swift
//  Oklahoma Aroma
//
//  Created by MaskX on 3/28/19.
//  Copyright © 2019 Aroma. All rights reserved.
//

import UIKit

class ViewController: BaseViewController, AppModuleDelegate {

    var screenWidth = 0
    var screenHeight = 0
    var totalHeight: CGFloat = 0.0
    var totalWidth: CGFloat = 0.0
    
    let API_KEY:                String = "AbAM22GNW6uCs3gAje4XgjtZZ5KmWa2h"
    let LOCATION_CODE_INAPP:    String = "inapp"
    let LOCATION_CODE_REWARD:   String = "reward"
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        /// for starting the app
        AppTracker.setAppModuleDelegate(self);
        AppTracker.startSession(self.API_KEY, with: AppTrackerEnableAutoCache);
        self.showAds()
        self.getScreenSize()
        self.configurationUI()
    }
    
    func showAds() {
        if(AppTracker.isAdReady(LOCATION_CODE_INAPP)) {
            AppTracker.loadModule(LOCATION_CODE_INAPP, viewController: self);
        } else {
            // Ad not available yet
            print("ad not available yet")
        }
    }

    func getScreenSize() {
        self.screenWidth = Int(UIScreen.main.bounds.size.width)
        self.screenHeight = Int(UIScreen.main.bounds.height)
        self.totalHeight = UIScreen.main.bounds.height
        self.totalWidth = UIScreen.main.bounds.width
    }
    
    func configurationUI() {
        // banner button
        let bannerButton = UIButton(frame: CGRect(x: 0, y: 0, width: screenWidth, height: screenHeight/4))
        bannerButton.setImage(UIImage(named: "banner"), for: .normal)
        // world news button
        let worldnewsButton = UIButton(frame: CGRect(x: 0, y: screenHeight/4, width: screenWidth/2, height: screenHeight/4))
        worldnewsButton.setImage(UIImage(named: "localNews"), for: .normal)
        // bud flix button
        let budflixButton = UIButton(frame: CGRect(x: screenWidth/2, y: screenHeight/4, width: Int(totalWidth - CGFloat(screenWidth/2)), height: screenHeight/4))
        budflixButton.setImage(UIImage(named: "worldNews"), for: .normal)
        // calendar button
        let calendarButton = UIButton(frame: CGRect(x: 0, y: (screenHeight/4) * 2, width: screenWidth/2, height: screenHeight/4))
        calendarButton.setImage(UIImage(named: "events"), for: .normal)
        // flyers button
        let flyersButton = UIButton(frame: CGRect(x: screenWidth/2, y: (screenHeight/4) * 2, width: Int(totalWidth - CGFloat(screenWidth/2)), height: screenHeight/4))
        flyersButton.setImage(UIImage(named: "budflix"), for: .normal)
        // coupons button
        let couponsButton = UIButton(frame: CGRect(x: 0, y: (screenHeight/4) * 3, width: screenWidth/2, height: Int(totalHeight - CGFloat((screenHeight/4) * 3))))
        couponsButton.setImage(UIImage(named: "sale"), for: .normal)
        
        // map locator button
        let mapLocatorButton = UIButton(frame: CGRect(x: screenWidth/2, y: (screenHeight/4) * 3, width: Int(totalWidth - CGFloat(screenWidth/2)), height: Int(totalHeight - CGFloat((screenHeight/4) * 3))))
        mapLocatorButton.setImage(UIImage(named: "mapLocator"), for: .normal)
        // add target to all buttons
        bannerButton.addTarget(self, action: #selector(didTapbannerButton), for: .touchUpInside)
        worldnewsButton.addTarget(self, action: #selector(didTapworldnewsButton), for: .touchUpInside)
        budflixButton.addTarget(self, action: #selector(didTapbudflixButton), for: .touchUpInside)
        calendarButton.addTarget(self, action: #selector(didTapcalendarButton), for: .touchUpInside)
        flyersButton.addTarget(self, action: #selector(didTapflyersButton), for: .touchUpInside)
        couponsButton.addTarget(self, action: #selector(didTapCouponsButton), for: .touchUpInside)
        mapLocatorButton.addTarget(self, action: #selector(didTapmaplocationButton), for: .touchUpInside)
        // add all buttons to the view
        self.view.addSubview(bannerButton)
        self.view.addSubview(worldnewsButton)
        self.view.addSubview(budflixButton)
        self.view.addSubview(calendarButton)
        self.view.addSubview(flyersButton)
        self.view.addSubview(couponsButton)
        self.view.addSubview(mapLocatorButton)
    }
    
    @objc func didTapbannerButton() {
        self.appDelegate.buttonIndex = 100
        self.gotoWebView()
    }
    @objc func didTapworldnewsButton() {
        self.appDelegate.buttonIndex = 101
        self.gotoWebView()
    }
    @objc func didTapbudflixButton() {
        self.appDelegate.buttonIndex = 102
        self.gotoWebView()
    }
    @objc func didTapcalendarButton() {
        self.appDelegate.buttonIndex = 103
        self.gotoWebView()
    }
    @objc func didTapflyersButton() {
        self.appDelegate.buttonIndex = 104
        self.gotoWebView()
    }
    @objc func didTapCouponsButton() {
        self.appDelegate.buttonIndex = 105
        self.gotoWebView()
    }
    @objc func didTapmaplocationButton() {
        self.appDelegate.buttonIndex = 106
        self.gotoWebView()
    }
    
    
    func gotoWebView(){
        let storyboard: UIStoryboard? = UIStoryboard(name: "Main", bundle: nil)
        let rootVC = storyboard?.instantiateViewController(withIdentifier: "WebViewVC") as? WebViewController
        self.navigationController?.pushViewController(rootVC!, animated: true)
    }
    
    func onModuleCached(_ placement: String!) {
        print("Module", placement, "cached successfully", separator:" ");
        if(placement == LOCATION_CODE_INAPP) {
        } else if(placement == LOCATION_CODE_REWARD) {
        }
    }
    func onModuleLoaded(_ placement: String!) {
        print("Module", placement, "loaded successfully", separator:" ");
        if(placement == LOCATION_CODE_INAPP) {
            print("location_code_inapp")
        } else if(placement == LOCATION_CODE_REWARD) {
            print("location_code_reward")
        }
    }
    func onModuleFailed(_ placement: String!, error: String!, cached iscached: Bool) {
        if(iscached) {
            print("Module", placement, "failed to cache:", error, separator:" ")
        } else {
            print("Module", placement, "failed to load:", error, separator:" ")
        }
    }
    func onModuleClicked(_ placement: String!) {
        print("Module", placement, "clicked by user", separator:" ");
        
    }
    func onModuleClosed(_ placement: String!, reward:Bool) {
        print("Module", placement, "closed by user", separator:" ");
        if(reward) {
            print("Reward Triggered");
        }
    }

}

