//
//  WooProductDisplay.swift
//  Eightfold
//
//  Created by brianna on 1/28/18.
//  Copyright © 2018 Owly Design. All rights reserved.
//

import Foundation

/// <#Description#>
///
/// - Default: <#Default description#>
/// - products: <#products description#>
/// - subcategories: <#subcategories description#>
/// - both: <#both description#>
public enum WooProductDisplay: String {
    case Default = "default"
    case products = "products"
    case subcategories = "subcategories"
    case both = "both"
}
