//
//  WooRequestParameters.swift
//  Eightfold
//
//  Created by brianna on 1/28/18.
//  Copyright © 2018 Owly Design. All rights reserved.
//

import Foundation

public class WooRequestParameters {
    public struct Array {
        var type: WooRequestType
        var parameters: [String:String]
    }
}
