//
//  WooSortOrder.swift
//  Eightfold
//
//  Created by brianna on 1/28/18.
//  Copyright © 2018 Owly Design. All rights reserved.
//

import Foundation

/// <#Description#>
///
/// - ascending: <#ascending description#>
/// - descending: <#descending description#>
public enum WooSortOrder: String {
    case ascending = "asc"
    case descending = "desc"
}
