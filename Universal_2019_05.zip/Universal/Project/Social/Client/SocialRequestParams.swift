//
//  RequestParams.swift
//  Hackers
//
//  Created by Mark on 20/11/2018.
//  Copyright © 2018 Sherdle. All rights reserved.
//

import Foundation

public class SocialRequestParams {
    public var page: Int?
    public var nextPageToken: String?
    public var perPage: Int?
    public var category: String?
}
