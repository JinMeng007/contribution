//
//  UINavigationBar+Custom.h
//  Universal
//
//  Created by Mark on 22/04/2018.
//  Copyright © 2018 Sherdle. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface CustomNavigationBar : UINavigationBar

@property (strong, nonatomic) UIView *backgroundView;

@end
