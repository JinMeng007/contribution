//
//  SWRevealViewController+Subviews.h
//  Universal
//
//  Created by Mu-Sonic on 28/11/2015.
//  Copyright © 2018 Sherdle. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "SWRevealViewController.h"

@interface SWRevealViewController (SWRevealViewController_Subviews)

@end
