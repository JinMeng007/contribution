//
//  RearViewCell.h
//  Universal
//
//  Created by Mu-Sonic on 07/11/2015.
//  Copyright © 2018 Sherdle. All rights reserved.
//

#import <UIKit/UIKit.h>

#define SELECTED_COLOR [UIColor colorWithRed:0.0f/255.0f green:66.0f/255.0f blue:117.0f/255.0f alpha:0.2]

@interface RearViewCell : UITableViewCell

@end
