//
//  main.m
//  Universal
//
//  Created by Apple on 22/07/14.
//  Copyright (c) 2018 Sherdle. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "AppDelegate.h"

#import "RemoteApplication.h"

int main(int argc, char * argv[])
{
    @autoreleasepool {
         return UIApplicationMain(argc, argv, NSStringFromClass([RemoteApplication class]), NSStringFromClass([AppDelegate class]));
    }
}
