//
//  Item.h
//  Universal
//
//  Created by Mark on 02/08/2017.
//  Copyright © 2017 Sherdle. All rights reserved.
//

@interface Item : NSObject

@property NSString *name;
@property NSString *icon;
@property BOOL iap;

@property NSMutableArray *tabs;

@end
