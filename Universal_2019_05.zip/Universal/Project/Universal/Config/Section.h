//
//  Section.h
//  Universal
//
//  Created by Mark on 02/08/2017.
//  Copyright © 2017 Sherdle. All rights reserved.
//

@interface Section : NSObject

@property NSString *name;
@property NSMutableArray *items;

@end

