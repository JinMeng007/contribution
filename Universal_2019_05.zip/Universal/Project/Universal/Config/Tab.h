//
//  Tab.h
//  Universal
//
//  Created by Mark on 02/08/2017.
//  Copyright © 2017 Sherdle. All rights reserved.
//

@interface Tab : NSObject

@property NSString *name;
@property NSString *icon;
@property NSString *type;

@property NSMutableArray *params;

@end
