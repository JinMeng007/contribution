//
//  Config.h
//
//  Copyright (c) 2018 Sherdle. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface Config : NSObject

@property (class) NSArray *config;
@end
