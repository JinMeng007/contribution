//
//  Constants.swift
//  Universal
//
//  Created by Mark on 17/03/2018.
//  Copyright © 2018 Sherdle. All rights reserved.
//

import Foundation

public let currency = "$"

public let weight_unit = "KG"

public let size_unit = "M"

public let checkout_url = "/checkout/"

public let checkout_order_received = "/checkout/order-received/"
