//
//  FooterView.m
//
//  Copyright (c) 2018 Sherdle. All rights reserved.
//

#import "FooterView.h"

@implementation FooterView
@end
