//
//  FooterView.h
//
//  Copyright (c) 2018 Sherdle. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface FooterView : UICollectionReusableView

@property (nonatomic, retain) IBOutlet UIActivityIndicatorView *activityIndicator;

@end
