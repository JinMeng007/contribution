//
//  UniversalTests.m
//  UniversalTests
//
//  Created by Apple on 22/07/14.
//  Copyright (c) 2018 Sherdle. All rights reserved.
//

#import <XCTest/XCTest.h>

@interface UniversalTests : XCTestCase

@end

@implementation UniversalTests

- (void)setUp
{
    [super setUp];
    // Put setup code here. This method is called before the invocation of each test method in the class.
}

- (void)tearDown
{
    // Put teardown code here. This method is called after the invocation of each test method in the class.
    [super tearDown];
}

- (void)testExample
{

}

@end
