//
//  RestProvider.h
//  Universal
//
//  Created by Mark on 31/01/2017.
//  Copyright © 2017 Sherdle. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "WordpressProvider.h"

@interface RestProvider : NSObject <WordpressProvider>

@end
