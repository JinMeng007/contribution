//
//  SliderStub.swift
//  
//
//  Created by Mark on 17/12/2018.
//

import Foundation

class SliderStub: WPPost {
}

