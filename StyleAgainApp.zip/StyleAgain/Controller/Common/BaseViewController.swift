//
//  BaseViewController.swift
//  StyleAgain
//
//  Created by Macmini on 12/2/18.
//  Copyright © 2018 Style Again. All rights reserved.
//

import UIKit

class BaseViewController: UIViewController {
    
    override func viewDidLoad() {
        super.viewDidLoad()        
    }
    
    @IBAction func prepareToUnWind(segue: UIStoryboardSegue?) {
        
    }

}
